const express = require("express");
const { createRandomQuestion } = require("../controllers/randomQuestion.controller");
const {getRandomQuestion} = require("../controllers/randomQuestion.controller");
const { answer } = require("../controllers/answer.controller");
const router = express.Router();

router.post("/createquestion", createRandomQuestion);
router.post("/answer",answer);
router.get("/randomQuestion", getRandomQuestion);
module.exports = router;
