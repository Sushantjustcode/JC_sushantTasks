const express = require("express");
const allRoutes = require("./routes/allRoutes.route");

const app = express();


app.use(express.json());
app.use("/api", allRoutes);

module.exports = app;
