const RandomQuestion = require("../models/randomQuestion.model");
const { createRandomQuestion: createRandomQuestionService } = require("../services/randomQuestion.service");

const createRandomQuestion = async (req, res) => {
    try {
        const { question, answerKeywords } = req.body;
        const newQuestion = await createRandomQuestionService({ question, answerKeywords });

        return res.status(201).json({
            message: "Random ques created",
            data: newQuestion,
        });
    } catch (error) {
        return res.status(400).json({
            message: error.message,
        });
    }
};

const getRandomQuestion = async (req, res) => {
    try {
        const randomQuestion = await RandomQuestion.aggregate([{ $sample: { size: 1 } }]);
        if (randomQuestion.length === 0) {
            return res.status(400).json({
                message: "No question found",
            });
        }
        console.log(randomQuestion,"it is a random question wholle");
        console.log(randomQuestion[0], "it is a random question idx 0");
        
        return res.status(200).json({
            message: "Random question fetched successfully",
            data: randomQuestion[0],
        });
    } catch (error) {
        return res.status(500).json({
            message: "Error fetching random question",
            error: error.message,
        });
    }
};

module.exports = {
    createRandomQuestion,
    getRandomQuestion,
};
