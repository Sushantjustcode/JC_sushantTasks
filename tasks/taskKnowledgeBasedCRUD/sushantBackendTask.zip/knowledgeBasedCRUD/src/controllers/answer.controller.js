const { answerService } = require("../services/answer.service");

const answer = async (req, res) => {
    try {
        const { questionId, question, answer: submittedAnswer } = req.body;

        const result = await answerService({
            questionId,
            answer: submittedAnswer,
        });

        return res.status(200).json(result);
    } catch (error) {
            return res.status(400).json({
            success: false,
            message: error.message,
        });
    }
};

module.exports = {
    answer,
};
