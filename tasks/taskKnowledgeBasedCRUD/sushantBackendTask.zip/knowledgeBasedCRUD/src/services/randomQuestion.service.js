const RandomQuestion = require("../models/randomQuestion.model");

const createRandomQuestion = async ({ question, answerKeywords }) => {
    if (!question || !answerKeywords || !Array.isArray(answerKeywords) || answerKeywords.length === 0) {
        const error = new Error("question and answerKeywords are required.");
        error.statusCode = 400;
        throw error;
    }

    return RandomQuestion.create({
        question,
        answerKeywords,
    });
};

module.exports = {
    createRandomQuestion,
};
