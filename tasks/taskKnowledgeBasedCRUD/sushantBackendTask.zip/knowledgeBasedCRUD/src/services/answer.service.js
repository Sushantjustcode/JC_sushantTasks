const RandomQuestion = require("../models/randomQuestion.model");
const QuestionAnswer = require("../models/questionAnswer.model");

const answerService = async ({ questionId, question, answer }) => {
    
    const targetQuestionId = questionId || question._id ||  question.id;

    console.log(questionId,question,answer,"these are questionID, question, answer");
    console.log(targetQuestionId,"is the targeted ID");

    if (!targetQuestionId) {
        const error = new Error("questionId is required. Use the id from /randomQuestion route");
        error.statusCode = 400;
        throw error;
    }

    if (!answer || String(answer).trim() === "") {
        const error = new Error("answer MSUT be entered");
        error.statusCode = 400;
        throw error;
    }

    const currentQuestion = await RandomQuestion.findById(targetQuestionId);

    if (!currentQuestion) {
        const error = new Error("Question not found for the given id");
        error.statusCode = 404;
        throw error;
    }

    const normalizedAnswer = String(answer).trim().toLowerCase();
    const keywords = (currentQuestion.answerKeywords || [])
        .map((keyword) => String(keyword).trim().toLowerCase());

    const matchedKeywords = keywords.filter((keyword) =>
        normalizedAnswer.includes(keyword),
    );
    const isCorrect = matchedKeywords.length > 0;

    await QuestionAnswer.create({
        randomQuestion: currentQuestion._id,
        Answer: String(answer).trim(),
        correct: isCorrect,
        incorrect: !isCorrect,
        count: isCorrect ? 1 : 0,
        refOfAns: "",
    });

    return {
        success: true,
        isCorrect,
        questionId: currentQuestion._id,
        question: currentQuestion.question,
        matchedKeywords,
        correctAnswer: keywords,
        userAnswer: String(answer).trim(),
    };
};

module.exports = {
    answerService,
};
