const mongoose = require("mongoose");

const questionAnswerSchema = new mongoose.Schema(
    {
        randomQuestion: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "RandomQuestion",
            required: true,
        },
        Answer: {
            type: String,
            required: true,
            trim: true,
        },
        correct: {
            type: Boolean,
            default: false,
        },
        incorrect: {
            type: Boolean,
            default: false,
        },
        count: {
            type: Number,
            default: 0,
        },
        refOfAns: {
            type: String,
            default: "",
        },
    },
    { timestamps: true }
);

module.exports = mongoose.model("QuestionAnswer", questionAnswerSchema);
