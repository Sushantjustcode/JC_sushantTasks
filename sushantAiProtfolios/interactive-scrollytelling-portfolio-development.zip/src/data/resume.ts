export const profile = {
  name: "Sushant Chauhan",
  role: "Full-Stack MERN Developer  //  Game & 3D Environment Designer",
  location: "Karnal, Haryana, India",
  phone: "+91-7015132358",
  email: "mailto:example@gmail.com",
  linkedin: "https://linkedin.com",
  portfolio: "#",
  tags: ["Full-Stack (MERN)", "Game & 3D Design", "Self-Driven Learner", "BCA · AI"],
  blurb:
    "Full-Stack MERN Developer with hands-on experience building web applications using React.js, Node.js, Express.js and MongoDB. Completed multiple structured training programs — including an intensive backend-focused MERN internship and an industrial training program — and independently builds and ships end-to-end personal projects on an ongoing basis. Brings a confident, self-driven approach to practical experience in game development, level design and 3D modeling, adding strong problem solving, performance awareness and attention to detail to every build.",
};

export const experience = [
  {
    title: "Self-Driven Developer",
    org: "Independent Projects & Continuous Learning",
    time: "Ongoing",
    points: [
      "Independently conceptualized, designed and built multiple end-to-end projects spanning full-stack web development and 3D environment art.",
      "Maintains a disciplined self-learning routine — regularly exploring new frameworks, engines and design patterns outside formal coursework.",
      "Applies modern development best practices (component-based architecture, version control, responsive design) across every build.",
      "Continuously iterates on past projects to refine performance, visual polish and code quality.",
    ],
  },
  {
    title: "Web Development Intern — Backend & MERN Training",
    org: "CodeQuotient School of Technology, Panipat",
    time: "Jul 2026 – Aug 2026",
    points: [
      "Learned and applied the MERN stack with an emphasis on backend development, REST APIs, database operations and structured application architecture.",
      "Built a Student Management System using MongoDB, Express.js, React.js and Node.js as the internship project.",
      "Implemented CRUD workflows, database integration and a responsive management interface for handling student records.",
      "Practiced debugging, modular coding, Git-based workflow and translating requirements into working application features.",
    ],
  },
  {
    title: "Industrial Trainee",
    org: "CodeQuotient School of Technology",
    time: "Jul 2025 – Aug 2025",
    points: [
      "Completed an intensive, project-driven 6–8 week training program focused on professional software development practices and career readiness.",
      "Strengthened real-world application architecture skills by translating abstract problem statements into working, structured code.",
      "Practiced collaborative development workflows, code reviews and iterative debugging in a fast-paced training environment.",
      "Demonstrated rapid learning agility, consistency and strong technical performance throughout the program, earning recognition from mentors.",
    ],
  },
];

export const projects = [
  {
    title: "Student Management System",
    tags: ["MERN Stack", "MongoDB", "Express.js", "React.js", "Node.js"],
    points: [
      "Built as the internship project at CodeQuotient School of Technology, Panipat.",
      "Implemented CRUD operations, database integration and structured record workflows.",
      "Designed a responsive interface for managing and searching student information.",
    ],
    icon: "code",
  },
  {
    title: "Library Management System",
    tags: ["Web Development", "Database"],
    points: [
      "Developed a management application for organizing books and library records.",
      "Focused on clear data handling, practical workflows and an easy-to-use interface.",
    ],
    icon: "book",
  },
  {
    title: "Personal Portfolio Websites",
    tags: ["React.js", "JavaScript", "Tailwind CSS"],
    points: [
      "Designed responsive portfolio websites to present development and creative work.",
      "Focused on clean navigation, visual hierarchy, responsive layouts and professional presentation.",
    ],
    icon: "window",
  },
  {
    title: "Horror Game — Forest Level Design",
    tags: ["Unreal Engine", "Unity", "Blender"],
    points: [
      "Designed a horror-themed forest level using environment composition, pacing, sightlines and lighting.",
      "Created exploration spaces, set-pieces and atmosphere-focused environments to support gameplay flow.",
      "Applied level design thinking to guide player attention and communicate mood through the environment.",
    ],
    icon: "forest",
  },
  {
    title: "3D Modeling — Game Assets",
    tags: ["Blender", "Unity", "Unreal Engine"],
    points: [
      "Modeled game assets and environment elements for use in 3D scenes.",
      "Worked with materials, textures, lighting and game-ready asset preparation.",
      "Balanced visual detail with practical real-time requirements when preparing assets for game environments.",
    ],
    icon: "cube",
  },
];

export const skills = {
  Frontend: ["React.js", "JavaScript", "HTML5", "CSS3", "Tailwind CSS", "Bootstrap"],
  Backend: ["Node.js", "Express.js", "REST APIs", "CRUD", "MERN"],
  Databases: ["MongoDB", "SQL"],
  Programming: ["C", "C++", "C#", "Python", "OOP", "DSA"],
  "Game & 3D": ["Blender", "Unity", "Unreal Engine", "Level Design", "3D Modeling", "Environment Art", "Lighting", "Texturing"],
  Tools: ["Git", "GitHub", "MS Excel", "MS PowerPoint", "MS Word"],
};

export const strengths = [
  "Problem Solving",
  "Debugging & Troubleshooting",
  "Systematic Thinking",
  "Creativity & Design Thinking",
  "Adaptability",
  "Communication",
  "Confidence",
  "Leadership",
];

export const achievements = [
  { title: "HackWars Hackathon", detail: "Runner-Up — NIT Karnataka", year: "" },
  { title: "CodeMaster Hackathon", detail: "Runner-Up (Semifinalist) — CQST College", year: "" },
  { title: "WhiteHat Jr Game Developer", detail: "Achievement", year: "2020" },
  { title: "Football", detail: "Medallist — Interschool Competition", year: "" },
  { title: "Basketball", detail: "Medallist — Interschool Competition", year: "" },
];

export const education = [
  {
    title: "BCA — Artificial Intelligence",
    org: "Kurukshetra University",
    time: "July 2024 – July 2027",
  },
  {
    title: "Secondary Education — Non-Medical Science",
    org: "War Heroes Memorial School, Basdhara, Karnal",
    time: "Class 10 — 2022 · Class 12 — 2024",
  },
];
