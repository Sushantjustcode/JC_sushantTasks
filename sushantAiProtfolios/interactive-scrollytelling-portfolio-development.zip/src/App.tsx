import { useEffect, useState } from "react";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { useSmoothScroll } from "./lib/useSmoothScroll";
import Preloader from "./components/Preloader";
import Cursor from "./components/Cursor";
import ProgressBar from "./components/ProgressBar";
import NavDots from "./components/NavDots";
import Header from "./components/Header";
import Hero from "./components/Hero";
import Profile from "./components/Profile";
import Experience from "./components/Experience";
import Projects from "./components/Projects";
import SkillsConstellation from "./components/SkillsConstellation";
import Strengths from "./components/Strengths";
import Achievements from "./components/Achievements";
import Education from "./components/Education";
import Contact from "./components/Contact";

export default function App() {
  const [loading, setLoading] = useState(true);
  useSmoothScroll();

  useEffect(() => {
    const t = setTimeout(() => ScrollTrigger.refresh(), 400);
    return () => clearTimeout(t);
  }, [loading]);

  return (
    <>
      {loading && <Preloader onDone={() => setLoading(false)} />}
      <div className="grain" />
      <Cursor />
      <ProgressBar />
      <NavDots />
      <Header />
      <main>
        <Hero />
        <Profile />
        <Experience />
        <Projects />
        <SkillsConstellation />
        <Strengths />
        <Achievements />
        <Education />
        <Contact />
      </main>
    </>
  );
}
