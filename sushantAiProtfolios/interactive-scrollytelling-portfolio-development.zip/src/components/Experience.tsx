import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { experience } from "../data/resume";

gsap.registerPlugin(ScrollTrigger);

export default function Experience() {
  const root = useRef<HTMLDivElement>(null);
  const lineRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.to(lineRef.current, {
        scaleY: 1,
        ease: "none",
        scrollTrigger: {
          trigger: ".timeline-list",
          start: "top 60%",
          end: "bottom 70%",
          scrub: true,
        },
      });

      document.querySelectorAll<HTMLElement>(".exp-item").forEach((item) => {
        const node = item.querySelector(".exp-node");
        const card = item.querySelector(".exp-card");
        gsap.fromTo(
          node,
          { scale: 0 },
          {
            scale: 1,
            duration: 0.4,
            ease: "back.out(3)",
            scrollTrigger: { trigger: item, start: "top 70%" },
          }
        );
        gsap.fromTo(
          card,
          { opacity: 0, y: 50, filter: "blur(6px)" },
          {
            opacity: 1,
            y: 0,
            filter: "blur(0px)",
            duration: 0.9,
            ease: "power3.out",
            scrollTrigger: { trigger: item, start: "top 75%" },
          }
        );
        const bullets = item.querySelectorAll(".exp-bullet");
        gsap.fromTo(
          bullets,
          { opacity: 0, x: -14 },
          {
            opacity: 1,
            x: 0,
            stagger: 0.08,
            duration: 0.6,
            ease: "power2.out",
            scrollTrigger: { trigger: item, start: "top 60%" },
          }
        );
      });
    }, root);
    return () => ctx.revert();
  }, []);

  return (
    <section id="experience" ref={root} className="relative py-28 md:py-40 px-6 md:px-14" style={{ background: "var(--cream-deep)" }}>
      <div className="max-w-6xl mx-auto">
        <div className="flex items-end justify-between mb-16 md:mb-24 flex-wrap gap-4">
          <h2 className="font-display text-3xl md:text-5xl" style={{ color: "var(--ink)" }}>
            Where the hours <span className="text-rust italic">went.</span>
          </h2>
          <span className="font-mono-ish text-xs tracking-[0.2em] uppercase text-moss">02 / Experience</span>
        </div>

        <div className="timeline-list relative pl-10 md:pl-16">
          <div className="absolute left-[7px] md:left-[7px] top-0 bottom-0 w-px" style={{ background: "var(--line)" }} />
          <div
            ref={lineRef}
            className="absolute left-[7px] md:left-[7px] top-0 w-px origin-top bg-rust"
            style={{ transform: "scaleY(0)", height: "100%" }}
          />

          <div className="flex flex-col gap-20 md:gap-28">
            {experience.map((exp) => (
              <div key={exp.title} className="exp-item relative">
                <span
                  className="exp-node absolute -left-10 md:-left-16 top-1.5 w-[15px] h-[15px] rounded-full border-2"
                  style={{ borderColor: "var(--rust)", background: "var(--cream-deep)" }}
                />
                <div className="exp-card">
                  <div className="flex flex-wrap items-baseline gap-x-4 gap-y-1 mb-3">
                    <h3 className="font-display text-xl md:text-2xl" style={{ color: "var(--ink)" }}>
                      {exp.title}
                    </h3>
                    <span className="font-mono-ish text-[11px] uppercase tracking-wider text-rust">{exp.time}</span>
                  </div>
                  <p className="text-sm md:text-base mb-4" style={{ color: "var(--ink-soft)" }}>
                    {exp.org}
                  </p>
                  <ul className="flex flex-col gap-2 max-w-2xl">
                    {exp.points.map((p) => (
                      <li key={p} className="exp-bullet flex gap-3 text-sm md:text-[15px] leading-relaxed" style={{ color: "var(--ink-soft)" }}>
                        <span className="mt-2 w-1 h-1 rounded-full bg-rust shrink-0" />
                        {p}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
