import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { MotionPathPlugin } from "gsap/MotionPathPlugin";
import { education } from "../data/resume";

gsap.registerPlugin(ScrollTrigger, MotionPathPlugin);

export default function Education() {
  const root = useRef<HTMLDivElement>(null);
  const pathRef = useRef<SVGPathElement>(null);
  const markerRef = useRef<HTMLDivElement>(null);
  const drawRef = useRef<SVGPathElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const len = pathRef.current!.getTotalLength();
      gsap.set(drawRef.current, { strokeDasharray: len, strokeDashoffset: len });

      gsap.to(markerRef.current, {
        motionPath: {
          path: pathRef.current!,
          align: pathRef.current!,
          alignOrigin: [0.5, 0.5],
        },
        ease: "none",
        scrollTrigger: {
          trigger: root.current,
          start: "top 75%",
          end: "bottom 60%",
          scrub: 0.6,
        },
      });

      gsap.to(drawRef.current, {
        strokeDashoffset: 0,
        ease: "none",
        scrollTrigger: {
          trigger: root.current,
          start: "top 75%",
          end: "bottom 60%",
          scrub: 0.6,
        },
      });

      gsap.utils.toArray<HTMLElement>(".edu-card").forEach((card) => {
        gsap.fromTo(
          card,
          { opacity: 0, y: 40 },
          { opacity: 1, y: 0, duration: 0.9, ease: "power3.out", scrollTrigger: { trigger: card, start: "top 80%" } }
        );
      });
    }, root);
    return () => ctx.revert();
  }, []);

  return (
    <section id="education" ref={root} className="relative py-28 md:py-40 px-6 md:px-14 overflow-hidden" style={{ background: "var(--cream)" }}>
      <div className="max-w-6xl mx-auto relative">
        <div className="flex items-end justify-between mb-20 flex-wrap gap-4">
          <h2 className="font-display text-3xl md:text-5xl" style={{ color: "var(--ink)" }}>
            The path <span className="text-rust italic">so far.</span>
          </h2>
          <span className="font-mono-ish text-xs tracking-[0.2em] uppercase text-moss">06 / Education</span>
        </div>

        <div className="relative grid md:grid-cols-[1fr_auto] gap-10 items-stretch">
          <div className="flex flex-col gap-24 md:gap-40 py-10">
            {education.map((e, i) => (
              <div key={e.title} className={`edu-card max-w-md ${i % 2 === 1 ? "md:ml-auto md:text-right" : ""}`}>
                <span className="font-mono-ish text-xs uppercase tracking-[0.2em] text-rust">{e.time}</span>
                <h3 className="font-display text-2xl md:text-3xl mt-2 mb-2" style={{ color: "var(--ink)" }}>
                  {e.title}
                </h3>
                <p className="text-sm md:text-base" style={{ color: "var(--ink-soft)" }}>
                  {e.org}
                </p>
              </div>
            ))}
          </div>

          <div className="absolute md:relative left-1/2 md:left-auto -translate-x-1/2 md:translate-x-0 w-16 md:w-40 h-full pointer-events-none opacity-70 md:opacity-100">
            <svg viewBox="0 0 160 600" className="w-full h-full" preserveAspectRatio="none">
              <path
                ref={pathRef}
                d="M80,10 C20,100 140,180 80,260 C20,340 140,420 80,500 C40,540 100,560 80,590"
                fill="none"
                stroke="var(--line)"
                strokeWidth="1.5"
              />
              <path
                ref={drawRef}
                d="M80,10 C20,100 140,180 80,260 C20,340 140,420 80,500 C40,540 100,560 80,590"
                fill="none"
                stroke="var(--rust)"
                strokeWidth="1.5"
              />
            </svg>
            <div
              ref={markerRef}
              className="absolute top-0 left-0 w-4 h-4 -ml-2 -mt-2 rounded-full border-2"
              style={{ borderColor: "var(--rust)", background: "var(--cream)" }}
            />
          </div>
        </div>
      </div>
    </section>
  );
}
