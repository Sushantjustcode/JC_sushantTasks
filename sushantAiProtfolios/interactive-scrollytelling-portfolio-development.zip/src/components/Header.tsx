import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { profile } from "../data/resume";

gsap.registerPlugin(ScrollTrigger);

export default function Header() {
  const bar = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let last = false;
    const apply = (scrolled: boolean) => {
      if (scrolled === last) return;
      last = scrolled;
      gsap.to(bar.current, {
        y: scrolled ? 0 : -110,
        duration: 0.6,
        ease: "power3.out",
        overwrite: true,
      });
      if (bar.current) {
        bar.current.style.backdropFilter = scrolled ? "blur(10px)" : "blur(0px)";
      }
    };

    const st = ScrollTrigger.create({
      start: 0,
      end: "max",
      onUpdate: (self) => apply(self.scroll() > 80),
    });
    return () => st.kill();
  }, []);

  return (
    <header
      ref={bar}
      className="fixed top-0 left-0 right-0 z-[45] px-6 md:px-14 py-4 flex items-center justify-between border-b"
      style={{
        borderColor: "var(--line)",
        background: "rgba(243,239,230,0.78)",
        transform: "translateY(-110%)",
      }}
    >
      <a href="#hero" data-cursor="link" className="flex items-center gap-3">
        <span
          className="w-9 h-9 rounded-full flex items-center justify-center font-display text-sm"
          style={{ background: "var(--ink)", color: "var(--cream)" }}
        >
          SC
        </span>
        <span className="flex flex-col leading-tight">
          <span className="font-display text-base md:text-lg" style={{ color: "var(--ink)" }}>
            {profile.name}
          </span>
          <span className="font-mono-ish text-[10px] uppercase tracking-[0.18em]" style={{ color: "var(--rust)" }}>
            MERN Dev · 3D Designer
          </span>
        </span>
      </a>

      <span className="font-mono-ish text-[10px] md:text-[11px] uppercase tracking-[0.2em] hidden sm:block" style={{ color: "var(--ink-soft)" }}>
        Portfolio — {new Date().getFullYear()}
      </span>
    </header>
  );
}
