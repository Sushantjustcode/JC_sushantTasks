import { useEffect, useRef } from "react";
import * as THREE from "three";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

export default function HeroField({ containerSelector }: { containerSelector: string }) {
  const mountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(50, mount.clientWidth / mount.clientHeight, 0.1, 100);
    camera.position.set(0, 0, 8);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(mount.clientWidth, mount.clientHeight);
    mount.appendChild(renderer.domElement);

    // Central wireframe icosahedron cluster
    const group = new THREE.Group();
    scene.add(group);

    const geo = new THREE.IcosahedronGeometry(2.3, 1);
    const wire = new THREE.WireframeGeometry(geo);
    const lineMat = new THREE.LineBasicMaterial({ color: new THREE.Color("#c1532e"), transparent: true, opacity: 0.55 });
    const lines = new THREE.LineSegments(wire, lineMat);
    group.add(lines);

    const geo2 = new THREE.IcosahedronGeometry(1.15, 0);
    const wire2 = new THREE.WireframeGeometry(geo2);
    const lineMat2 = new THREE.LineBasicMaterial({ color: new THREE.Color("#16150f"), transparent: true, opacity: 0.3 });
    const lines2 = new THREE.LineSegments(wire2, lineMat2);
    group.add(lines2);

    // Orbiting ring
    const ringGeo = new THREE.TorusGeometry(3.4, 0.006, 8, 120);
    const ringMat = new THREE.MeshBasicMaterial({ color: new THREE.Color("#16150f"), transparent: true, opacity: 0.25 });
    const ring = new THREE.Mesh(ringGeo, ringMat);
    ring.rotation.x = Math.PI / 2.4;
    group.add(ring);

    // Particle field
    const COUNT = 420;
    const positions = new Float32Array(COUNT * 3);
    for (let i = 0; i < COUNT; i++) {
      const r = 5 + Math.random() * 6;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      positions[i * 3 + 2] = r * Math.cos(phi) * 0.4;
    }
    const pGeo = new THREE.BufferGeometry();
    pGeo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    const pMat = new THREE.PointsMaterial({ color: new THREE.Color("#3c3a32"), size: 0.028, transparent: true, opacity: 0.55 });
    const points = new THREE.Points(pGeo, pMat);
    scene.add(points);

    let targetX = 0;
    let targetY = 0;
    const onMouseMove = (e: MouseEvent) => {
      targetX = (e.clientX / window.innerWidth - 0.5) * 0.6;
      targetY = (e.clientY / window.innerHeight - 0.5) * 0.6;
    };
    window.addEventListener("mousemove", onMouseMove);

    const resize = () => {
      if (!mount) return;
      camera.aspect = mount.clientWidth / mount.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(mount.clientWidth, mount.clientHeight);
    };
    window.addEventListener("resize", resize);

    let frameId: number;
    const clock = new THREE.Clock();
    const render = () => {
      const dt = clock.getDelta();
      group.rotation.y += dt * 0.12;
      group.rotation.x += dt * 0.04;
      lines2.rotation.y -= dt * 0.18;
      points.rotation.y += dt * 0.02;

      camera.position.x += (targetX * 1.4 - camera.position.x) * 0.04;
      camera.position.y += (-targetY * 1.4 - camera.position.y) * 0.04;
      camera.lookAt(0, 0, 0);

      renderer.render(scene, camera);
      frameId = requestAnimationFrame(render);
    };
    render();

    const st = ScrollTrigger.create({
      trigger: containerSelector,
      start: "top top",
      end: "bottom top",
      scrub: 0.6,
      onUpdate: (self) => {
        group.rotation.z = self.progress * 1.1;
        const s = 1 - self.progress * 0.35;
        group.scale.setScalar(s);
        points.scale.setScalar(1 + self.progress * 0.4);
        renderer.domElement.style.opacity = String(1 - self.progress * 0.8);
      },
    });

    return () => {
      cancelAnimationFrame(frameId);
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("resize", resize);
      st.kill();
      renderer.dispose();
      geo.dispose();
      geo2.dispose();
      ringGeo.dispose();
      pGeo.dispose();
      lineMat.dispose();
      lineMat2.dispose();
      ringMat.dispose();
      pMat.dispose();
      if (mount.contains(renderer.domElement)) mount.removeChild(renderer.domElement);
    };
  }, [containerSelector]);

  return <div ref={mountRef} className="absolute inset-0" />;
}
