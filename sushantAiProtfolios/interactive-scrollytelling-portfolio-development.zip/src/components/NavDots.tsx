import { useEffect, useState } from "react";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { getLenis } from "../lib/useSmoothScroll";

const sections = [
  { id: "hero", label: "Intro" },
  { id: "profile", label: "Profile" },
  { id: "experience", label: "Experience" },
  { id: "projects", label: "Projects" },
  { id: "skills", label: "Skills" },
  { id: "achievements", label: "Achievements" },
  { id: "education", label: "Education" },
  { id: "contact", label: "Contact" },
];

export default function NavDots() {
  const [active, setActive] = useState("hero");

  useEffect(() => {
    const triggers = sections.map(({ id }) =>
      ScrollTrigger.create({
        trigger: `#${id}`,
        start: "top center",
        end: "bottom center",
        onToggle: (self) => {
          if (self.isActive) setActive(id);
        },
      })
    );
    return () => triggers.forEach((t) => t.kill());
  }, []);

  const go = (id: string) => {
    const lenis = getLenis();
    const el = document.getElementById(id);
    if (!el) return;
    if (lenis) lenis.scrollTo(el, { duration: 1.3 });
    else el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <nav className="fixed right-5 md:right-7 top-1/2 -translate-y-1/2 z-40 hidden sm:flex flex-col items-end gap-3">
      {sections.map((s) => (
        <button
          key={s.id}
          data-cursor="link"
          onClick={() => go(s.id)}
          className="group flex items-center gap-2"
          aria-label={s.label}
        >
          <span
            className="text-[10px] uppercase tracking-[0.18em] opacity-0 group-hover:opacity-100 transition-opacity duration-300 font-mono-ish"
            style={{ color: "var(--ink)" }}
          >
            {s.label}
          </span>
          <span
            className="block rounded-full transition-all duration-300"
            style={{
              width: active === s.id ? 10 : 6,
              height: active === s.id ? 10 : 6,
              background: active === s.id ? "var(--rust)" : "rgba(22,21,15,0.35)",
            }}
          />
        </button>
      ))}
    </nav>
  );
}
