import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { profile } from "../data/resume";

gsap.registerPlugin(ScrollTrigger);

export default function Profile() {
  const root = useRef<HTMLDivElement>(null);
  const blobRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.to(".word", {
        opacity: 1,
        color: "var(--ink)",
        stagger: 0.012,
        ease: "none",
        scrollTrigger: {
          trigger: ".profile-text",
          start: "top 75%",
          end: "bottom 55%",
          scrub: true,
        },
      });

      gsap.fromTo(
        ".stat-row",
        { opacity: 0, x: -24 },
        {
          opacity: 1,
          x: 0,
          stagger: 0.12,
          duration: 0.8,
          ease: "power3.out",
          scrollTrigger: { trigger: ".stat-row", start: "top 85%" },
        }
      );

      gsap.to(blobRef.current, {
        rotate: 25,
        scale: 1.08,
        transformOrigin: "50% 50%",
        ease: "none",
        scrollTrigger: {
          trigger: root.current,
          start: "top bottom",
          end: "bottom top",
          scrub: 1,
        },
      });
    }, root);
    return () => ctx.revert();
  }, []);

  const words = profile.blurb.split(" ");

  return (
    <section id="profile" ref={root} className="relative py-28 md:py-40 px-6 md:px-14" style={{ background: "var(--cream)" }}>
      <svg
        ref={blobRef}
        className="absolute -right-24 top-10 w-[420px] h-[420px] opacity-[0.35] pointer-events-none hidden md:block"
        viewBox="0 0 200 200"
      >
        <path
          fill="none"
          stroke="var(--rust)"
          strokeWidth="0.6"
          d="M45,-58.4C58.6,-49.5,69.6,-35.9,73.6,-20.5C77.6,-5.1,74.6,12,67.1,26.5C59.6,41,47.6,52.9,33.5,60.5C19.4,68.1,3.2,71.4,-13.1,70.2C-29.4,69,-45.8,63.3,-57.4,52.1C-69,40.9,-75.8,24.2,-76.8,7.1C-77.8,-10,-73,-27.5,-62.6,-40.3C-52.2,-53.1,-36.2,-61.2,-20.3,-67.9C-4.4,-74.6,11.4,-79.9,25.8,-75.9C40.2,-71.9,47.4,-67.3,45,-58.4Z"
          transform="translate(100 100)"
        />
        <circle cx="100" cy="100" r="54" fill="none" stroke="var(--ink)" strokeOpacity="0.25" strokeWidth="0.5" />
      </svg>

      <div className="grid md:grid-cols-[120px_1fr] gap-8 md:gap-16 max-w-6xl mx-auto relative">
        <div className="flex md:flex-col items-start gap-3 md:gap-6">
          <span className="font-mono-ish text-xs tracking-[0.2em] uppercase text-moss">01</span>
          <span
            className="font-mono-ish text-xs tracking-[0.3em] uppercase md:[writing-mode:vertical-rl] md:rotate-180"
            style={{ color: "var(--ink-soft)" }}
          >
            Profile
          </span>
        </div>

        <div>
          <p className="font-mono-ish text-[11px] md:text-xs uppercase tracking-[0.25em] mb-4" style={{ color: "var(--rust)" }}>
            {profile.name} — {profile.role}
          </p>
          <h2 className="font-display text-3xl md:text-5xl mb-10 leading-tight" style={{ color: "var(--ink)" }}>
            A developer who also{" "}
            <span className="text-rust italic">sculpts worlds.</span>
          </h2>

          <p className="profile-text font-display text-2xl md:text-[2.4rem] leading-[1.35] md:leading-[1.4] max-w-4xl">
            {words.map((w, i) => (
              <span key={i} className="word" style={{ opacity: 0.15, color: "var(--ink-soft)" }}>
                {w}{" "}
              </span>
            ))}
          </p>

          <div className="mt-16 flex flex-col gap-4 max-w-md">
            {[
              ["Based in", profile.location],
              ["Focus", "MERN · Game Dev · 3D Art"],
              ["Status", "Open to internships & collabs"],
            ].map(([label, value]) => (
              <div key={label} className="stat-row flex items-center justify-between border-b pb-3" style={{ borderColor: "var(--line)" }}>
                <span className="font-mono-ish text-xs uppercase tracking-[0.2em]" style={{ color: "var(--ink-soft)" }}>
                  {label}
                </span>
                <span className="font-medium text-sm md:text-base">{value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
