import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { skills } from "../data/resume";

gsap.registerPlugin(ScrollTrigger);

const CATEGORIES = Object.keys(skills) as (keyof typeof skills)[];
const PALETTE = ["#c1532e", "#4a5d44", "#16150f", "#9c6b2f", "#5b4a8a", "#2f6b63"];

type Node = {
  category: number;
  label: string;
  homeX: number;
  homeY: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  phase: number;
};

export default function SkillsConstellation() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [activeIndex, setActiveIndex] = useState(0);
  const activeRef = useRef(0);
  const mouseRef = useRef({ x: -9999, y: -9999 });

  useEffect(() => {
    const canvas = canvasRef.current!;
    const section = sectionRef.current!;
    const ctx2d = canvas.getContext("2d")!;

    let width = 0;
    let height = 0;
    let dpr = Math.min(window.devicePixelRatio || 1, 2);

    const clusterCenters: { x: number; y: number }[] = [];

    const nodes: Node[] = [];

    const layout = () => {
      width = section.clientWidth;
      height = window.innerHeight;
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      canvas.style.width = width + "px";
      canvas.style.height = height + "px";
      ctx2d.setTransform(dpr, 0, 0, dpr, 0, 0);

      clusterCenters.length = 0;
      const cx = width / 2;
      const cy = height / 2;
      const radius = Math.min(width, height) * 0.3;
      CATEGORIES.forEach((_, i) => {
        const angle = (i / CATEGORIES.length) * Math.PI * 2 - Math.PI / 2;
        clusterCenters.push({
          x: cx + Math.cos(angle) * radius,
          y: cy + Math.sin(angle) * radius,
        });
      });

      nodes.length = 0;
      CATEGORIES.forEach((cat, ci) => {
        const center = clusterCenters[ci];
        const items = skills[cat];
        items.forEach((label, idx) => {
          const a = (idx / items.length) * Math.PI * 2;
          const d = 38 + Math.random() * 46;
          const hx = center.x + Math.cos(a) * d;
          const hy = center.y + Math.sin(a) * d;
          nodes.push({
            category: ci,
            label,
            homeX: hx,
            homeY: hy,
            x: hx,
            y: hy,
            vx: 0,
            vy: 0,
            r: 3 + Math.random() * 1.6,
            phase: Math.random() * Math.PI * 2,
          });
        });
      });
    };

    layout();

    const onMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouseRef.current.x = e.clientX - rect.left;
      mouseRef.current.y = e.clientY - rect.top;
    };
    const onMouseLeave = () => {
      mouseRef.current.x = -9999;
      mouseRef.current.y = -9999;
    };
    canvas.addEventListener("mousemove", onMouseMove);
    canvas.addEventListener("mouseleave", onMouseLeave);

    const onResize = () => layout();
    window.addEventListener("resize", onResize);

    const cam = { x: 0, y: 0, zoom: 1 };
    let t = 0;

    const render = () => {
      t += 0.012;
      const active = activeRef.current;
      const target = clusterCenters[active] || { x: width / 2, y: height / 2 };
      const tx = width / 2 - target.x;
      const ty = height / 2 - target.y;
      cam.x += (tx - cam.x) * 0.045;
      cam.y += (ty - cam.y) * 0.045;
      cam.zoom += (1.35 - cam.zoom) * 0.045;

      ctx2d.clearRect(0, 0, width, height);
      ctx2d.save();
      ctx2d.translate(width / 2, height / 2);
      ctx2d.scale(cam.zoom, cam.zoom);
      ctx2d.translate(-width / 2 + cam.x, -height / 2 + cam.y);

      const mouse = mouseRef.current;

      // physics
      nodes.forEach((n) => {
        const floatX = Math.sin(t + n.phase) * 3;
        const floatY = Math.cos(t * 0.8 + n.phase) * 3;
        let tx2 = n.homeX + floatX;
        let ty2 = n.homeY + floatY;

        const dx = n.x - mouse.x;
        const dy = n.y - mouse.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 70) {
          const force = (70 - dist) / 70;
          tx2 += (dx / (dist || 1)) * force * 40;
          ty2 += (dy / (dist || 1)) * force * 40;
        }

        n.vx += (tx2 - n.x) * 0.02;
        n.vy += (ty2 - n.y) * 0.02;
        n.vx *= 0.82;
        n.vy *= 0.82;
        n.x += n.vx;
        n.y += n.vy;
      });

      // connecting lines within category
      for (let ci = 0; ci < CATEGORIES.length; ci++) {
        const catNodes = nodes.filter((n) => n.category === ci);
        const isActive = ci === active;
        ctx2d.strokeStyle = PALETTE[ci % PALETTE.length];
        ctx2d.globalAlpha = isActive ? 0.45 : 0.08;
        ctx2d.lineWidth = isActive ? 0.9 : 0.6;
        for (let i = 0; i < catNodes.length; i++) {
          for (let j = i + 1; j < catNodes.length; j++) {
            const a = catNodes[i];
            const b = catNodes[j];
            const d = Math.hypot(a.x - b.x, a.y - b.y);
            if (d < 120) {
              ctx2d.beginPath();
              ctx2d.moveTo(a.x, a.y);
              ctx2d.lineTo(b.x, b.y);
              ctx2d.stroke();
            }
          }
        }
        // line to center
        const center = clusterCenters[ci];
        ctx2d.globalAlpha = isActive ? 0.35 : 0.06;
        catNodes.forEach((n) => {
          ctx2d.beginPath();
          ctx2d.moveTo(center.x, center.y);
          ctx2d.lineTo(n.x, n.y);
          ctx2d.stroke();
        });
      }

      // nodes
      nodes.forEach((n) => {
        const isActive = n.category === active;
        ctx2d.globalAlpha = isActive ? 1 : 0.22;
        ctx2d.fillStyle = PALETTE[n.category % PALETTE.length];
        ctx2d.beginPath();
        ctx2d.arc(n.x, n.y, isActive ? n.r + 1.4 : n.r, 0, Math.PI * 2);
        ctx2d.fill();

        if (isActive) {
          ctx2d.globalAlpha = 0.9;
          ctx2d.fillStyle = "#16150f";
          ctx2d.font = "11px 'Space Grotesk', sans-serif";
          ctx2d.textAlign = "center";
          ctx2d.fillText(n.label, n.x, n.y - 10);
        }
      });

      // cluster center labels (dim)
      clusterCenters.forEach((c, i) => {
        ctx2d.globalAlpha = i === active ? 0 : 0.5;
        ctx2d.fillStyle = "#3c3a32";
        ctx2d.font = "10px 'Space Grotesk', sans-serif";
        ctx2d.textAlign = "center";
        ctx2d.fillText(CATEGORIES[i], c.x, c.y + 2);
      });

      ctx2d.restore();
      frame = requestAnimationFrame(render);
    };
    let frame = requestAnimationFrame(render);

    const st = ScrollTrigger.create({
      trigger: section,
      start: "top top",
      end: () => `+=${window.innerHeight * (CATEGORIES.length * 0.85 + 0.4)}`,
      scrub: 0.8,
      pin: true,
      anticipatePin: 1,
      invalidateOnRefresh: true,
      onUpdate: (self) => {
        const idx = Math.min(CATEGORIES.length - 1, Math.floor(self.progress * CATEGORIES.length));
        if (idx !== activeRef.current) {
          activeRef.current = idx;
          setActiveIndex(idx);
        }
      },
    });

    return () => {
      cancelAnimationFrame(frame);
      canvas.removeEventListener("mousemove", onMouseMove);
      canvas.removeEventListener("mouseleave", onMouseLeave);
      window.removeEventListener("resize", onResize);
      st.kill();
    };
  }, []);

  return (
    <section id="skills" ref={sectionRef} className="relative h-screen overflow-hidden" style={{ background: "var(--cream)" }}>
      <canvas ref={canvasRef} className="absolute inset-0" data-cursor="drag" />

      <div className="absolute top-8 md:top-12 left-6 md:left-14 right-6 md:right-14 flex items-end justify-between z-10 flex-wrap gap-4 pointer-events-none">
        <h2 className="font-display text-3xl md:text-5xl" style={{ color: "var(--ink)" }}>
          A constellation of <span className="text-rust italic">skills.</span>
        </h2>
        <span className="font-mono-ish text-xs tracking-[0.2em] uppercase text-moss">04 / Technical Skills</span>
      </div>

      <div className="absolute bottom-10 left-6 md:left-14 z-10 pointer-events-none max-w-sm">
        <span className="font-mono-ish text-[11px] uppercase tracking-[0.2em]" style={{ color: PALETTE[activeIndex % PALETTE.length] }}>
          0{activeIndex + 1} — {CATEGORIES[activeIndex]}
        </span>
        <p className="font-display text-xl md:text-2xl mt-2" style={{ color: "var(--ink)" }}>
          {skills[CATEGORIES[activeIndex]].join(" · ")}
        </p>
      </div>

      <div className="absolute bottom-10 right-6 md:right-14 z-10 flex gap-1.5">
        {CATEGORIES.map((c, i) => (
          <span
            key={c}
            className="w-6 h-1 rounded-full transition-colors duration-300"
            style={{ background: i === activeIndex ? "var(--rust)" : "var(--line)" }}
          />
        ))}
      </div>
    </section>
  );
}
