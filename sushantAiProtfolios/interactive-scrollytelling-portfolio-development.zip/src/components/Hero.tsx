import { useEffect, useRef } from "react";
import gsap from "gsap";
import HeroField from "./HeroField";
import { profile } from "../data/resume";

export default function Hero() {
  const root = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ delay: 2.3 });
      tl.to(".hero-line .char", {
        yPercent: 0,
        stagger: 0.02,
        duration: 1,
        ease: "power4.out",
      })
        .to(".hero-sub", { opacity: 1, y: 0, duration: 0.9, ease: "power3.out" }, "-=0.5")
        .to(".hero-tag", { opacity: 1, y: 0, stagger: 0.07, duration: 0.6, ease: "power3.out" }, "-=0.6")
        .to(".hero-meta", { opacity: 1, duration: 0.8 }, "-=0.4")
        .to(".scroll-cue", { opacity: 1, duration: 0.8 }, "-=0.3");
    }, root);
    return () => ctx.revert();
  }, []);

  const renderChars = (text: string) => (
    <span className="overflow-hidden inline-flex">
      {text.split("").map((c, i) => (
        <span
          key={i}
          className="char inline-block"
          style={{ transform: "translateY(110%)" }}
        >
          {c === " " ? "\u00A0" : c}
        </span>
      ))}
    </span>
  );

  return (
    <section id="hero" ref={root} className="relative h-[100svh] w-full overflow-hidden" style={{ background: "var(--cream)" }}>
      <HeroField containerSelector="#hero" />

      <div className="absolute inset-0 flex flex-col justify-between px-6 md:px-14 py-8 md:py-12 pointer-events-none">
        <div className="hero-meta opacity-0 flex justify-between items-start font-mono-ish text-[11px] md:text-xs tracking-[0.2em] uppercase">
          <span className="max-w-[45%] leading-relaxed">
            {profile.name}
            <br />
            Portfolio — 2026
          </span>
          <span className="text-right">{profile.location}</span>
        </div>

        <div>
          <h1 className="font-display leading-[0.92] text-[13vw] md:text-[7.2vw] font-medium" style={{ color: "var(--ink)" }}>
            <span className="sr-only">{profile.name}</span>
            <div className="hero-line block">{renderChars("Sushant")}</div>
            <div className="hero-line block text-rust">{renderChars("Chauhan")}</div>
          </h1>

          <p className="hero-sub opacity-0 translate-y-6 mt-6 max-w-xl text-base md:text-lg" style={{ color: "var(--ink-soft)" }}>
            Full-stack developer &amp; 3D environment designer crafting clean code
            and quiet, considered worlds — from REST APIs to rendered forests.
          </p>

          <div className="flex flex-wrap gap-2 mt-6">
            {profile.tags.map((t) => (
              <span
                key={t}
                className="hero-tag opacity-0 translate-y-4 text-[11px] md:text-xs uppercase tracking-wider px-3 py-1.5 rounded-full border font-mono-ish"
                style={{ borderColor: "var(--line)", color: "var(--ink-soft)" }}
              >
                {t}
              </span>
            ))}
          </div>
        </div>

        <div className="scroll-cue opacity-0 flex items-center justify-between font-mono-ish text-[11px] uppercase tracking-[0.2em]">
          <span className="flex items-center gap-2">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-rust blinking" />
            Available for opportunities
          </span>
          <span className="flex flex-col items-center gap-2">
            <span>Scroll</span>
            <span className="w-px h-10 bg-current opacity-40 relative overflow-hidden">
              <span className="absolute inset-x-0 top-0 h-3 bg-rust animate-[scrollDown_1.6s_ease-in-out_infinite]" />
            </span>
          </span>
        </div>
      </div>
      <style>{`
        @keyframes scrollDown {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(300%); }
        }
      `}</style>
    </section>
  );
}
