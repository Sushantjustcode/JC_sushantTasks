import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { strengths } from "../data/resume";

gsap.registerPlugin(ScrollTrigger);

export default function Strengths() {
  const track = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const tween = gsap.to(track.current, {
        xPercent: -50,
        duration: 26,
        ease: "linear",
        repeat: -1,
      });

      const st = ScrollTrigger.create({
        start: 0,
        end: "max",
        onUpdate: (self) => {
          tween.timeScale(self.direction === -1 ? -1.4 : 1);
        },
      });

      return () => {
        st.kill();
      };
    });
    return () => ctx.revert();
  }, []);

  const loopItems = [...strengths, ...strengths];

  return (
    <section className="relative py-16 md:py-20 overflow-hidden border-y" style={{ background: "var(--ink)", borderColor: "rgba(243,239,230,0.1)" }}>
      <div ref={track} className="marquee-track">
        {loopItems.map((s, i) => (
          <div key={i} className="flex items-center gap-8 pr-8">
            <span className="font-display text-3xl md:text-5xl whitespace-nowrap" style={{ color: "var(--cream)" }}>
              {s}
            </span>
            <span className="w-2 h-2 rounded-full bg-rust shrink-0" />
          </div>
        ))}
      </div>
    </section>
  );
}
