import type { CSSProperties } from "react";

type IconType = "code" | "book" | "window" | "forest" | "cube";

export default function ProjectIcon({
  type,
  className,
  style,
}: {
  type: IconType;
  className?: string;
  style?: CSSProperties;
}) {
  const common = {
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.1,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
  };

  switch (type) {
    case "code":
      return (
        <svg viewBox="0 0 120 120" className={className} style={style} {...common}>
          <rect x="10" y="18" width="100" height="84" rx="4" />
          <path d="M10 36h100" />
          <circle cx="22" cy="27" r="2" fill="currentColor" stroke="none" />
          <circle cx="32" cy="27" r="2" fill="currentColor" stroke="none" />
          <path d="M34 58 L22 70 L34 82" />
          <path d="M62 58 L74 70 L62 82" />
          <path d="M54 50 L46 90" />
        </svg>
      );
    case "book":
      return (
        <svg viewBox="0 0 120 120" className={className} style={style} {...common}>
          <path d="M60 30c-10-10-30-12-44-8v62c14-4 34-2 44 8" />
          <path d="M60 30c10-10 30-12 44-8v62c-14-4-34-2-44 8" />
          <path d="M60 30v70" />
          <path d="M26 44c8-2 18-2 24 2" />
          <path d="M26 58c8-2 18-2 24 2" />
        </svg>
      );
    case "window":
      return (
        <svg viewBox="0 0 120 120" className={className} style={style} {...common}>
          <rect x="12" y="22" width="96" height="76" rx="5" />
          <path d="M12 40h96" />
          <circle cx="24" cy="31" r="2" fill="currentColor" stroke="none" />
          <circle cx="34" cy="31" r="2" fill="currentColor" stroke="none" />
          <circle cx="44" cy="31" r="2" fill="currentColor" stroke="none" />
          <path d="M30 60h30" />
          <path d="M30 72h50" />
          <path d="M30 84h20" />
        </svg>
      );
    case "forest":
      return (
        <svg viewBox="0 0 120 120" className={className} style={style} {...common}>
          <path d="M35 70 L50 38 L65 70 Z" />
          <path d="M28 85 L50 48 L72 85 Z" />
          <path d="M70 80 L86 50 L102 80 Z" />
          <path d="M50 85v16" />
          <path d="M86 80v21" />
          <circle cx="94" cy="26" r="9" />
          <path d="M10 101h100" />
        </svg>
      );
    case "cube":
    default:
      return (
        <svg viewBox="0 0 120 120" className={className} style={style} {...common}>
          <path d="M60 14 L104 38 V82 L60 106 L16 82 V38 Z" />
          <path d="M16 38 L60 62 L104 38" />
          <path d="M60 62V106" />
          <path d="M38 26 L82 50" />
        </svg>
      );
  }
}
