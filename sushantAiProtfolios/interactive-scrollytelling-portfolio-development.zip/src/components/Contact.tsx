import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { profile } from "../data/resume";

gsap.registerPlugin(ScrollTrigger);

const links = [
  { label: "Email", href: profile.email, value: "Say hello" },
  { label: "LinkedIn", href: profile.linkedin, value: "Connect" },
  { label: "Portfolio", href: profile.portfolio, value: "Browse work" },
];

function Magnetic({ children }: { children: React.ReactNode }) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const xTo = gsap.quickTo(el, "x", { duration: 0.5, ease: "power3.out" });
    const yTo = gsap.quickTo(el, "y", { duration: 0.5, ease: "power3.out" });

    const move = (e: MouseEvent) => {
      const r = el.getBoundingClientRect();
      const relX = e.clientX - r.left - r.width / 2;
      const relY = e.clientY - r.top - r.height / 2;
      xTo(relX * 0.4);
      yTo(relY * 0.5);
    };
    const leave = () => {
      xTo(0);
      yTo(0);
    };
    el.addEventListener("mousemove", move);
    el.addEventListener("mouseleave", leave);
    return () => {
      el.removeEventListener("mousemove", move);
      el.removeEventListener("mouseleave", leave);
    };
  }, []);

  return <div ref={ref}>{children}</div>;
}

export default function Contact() {
  const root = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.to(".contact-char", {
        yPercent: 0,
        stagger: 0.015,
        duration: 1,
        ease: "power4.out",
        scrollTrigger: { trigger: root.current, start: "top 70%" },
      });
      gsap.fromTo(
        ".contact-link",
        { opacity: 0, y: 24 },
        { opacity: 1, y: 0, stagger: 0.12, duration: 0.8, ease: "power3.out", scrollTrigger: { trigger: ".contact-links", start: "top 85%" } }
      );
    }, root);
    return () => ctx.revert();
  }, []);

  const headline = "Let's build something.";

  return (
    <section id="contact" ref={root} className="relative pt-28 md:pt-40 pb-14 px-6 md:px-14" style={{ background: "var(--ink)" }}>
      <div className="max-w-6xl mx-auto">
        <span className="font-mono-ish text-xs tracking-[0.2em] uppercase" style={{ color: "var(--rust-soft)" }}>
          07 / Get in touch
        </span>

        <h2 className="font-display text-[9vw] sm:text-[7vw] md:text-[5.2vw] leading-[1.05] mt-6 mb-16 md:mb-24 flex flex-wrap" style={{ color: "var(--cream)" }}>
          {headline.split(" ").map((word, wi) => (
            <span key={wi} className="inline-flex whitespace-nowrap mr-[0.28em]">
              {word.split("").map((c, i) => (
                <span key={i} className="overflow-hidden inline-flex align-top">
                  <span className="contact-char inline-block" style={{ transform: "translateY(110%)" }}>
                    {c}
                  </span>
                </span>
              ))}
            </span>
          ))}
        </h2>

        <div className="contact-links grid sm:grid-cols-3 gap-6 md:gap-10 mb-24">
          {links.map((l) => (
            <a
              key={l.label}
              href={l.href}
              target="_blank"
              rel="noreferrer"
              data-cursor="link"
              className="contact-link group block border-t pt-6"
              style={{ borderColor: "rgba(243,239,230,0.18)" }}
            >
              <Magnetic>
                <div className="flex flex-col gap-2">
                  <span className="font-mono-ish text-[11px] uppercase tracking-[0.2em]" style={{ color: "var(--rust-soft)" }}>
                    {l.label}
                  </span>
                  <span className="font-display text-2xl md:text-3xl flex items-center gap-2 transition-transform duration-300 group-hover:translate-x-2" style={{ color: "var(--cream)" }}>
                    {l.value}
                    <span aria-hidden>↗</span>
                  </span>
                </div>
              </Magnetic>
            </a>
          ))}
        </div>

        <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 border-t pt-8" style={{ borderColor: "rgba(243,239,230,0.12)" }}>
          <div>
            <p className="font-display text-xl" style={{ color: "var(--cream)" }}>
              {profile.name}
            </p>
            <p className="text-sm mt-1" style={{ color: "rgba(243,239,230,0.55)" }}>
              {profile.location} · {profile.phone}
            </p>
          </div>
          <p className="font-mono-ish text-[11px] uppercase tracking-[0.2em]" style={{ color: "rgba(243,239,230,0.4)" }}>
            Designed &amp; built with React, GSAP &amp; Three.js — {new Date().getFullYear()}
          </p>
        </div>
      </div>
    </section>
  );
}
