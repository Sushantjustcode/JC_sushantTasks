import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { achievements } from "../data/resume";

gsap.registerPlugin(ScrollTrigger);

export default function Achievements() {
  const root = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.fromTo(
        ".badge-hex",
        { scale: 0, rotate: -60, opacity: 0 },
        {
          scale: 1,
          rotate: 0,
          opacity: 1,
          duration: 0.9,
          stagger: 0.12,
          ease: "back.out(2.2)",
          scrollTrigger: { trigger: ".badge-row", start: "top 78%" },
        }
      );

      gsap.to(".badge-hex", {
        y: -10,
        duration: 2.4,
        ease: "sine.inOut",
        yoyo: true,
        repeat: -1,
        stagger: { each: 0.3, from: "random" },
      });

      gsap.fromTo(
        ".ach-title",
        { opacity: 0, y: 30 },
        { opacity: 1, y: 0, duration: 1, ease: "power3.out", scrollTrigger: { trigger: ".ach-title", start: "top 85%" } }
      );
    }, root);
    return () => ctx.revert();
  }, []);

  return (
    <section id="achievements" ref={root} className="relative py-28 md:py-40 px-6 md:px-14" style={{ background: "var(--cream-deep)" }}>
      <div className="max-w-6xl mx-auto">
        <div className="flex items-end justify-between mb-20 flex-wrap gap-4">
          <h2 className="ach-title font-display text-3xl md:text-5xl" style={{ color: "var(--ink)" }}>
            Wins worth <span className="text-rust italic">mentioning.</span>
          </h2>
          <span className="font-mono-ish text-xs tracking-[0.2em] uppercase text-moss">05 / Achievements</span>
        </div>

        <div className="badge-row flex flex-wrap justify-center gap-x-10 gap-y-16 md:gap-x-14">
          {achievements.map((a, i) => (
            <div key={a.title} className="flex flex-col items-center text-center w-36 md:w-44">
              <div className="badge-hex relative" data-cursor="link">
                <svg viewBox="0 0 100 112" className="w-24 h-28 md:w-28 md:h-32 drop-shadow-sm">
                  <polygon
                    points="50,2 95,27 95,85 50,110 5,85 5,27"
                    fill={i % 2 === 0 ? "var(--ink)" : "var(--rust)"}
                    opacity="0.95"
                  />
                  <polygon
                    points="50,12 87,32 87,80 50,100 13,80 13,32"
                    fill="none"
                    stroke="var(--cream)"
                    strokeOpacity="0.5"
                    strokeWidth="0.7"
                  />
                  <text x="50" y="62" textAnchor="middle" fontSize="22" fill="var(--cream)" fontFamily="Fraunces, serif">
                    {a.year ? a.year.slice(2) : "★"}
                  </text>
                </svg>
              </div>
              <h3 className="font-display text-base md:text-lg mt-4 leading-snug" style={{ color: "var(--ink)" }}>
                {a.title}
              </h3>
              <p className="text-xs md:text-sm mt-1" style={{ color: "var(--ink-soft)" }}>
                {a.detail}
              </p>
            </div>
          ))}
        </div>

        <p className="text-center mt-20 italic text-sm" style={{ color: "var(--ink-soft)" }}>
          References and additional project links available on request.
        </p>
      </div>
    </section>
  );
}
