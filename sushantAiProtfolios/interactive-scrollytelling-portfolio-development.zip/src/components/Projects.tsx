import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { projects } from "../data/resume";
import ProjectIcon from "./ProjectIcon";

gsap.registerPlugin(ScrollTrigger);

export default function Projects() {
  const container = useRef<HTMLDivElement>(null);
  const track = useRef<HTMLDivElement>(null);
  const progressRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const trackEl = track.current!;
      const getTotalScroll = () => trackEl.scrollWidth - window.innerWidth;

      const tween = gsap.to(trackEl, {
        x: () => -getTotalScroll(),
        ease: "none",
        scrollTrigger: {
          trigger: container.current,
          start: "top top",
          end: () => `+=${getTotalScroll() + window.innerHeight * 0.4}`,
          scrub: 0.7,
          pin: true,
          anticipatePin: 1,
          invalidateOnRefresh: true,
          onUpdate: (self) => {
            gsap.set(progressRef.current, { scaleX: self.progress });
          },
        },
      });

      gsap.utils.toArray<HTMLElement>(".proj-icon").forEach((icon, i) => {
        gsap.to(icon, {
          rotate: i % 2 === 0 ? 20 : -20,
          scale: 1.08,
          ease: "none",
          scrollTrigger: {
            trigger: container.current,
            start: "top top",
            end: () => `+=${getTotalScroll() + window.innerHeight * 0.4}`,
            scrub: 1.4,
          },
        });
      });

      return () => tween.kill();
    }, container);
    return () => ctx.revert();
  }, []);

  return (
    <section id="projects" ref={container} className="relative h-screen overflow-hidden" style={{ background: "var(--cream)" }}>
      <div className="absolute top-8 md:top-12 left-6 md:left-14 right-6 md:right-14 flex items-end justify-between z-10 flex-wrap gap-4">
        <h2 className="font-display text-3xl md:text-5xl" style={{ color: "var(--ink)" }}>
          Things <span className="text-rust italic">I built.</span>
        </h2>
        <span className="font-mono-ish text-xs tracking-[0.2em] uppercase text-moss">03 / Selected Projects — scroll →</span>
      </div>

      <div ref={track} className="flex h-full items-center gap-6 md:gap-10 pl-6 md:pl-14 pr-[20vw] pt-16">
        {projects.map((p) => (
          <article
            key={p.title}
            data-cursor="link"
            className="group shrink-0 w-[82vw] sm:w-[60vw] md:w-[38vw] lg:w-[30vw] h-[62vh] md:h-[68vh] rounded-[1.5rem] border flex flex-col justify-between p-7 md:p-9 relative overflow-hidden transition-colors duration-500 hover:border-rust"
            style={{ borderColor: "var(--line)", background: "var(--cream-deep)" }}
          >
            <div className="flex items-start justify-between">
              <ProjectIcon
                type={p.icon as "code" | "book" | "window" | "forest" | "cube"}
                className="proj-icon w-16 h-16 md:w-20 md:h-20"
                style={{ color: "var(--rust)" }}
              />
              <span className="font-mono-ish text-xs" style={{ color: "var(--ink-soft)" }}>
                0{projects.indexOf(p) + 1}
              </span>
            </div>

            <div>
              <h3 className="font-display text-2xl md:text-3xl mb-3 leading-snug" style={{ color: "var(--ink)" }}>
                {p.title}
              </h3>
              <div className="flex flex-wrap gap-1.5 mb-4">
                {p.tags.map((t) => (
                  <span
                    key={t}
                    className="text-[10px] uppercase tracking-wider px-2 py-1 rounded-full border font-mono-ish"
                    style={{ borderColor: "var(--line)", color: "var(--ink-soft)" }}
                  >
                    {t}
                  </span>
                ))}
              </div>
              <ul className="flex flex-col gap-1.5 opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-500 max-h-0 group-hover:max-h-40 overflow-hidden">
                {p.points.map((pt) => (
                  <li key={pt} className="text-[13px] leading-snug flex gap-2" style={{ color: "var(--ink-soft)" }}>
                    <span className="mt-1.5 w-1 h-1 rounded-full bg-rust shrink-0" />
                    {pt}
                  </li>
                ))}
              </ul>
            </div>
          </article>
        ))}

        <div className="shrink-0 w-[40vw] flex flex-col items-start justify-center pr-20">
          <span className="font-mono-ish text-xs uppercase tracking-[0.2em] text-moss mb-3">That's the showreel</span>
          <p className="font-display text-2xl md:text-3xl max-w-sm">More in the works — always building something new.</p>
        </div>
      </div>

      <div className="absolute bottom-8 left-6 md:left-14 right-6 md:right-14 h-px" style={{ background: "var(--line)" }}>
        <div ref={progressRef} className="h-full origin-left bg-rust" style={{ transform: "scaleX(0)" }} />
      </div>
    </section>
  );
}
