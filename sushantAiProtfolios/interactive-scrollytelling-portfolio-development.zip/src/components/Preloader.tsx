import { useEffect, useRef, useState } from "react";
import gsap from "gsap";

export default function Preloader({ onDone }: { onDone: () => void }) {
  const wrap = useRef<HTMLDivElement>(null);
  const numRef = useRef<HTMLDivElement>(null);
  const barRef = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    document.body.style.overflow = "hidden";
    const counter = { val: 0 };
    const tl = gsap.timeline({
      onComplete: () => {
        document.body.style.overflow = "";
        setVisible(false);
        onDone();
      },
    });

    tl.to(counter, {
      val: 100,
      duration: 1.8,
      ease: "power2.inOut",
      onUpdate: () => {
        if (numRef.current) numRef.current.textContent = String(Math.floor(counter.val)).padStart(3, "0");
        if (barRef.current) gsap.set(barRef.current, { scaleX: counter.val / 100 });
      },
    })
      .to(".pre-line", { scaleX: 1, duration: 0.5, ease: "power3.out" }, "<0.1")
      .to(".pre-word .char", {
        yPercent: 0,
        stagger: 0.015,
        duration: 0.7,
        ease: "power4.out",
      }, "-=1.5")
      .to(wrap.current, { yPercent: -100, duration: 0.9, ease: "power4.inOut", delay: 0.3 });

    return () => {
      tl.kill();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (!visible) return null;

  const word = "SUSHANT CHAUHAN";

  return (
    <div
      ref={wrap}
      className="fixed inset-0 z-[90] flex flex-col items-center justify-center"
      style={{ background: "var(--ink)" }}
    >
      <div className="overflow-hidden pre-word flex flex-wrap justify-center px-6 max-w-[92vw]">
        {word.split("").map((c, i) => (
          <span
            key={i}
            className="char inline-block text-[8.5vw] md:text-[4.4vw] font-display leading-none"
            style={{ color: "var(--cream)", transform: "translateY(110%)" }}
          >
            {c === " " ? "\u00A0" : c}
          </span>
        ))}
      </div>
      <div className="mt-8 flex items-center gap-4 w-56">
        <div className="h-px flex-1 bg-white/20 relative overflow-hidden">
          <div ref={barRef} className="absolute inset-0 origin-left bg-rust" style={{ transform: "scaleX(0)" }} />
        </div>
        <div ref={numRef} className="font-mono-ish text-xs tracking-widest" style={{ color: "var(--cream)" }}>
          000
        </div>
      </div>
    </div>
  );
}
