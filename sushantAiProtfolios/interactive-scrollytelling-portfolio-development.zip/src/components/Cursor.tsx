import { useEffect, useRef } from "react";
import gsap from "gsap";

export default function Cursor() {
  const dot = useRef<HTMLDivElement>(null);
  const ring = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!dot.current || !ring.current) return;
    const xDot = gsap.quickTo(dot.current, "x", { duration: 0.12, ease: "power3.out" });
    const yDot = gsap.quickTo(dot.current, "y", { duration: 0.12, ease: "power3.out" });
    const xRing = gsap.quickTo(ring.current, "x", { duration: 0.45, ease: "power3.out" });
    const yRing = gsap.quickTo(ring.current, "y", { duration: 0.45, ease: "power3.out" });

    const move = (e: MouseEvent) => {
      xDot(e.clientX);
      yDot(e.clientY);
      xRing(e.clientX);
      yRing(e.clientY);
    };
    window.addEventListener("mousemove", move);

    const onEnter = (e: Event) => {
      const el = e.target as HTMLElement;
      if (el.closest?.("[data-cursor='link']")) {
        gsap.to(ring.current, { width: 64, height: 64, borderColor: "transparent", backgroundColor: "rgba(22,21,15,0.08)", duration: 0.25 });
      } else if (el.closest?.("[data-cursor='drag']")) {
        gsap.to(ring.current, { width: 90, height: 90, borderColor: "transparent", backgroundColor: "rgba(193,83,46,0.12)", duration: 0.25 });
      }
    };
    const onLeave = () => {
      gsap.to(ring.current, { width: 34, height: 34, borderColor: "var(--ink)", backgroundColor: "transparent", duration: 0.25 });
    };

    document.addEventListener("mouseover", onEnter);
    document.addEventListener("mouseout", onLeave);

    return () => {
      window.removeEventListener("mousemove", move);
      document.removeEventListener("mouseover", onEnter);
      document.removeEventListener("mouseout", onLeave);
    };
  }, []);

  return (
    <>
      <div ref={dot} className="cursor-dot" />
      <div ref={ring} className="cursor-ring" />
    </>
  );
}
