import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type PointerEvent as ReactPointerEvent,
} from "react";
import {
  createEngine,
  drawGame,
  launchBall,
  resetEngine,
  resizeEngine,
  setAimFromPoint,
  tickEngine,
  type Engine,
  type GameEvent,
  type GamePhase,
} from "./game";

type ScoreRecord = {
  score: number;
  made: number;
  shots: number;
  at: number;
};

type HudState = {
  score: number;
  lives: number;
  seconds: number;
  shots: number;
  made: number;
  combo: number;
};

type Feedback = {
  id: number;
  message: string;
  tone: "hit" | "miss" | "neutral";
};

const SCORE_KEY = "paper-in-the-dustbin-scores-v1";
const ROUND_LENGTH = 45;

function loadRecords(): ScoreRecord[] {
  try {
    const stored: unknown = JSON.parse(localStorage.getItem(SCORE_KEY) ?? "[]");
    if (!Array.isArray(stored)) return [];
    return stored
      .filter((item): item is ScoreRecord =>
        item !== null &&
        typeof item === "object" &&
        Number.isFinite(item.score) &&
        Number.isFinite(item.made) &&
        Number.isFinite(item.shots) &&
        Number.isFinite(item.at),
      )
      .slice(0, 5);
  } catch {
    return [];
  }
}

function snapshot(engine: Engine): HudState {
  return {
    score: engine.score,
    lives: engine.lives,
    seconds: Math.max(0, Math.ceil(engine.secondsLeft)),
    shots: engine.shots,
    made: engine.made,
    combo: engine.combo,
  };
}

function formatClock(seconds: number): string {
  const minutes = Math.floor(seconds / 60);
  const remainder = seconds % 60;
  return `${String(minutes).padStart(2, "0")}:${String(remainder).padStart(2, "0")}`;
}

function formatScore(score: number): string {
  return String(score).padStart(4, "0");
}

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<Engine | null>(null);
  if (!engineRef.current) engineRef.current = createEngine();
  const engine = engineRef.current;

  const [phase, setPhase] = useState<GamePhase>("ready");
  const [hud, setHud] = useState<HudState>(() => snapshot(engine));
  const [feedback, setFeedback] = useState<Feedback | null>(null);
  const [records, setRecords] = useState<ScoreRecord[]>(loadRecords);
  const recordsRef = useRef(records);
  const feedbackTimerRef = useRef<number | null>(null);

  const announce = useCallback((message: string, tone: Feedback["tone"]) => {
    setFeedback({ id: Date.now() + Math.random(), message, tone });
    if (feedbackTimerRef.current !== null) window.clearTimeout(feedbackTimerRef.current);
    feedbackTimerRef.current = window.setTimeout(() => setFeedback(null), 1150);
  }, []);

  const finishRun = useCallback(() => {
    const current = engineRef.current;
    if (!current || current.didRecord) return;

    current.didRecord = true;
    current.phase = "gameover";
    setPhase("gameover");
    setHud(snapshot(current));

    const run: ScoreRecord = {
      score: current.score,
      made: current.made,
      shots: current.shots,
      at: Date.now(),
    };
    const next = [...recordsRef.current, run]
      .sort((a, b) => b.score - a.score || b.made - a.made || b.at - a.at)
      .slice(0, 5);
    recordsRef.current = next;
    setRecords(next);
    try {
      localStorage.setItem(SCORE_KEY, JSON.stringify(next));
    } catch {
      // The round still completes if browser storage is unavailable.
    }
  }, []);

  const handleGameEvent = useCallback((event: GameEvent) => {
    const current = engineRef.current;
    if (!current) return;

    if (event.kind === "hit") {
      const streak = event.combo > 1 ? `  /  ${event.combo} IN A ROW` : "";
      announce(`SWISH  +${event.points}${streak}`, "hit");
      setHud(snapshot(current));
      try {
        navigator.vibrate?.(24);
      } catch {
        // Haptics are an optional extra on supported devices.
      }
    } else if (event.kind === "miss") {
      announce(event.rim ? "RIMMED OUT" : "PAPER DOWN", "miss");
      setHud(snapshot(current));
      if (event.gameOver) finishRun();
    } else {
      announce("SHIFT OVER", "neutral");
      finishRun();
    }
  }, [announce, finishRun]);

  const beginRound = useCallback(() => {
    const current = engineRef.current;
    if (!current) return;
    resetEngine(current);
    setPhase("playing");
    setHud(snapshot(current));
    setFeedback(null);
    if (feedbackTimerRef.current !== null) window.clearTimeout(feedbackTimerRef.current);
  }, []);

  const togglePause = useCallback(() => {
    const current = engineRef.current;
    if (!current) return;
    if (current.phase === "playing") {
      current.phase = "paused";
      current.dragging = false;
      current.pointerId = null;
      setPhase("paused");
    } else if (current.phase === "paused") {
      current.phase = "playing";
      setPhase("playing");
    }
  }, []);

  const resumeRound = useCallback(() => {
    const current = engineRef.current;
    if (!current || current.phase !== "paused") return;
    current.phase = "playing";
    setPhase("playing");
  }, []);

  const fire = useCallback(() => {
    const current = engineRef.current;
    if (!current || !launchBall(current)) return;
    setHud(snapshot(current));
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext("2d", { alpha: false });
    if (!canvas || !ctx) return;

    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      if (rect.width < 1 || rect.height < 1) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 1.75);
      canvas.width = Math.round(rect.width * dpr);
      canvas.height = Math.round(rect.height * dpr);
      resizeEngine(engine, rect.width, rect.height, dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    const observer = new ResizeObserver(resize);
    observer.observe(canvas);
    window.addEventListener("resize", resize);
    resize();

    let requestId = 0;
    let lastTime = performance.now();
    let hudClock = 0;

    const frame = (time: number) => {
      const delta = Math.min((time - lastTime) / 1000, 1 / 30);
      lastTime = time;

      if (engine.phase === "playing") {
        const event = tickEngine(engine, delta);
        if (event) handleGameEvent(event);
        hudClock += delta;
        if (hudClock >= 0.1) {
          setHud(snapshot(engine));
          hudClock = 0;
        }
      }

      drawGame(ctx, engine, time);
      requestId = window.requestAnimationFrame(frame);
    };

    requestId = window.requestAnimationFrame(frame);
    return () => {
      observer.disconnect();
      window.removeEventListener("resize", resize);
      window.cancelAnimationFrame(requestId);
    };
  }, [engine, handleGameEvent]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target;
      if (target instanceof HTMLElement) {
        const tag = target.tagName;
        if (target.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(tag)) return;
        if (target instanceof HTMLButtonElement && ["Enter", " "].includes(event.key)) return;
      }

      const current = engineRef.current;
      if (!current) return;
      const key = event.key.toLowerCase();

      if (key === "escape" || key === "p") {
        if (current.phase === "playing" || current.phase === "paused") {
          event.preventDefault();
          togglePause();
        }
        return;
      }

      if (event.code === "Space" || event.key === "Enter") {
        if (current.phase === "ready" || current.phase === "gameover") {
          event.preventDefault();
          beginRound();
          return;
        }
        if (current.phase === "paused") {
          event.preventDefault();
          resumeRound();
          return;
        }
      }

      if (current.phase !== "playing") return;
      if (["ArrowLeft", "ArrowRight", "ArrowUp", "ArrowDown"].includes(event.key)) {
        event.preventDefault();
        if (event.key === "ArrowLeft") current.aimAngle = Math.min(1.2, current.aimAngle + 0.025);
        if (event.key === "ArrowRight") current.aimAngle = Math.max(0.13, current.aimAngle - 0.025);
        if (event.key === "ArrowUp") current.aimPower = Math.min(1, current.aimPower + 0.045);
        if (event.key === "ArrowDown") current.aimPower = Math.max(0, current.aimPower - 0.045);
        return;
      }
      if (event.code === "Space") {
        event.preventDefault();
        fire();
      }
    };

    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [beginRound, fire, resumeRound, togglePause]);

  const pointerPoint = (event: ReactPointerEvent<HTMLCanvasElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    return { x: event.clientX - rect.left, y: event.clientY - rect.top };
  };

  const onPointerDown = (event: ReactPointerEvent<HTMLCanvasElement>) => {
    const current = engineRef.current;
    if (!current || current.phase !== "playing" || current.ball.mode !== "ready") return;
    const point = pointerPoint(event);
    const distance = Math.hypot(point.x - current.ball.x, point.y - current.ball.y);
    if (distance > Math.max(86, current.height * 0.27)) return;

    event.preventDefault();
    event.currentTarget.setPointerCapture(event.pointerId);
    current.pointerId = event.pointerId;
    current.dragging = true;
    current.dragStartX = point.x;
    current.dragStartY = point.y;
    current.dragX = point.x;
    current.dragY = point.y;
  };

  const onPointerMove = (event: ReactPointerEvent<HTMLCanvasElement>) => {
    const current = engineRef.current;
    if (!current?.dragging || current.pointerId !== event.pointerId) return;
    event.preventDefault();
    const point = pointerPoint(event);
    setAimFromPoint(current, point.x, point.y);
  };

  const onPointerUp = (event: ReactPointerEvent<HTMLCanvasElement>) => {
    const current = engineRef.current;
    if (!current?.dragging || current.pointerId !== event.pointerId) return;
    event.preventDefault();
    const point = pointerPoint(event);
    const pullDistance = Math.hypot(point.x - current.dragStartX, point.y - current.dragStartY);
    if (pullDistance > 18) setAimFromPoint(current, point.x, point.y);
    current.dragging = false;
    current.pointerId = null;
    fire();
  };

  const onPointerCancel = (event: ReactPointerEvent<HTMLCanvasElement>) => {
    const current = engineRef.current;
    if (!current || current.pointerId !== event.pointerId) return;
    current.dragging = false;
    current.pointerId = null;
  };

  const bestScore = records[0]?.score ?? 0;
  const timeFraction = Math.max(0, Math.min(1, hud.seconds / ROUND_LENGTH));

  return (
    <main className="app-shell">
      <header className="topbar">
        <a className="league-mark" href="#game" aria-label="Paper in the dustbin home">
          <span className="mark-art" aria-hidden="true">
            <svg viewBox="0 0 44 44" fill="none">
              <path d="M12 15h20l-2 23H14l-2-23Z" fill="#dce87a" stroke="currentColor" strokeWidth="2.5" />
              <path d="M10 12h24M17 12l1.2-3h7.6l1.2 3M18 20v12M26 20v12" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
              <path d="m19 7 3-3 3 3" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </span>
          <span className="league-name">BREAKROOM<span>SPORTS CLUB</span></span>
        </a>
        <div className="topbar-note"><span className="live-dot" /> THE DESK LEAGUE <span className="topbar-slash">/</span> EVENT 01</div>
      </header>

      <section className="intro" aria-labelledby="page-title">
        <div>
          <p className="eyebrow"><span className="eyebrow-line" /> OFFICE ARCADE / EVENT 01</p>
          <h1 id="page-title">Paper in the <span>dustbin.</span></h1>
        </div>
        <p className="intro-note">A little lunch-break physics.<br />A lot of unnecessary glory.</p>
      </section>

      <section className="game-section" id="game" aria-label="Paper toss game">
        <div className={`arena arena-${phase}`}>
          <canvas
            ref={canvasRef}
            className="game-canvas"
            tabIndex={0}
            aria-label="Paper toss game. Drag back from the paper to aim, then release to throw."
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerCancel={onPointerCancel}
          />

          <div className="arena-hud">
            <div key={hud.score} className={`score-readout ${feedback?.tone === "hit" ? "score-pop" : ""}`}>
              <span className="hud-label">SCORE</span>
              <strong>{formatScore(hud.score)}</strong>
              {hud.combo > 1 && <span className="combo-tag">STREAK x{hud.combo}</span>}
            </div>

            <div className="hud-right">
              <div className="timer-readout">
                <span className="hud-label">TIME LEFT</span>
                <strong className={hud.seconds <= 8 ? "time-urgent" : ""}>{formatClock(hud.seconds)}</strong>
              </div>
              <div className="lives-readout" aria-label={`${hud.lives} chances remaining`}>
                <span className="hud-label">CHANCES</span>
                <div className="life-marks" aria-hidden="true">
                  {[0, 1, 2].map((life) => <span className={life < hud.lives ? "life-mark" : "life-mark spent"} key={life} />)}
                </div>
              </div>
              {(phase === "playing" || phase === "paused") && (
                <button className="pause-button" onClick={togglePause} aria-label={phase === "paused" ? "Resume game" : "Pause game"}>
                  {phase === "paused" ? <PlayIcon /> : <PauseIcon />}
                </button>
              )}
            </div>
          </div>

          <div className="timer-track" aria-hidden="true"><span style={{ width: `${timeFraction * 100}%` }} /></div>

          {feedback && phase === "playing" && (
            <div className={`shot-feedback feedback-${feedback.tone}`} key={feedback.id} aria-live="polite">
              {feedback.message}
            </div>
          )}

          {phase !== "playing" && (
            <div className="state-shade">
              <div className={`state-panel panel-${phase}`} role="dialog" aria-modal="true" aria-labelledby="state-title">
                {phase === "ready" && (
                  <>
                    <p className="panel-kicker"><span>01</span> TAKE YOUR PLACE AT THE LINE</p>
                    <h2 id="state-title">Make it <i>count.</i></h2>
                    <p className="panel-copy">Pull back from the paper, line up the moving bin, then let it fly.</p>
                    <button className="primary-button" onClick={beginRound}>START THE ROUND <ArrowIcon /></button>
                    <div className="panel-facts"><span>45 SECOND SHIFT</span><span>3 CHANCES</span><span>BEST {formatScore(bestScore)}</span></div>
                  </>
                )}

                {phase === "paused" && (
                  <>
                    <p className="panel-kicker"><span>TIME OUT</span> THE BIN ISN'T GOING ANYWHERE</p>
                    <h2 id="state-title">Catch your <i>breath.</i></h2>
                    <p className="panel-copy">You have {formatClock(hud.seconds)} left and {hud.lives} {hud.lives === 1 ? "chance" : "chances"}. Pick up right where you left off.</p>
                    <button className="primary-button" onClick={resumeRound}>BACK TO IT <ArrowIcon /></button>
                    <button className="text-button" onClick={beginRound}>START A FRESH ROUND</button>
                  </>
                )}

                {phase === "gameover" && (
                  <>
                    <p className="panel-kicker"><span>SHIFT COMPLETE</span> PAPERWORK CAN WAIT</p>
                    <h2 id="state-title">That's a <i>wrap.</i></h2>
                    <p className="panel-copy">Final score <strong>{formatScore(hud.score)}</strong> / {hud.made} {hud.made === 1 ? "make" : "makes"} from {hud.shots} {hud.shots === 1 ? "shot" : "shots"}.</p>
                    <button className="primary-button" onClick={beginRound}>PLAY AGAIN <ArrowIcon /></button>
                    <p className="best-callout">LOCAL BEST <strong>{formatScore(bestScore)}</strong></p>
                  </>
                )}
              </div>
            </div>
          )}
        </div>

        <div className="under-arena">
          <div className="control-guide">
            <div className="guide-heading"><span className="guide-stamp">HOW TO PLAY</span><span className="guide-rule" /></div>
            <p className="touch-instruction"><strong>Touch + mouse</strong><span>Grab the sheet. Pull back. Release.</span></p>
            <div className="keyboard-instruction">
              <span><kbd>←</kbd><kbd>→</kbd> AIM</span>
              <span><kbd>↑</kbd><kbd>↓</kbd> POWER</span>
              <span><kbd>SPACE</kbd> THROW</span>
              <span><kbd>P</kbd> PAUSE</span>
            </div>
          </div>

          <section className="leaderboard" aria-labelledby="leaderboard-title">
            <div className="leaderboard-heading">
              <h2 id="leaderboard-title">BEST RUNS</h2>
              <span>SAVED ON THIS DEVICE</span>
            </div>
            <table>
              <thead>
                <tr><th scope="col">#</th><th scope="col">SCORE</th><th scope="col">MADE</th><th scope="col">DATE</th></tr>
              </thead>
              <tbody>
                {records.length === 0 ? (
                  <tr className="empty-row"><td colSpan={4}>No rounds logged yet. Put one on the board.</td></tr>
                ) : records.map((record, index) => (
                  <tr key={`${record.at}-${index}`}>
                    <td className="rank-cell">{String(index + 1).padStart(2, "0")}</td>
                    <td className="record-score">{formatScore(record.score)}</td>
                    <td>{record.made}/{record.shots}</td>
                    <td>{new Date(record.at).toLocaleDateString(undefined, { month: "short", day: "numeric" })}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </section>
        </div>
      </section>

      <footer className="page-footer"><span>BREAKROOM SPORTS CLUB</span><span>KEEP YOUR EYE ON THE BIN.</span></footer>
    </main>
  );
}

function ArrowIcon() {
  return <svg viewBox="0 0 20 20" aria-hidden="true"><path d="M3.5 10h12m-5-5 5 5-5 5" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" /></svg>;
}

function PauseIcon() {
  return <svg viewBox="0 0 20 20" aria-hidden="true"><path d="M6.5 4.5v11m7-11v11" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="square" /></svg>;
}

function PlayIcon() {
  return <svg viewBox="0 0 20 20" aria-hidden="true"><path d="m6 4.5 9 5.5-9 5.5v-11Z" fill="currentColor" /></svg>;
}