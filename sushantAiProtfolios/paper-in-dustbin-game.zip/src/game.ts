export type GamePhase = "ready" | "playing" | "paused" | "gameover";
export type BallMode = "ready" | "flying" | "scored" | "missed";

export type GameEvent =
  | { kind: "hit"; points: number; combo: number }
  | { kind: "miss"; livesLeft: number; rim: boolean; gameOver: boolean }
  | { kind: "gameover"; reason: "time" };

type Particle = {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  spin: number;
  angle: number;
  paper: boolean;
  color: string;
};

type Scrap = { x: number; y: number; angle: number; scale: number; life: number };

export type Engine = {
  phase: GamePhase;
  width: number;
  height: number;
  dpr: number;
  elapsed: number;
  secondsLeft: number;
  score: number;
  lives: number;
  shots: number;
  made: number;
  misses: number;
  combo: number;
  aimAngle: number;
  aimPower: number;
  dragging: boolean;
  dragStartX: number;
  dragStartY: number;
  dragX: number;
  dragY: number;
  pointerId: number | null;
  ball: {
    x: number;
    y: number;
    vx: number;
    vy: number;
    radius: number;
    angle: number;
    spin: number;
    mode: BallMode;
  };
  settleTimer: number;
  shake: number;
  trails: { x: number; y: number; life: number }[];
  particles: Particle[];
  scraps: Scrap[];
  didRecord: boolean;
};

const ROUND_SECONDS = 45;
const PAPER = "#f8f4e8";
const PARTICLE_COLORS = ["#f8f4e8", "#dce87a", "#9bac82", "#fffdf5"];

export function createEngine(): Engine {
  return {
    phase: "ready",
    width: 0,
    height: 0,
    dpr: 1,
    elapsed: 0,
    secondsLeft: ROUND_SECONDS,
    score: 0,
    lives: 3,
    shots: 0,
    made: 0,
    misses: 0,
    combo: 0,
    aimAngle: 0.7,
    aimPower: 0.52,
    dragging: false,
    dragStartX: 0,
    dragStartY: 0,
    dragX: 0,
    dragY: 0,
    pointerId: null,
    ball: {
      x: 0,
      y: 0,
      vx: 0,
      vy: 0,
      radius: 14,
      angle: 0,
      spin: 0,
      mode: "ready",
    },
    settleTimer: 0,
    shake: 0,
    trails: [],
    particles: [],
    scraps: [],
    didRecord: false,
  };
}

export function resetEngine(engine: Engine): void {
  engine.phase = "playing";
  engine.elapsed = 0;
  engine.secondsLeft = ROUND_SECONDS;
  engine.score = 0;
  engine.lives = 3;
  engine.shots = 0;
  engine.made = 0;
  engine.misses = 0;
  engine.combo = 0;
  engine.aimAngle = 0.7;
  engine.aimPower = 0.52;
  engine.dragging = false;
  engine.dragStartX = 0;
  engine.dragStartY = 0;
  engine.pointerId = null;
  engine.settleTimer = 0;
  engine.shake = 0;
  engine.trails.length = 0;
  engine.particles.length = 0;
  engine.scraps.length = 0;
  engine.didRecord = false;
  setBallHome(engine);
}

export function resizeEngine(engine: Engine, width: number, height: number, dpr: number): void {
  const previousWidth = engine.width;
  const previousHeight = engine.height;

  if (previousWidth > 0 && previousHeight > 0) {
    const scaleX = width / previousWidth;
    const scaleY = height / previousHeight;
    engine.ball.x *= scaleX;
    engine.ball.y *= scaleY;
    engine.ball.vx *= scaleX;
    engine.ball.vy *= scaleY;
    engine.dragStartX *= scaleX;
    engine.dragStartY *= scaleY;
    engine.dragX *= scaleX;
    engine.dragY *= scaleY;
  }

  engine.width = width;
  engine.height = height;
  engine.dpr = dpr;
  engine.ball.radius = Math.max(11, Math.min(18, height * 0.034));

  if (previousWidth === 0 || previousHeight === 0 || engine.ball.mode === "ready") {
    setBallHome(engine);
  }
}

export function setAimFromPoint(engine: Engine, x: number, y: number): void {
  engine.dragX = x;
  engine.dragY = y;
  const dx = x - engine.ball.x;
  const dy = y - engine.ball.y;
  const distance = Math.hypot(dx, dy);

  if (distance < 18) return;
  engine.aimAngle = clamp(Math.atan2(dy, -dx), 0.13, 1.2);
  engine.aimPower = clamp((distance - 18) / 122, 0, 1);
}

export function launchBall(engine: Engine): boolean {
  if (engine.phase !== "playing" || engine.ball.mode !== "ready" || engine.secondsLeft <= 0) return false;

  const layout = getLayout(engine);
  const targetX = getTargetX(engine);
  const dx = Math.max(1, targetX - engine.ball.x);
  const catchY = layout.binTop + engine.ball.radius * 0.15;
  const rise = Math.max(1, engine.ball.y - catchY);
  const gravity = engine.height * 1.75;
  const angle = engine.aimAngle;
  const cosine = Math.max(0.15, Math.cos(angle));
  const possibleRise = dx * Math.tan(angle) - rise;
  const idealSpeed = possibleRise > 1
    ? Math.sqrt((gravity * dx * dx) / (2 * cosine * cosine * possibleRise))
    : engine.height * 2.55;
  const speed = clamp(idealSpeed * (0.74 + engine.aimPower * 0.52), engine.height * 0.95, engine.height * 3.4);

  engine.ball.vx = speed * Math.cos(angle);
  engine.ball.vy = -speed * Math.sin(angle);
  engine.ball.spin = (Math.random() > 0.5 ? 1 : -1) * (8 + engine.aimPower * 10);
  engine.ball.mode = "flying";
  engine.ball.angle = 0;
  engine.shots += 1;
  engine.shake = Math.max(engine.shake, 2.5);
  engine.dragging = false;
  engine.dragStartX = 0;
  engine.dragStartY = 0;
  engine.pointerId = null;
  return true;
}

export function tickEngine(engine: Engine, delta: number): GameEvent | null {
  if (engine.phase !== "playing") return null;

  const dt = Math.min(delta, 1 / 30);
  engine.elapsed += dt;
  engine.secondsLeft = Math.max(0, engine.secondsLeft - dt);
  engine.shake = Math.max(0, engine.shake - 20 * dt);
  updateParticles(engine, dt);

  const ball = engine.ball;
  let event: GameEvent | null = null;

  if (ball.mode === "flying") {
    const previousX = ball.x;
    const previousY = ball.y;
    const gravity = engine.height * 1.75;
    ball.vy += gravity * dt;
    ball.x += ball.vx * dt;
    ball.y += ball.vy * dt;
    ball.angle += ball.spin * dt;

    if (engine.trails.length < 28) {
      engine.trails.push({ x: ball.x, y: ball.y, life: 0.23 });
    }

    const layout = getLayout(engine);
    const catchY = layout.binTop + ball.radius * 0.15;
    if (ball.vy > 0 && previousY < catchY && ball.y >= catchY) {
      const crossingRatio = (catchY - previousY) / Math.max(1, ball.y - previousY);
      const crossingX = previousX + (ball.x - previousX) * crossingRatio;
      const binX = getTargetX(engine);
      const offset = Math.abs(crossingX - binX);

      if (offset <= layout.openingHalf - ball.radius * 0.35) {
        event = scoreShot(engine, crossingX, catchY);
      } else if (offset <= layout.bodyHalf + ball.radius * 0.7) {
        event = missShot(engine, crossingX, catchY, true);
      }
    }

    if (ball.mode === "flying" && (ball.y + ball.radius >= layout.groundY || ball.x > engine.width + ball.radius * 2)) {
      event = missShot(engine, ball.x, Math.min(ball.y, layout.groundY - ball.radius), false);
    }
  } else if (ball.mode === "scored" || ball.mode === "missed") {
    engine.settleTimer -= dt;
    if (engine.settleTimer <= 0) {
      if (engine.secondsLeft <= 0) {
        engine.phase = "gameover";
        event = { kind: "gameover", reason: "time" };
      } else {
        setBallHome(engine);
      }
    }
  } else if (engine.secondsLeft <= 0) {
    engine.phase = "gameover";
    event = { kind: "gameover", reason: "time" };
  }

  return event;
}

export function getTargetX(engine: Engine): number {
  return engine.width * 0.76 + Math.sin(engine.elapsed * 0.72) * engine.width * 0.034;
}

export function getLayout(engine: Engine) {
  const height = engine.height;
  const groundY = height * 0.82;
  const binHeight = height * 0.255;
  const binTop = groundY - binHeight;
  const bodyHalf = height * 0.12;
  const openingHalf = height * 0.09;

  return { groundY, binTop, binHeight, bodyHalf, openingHalf };
}

export function drawGame(ctx: CanvasRenderingContext2D, engine: Engine, now: number): void {
  const { width, height } = engine;
  if (width <= 0 || height <= 0) return;

  ctx.save();
  ctx.setTransform(engine.dpr, 0, 0, engine.dpr, 0, 0);
  ctx.clearRect(0, 0, width, height);

  if (engine.shake > 0) {
    const strength = engine.shake;
    ctx.translate((Math.random() - 0.5) * strength, (Math.random() - 0.5) * strength);
  }

  drawRoom(ctx, engine);
  drawAimGuide(ctx, engine);
  drawBin(ctx, engine);
  drawScraps(ctx, engine);
  drawTrails(ctx, engine);
  drawBall(ctx, engine, now);
  drawParticles(ctx, engine);
  drawCanvasMessage(ctx, engine);
  ctx.restore();
}

function setBallHome(engine: Engine): void {
  const layout = getLayout(engine);
  engine.ball.x = engine.width * 0.14;
  engine.ball.y = layout.groundY - engine.ball.radius - 2;
  engine.ball.vx = 0;
  engine.ball.vy = 0;
  engine.ball.spin = 0;
  engine.ball.angle = 0;
  engine.ball.mode = "ready";
  engine.settleTimer = 0;
  engine.dragging = false;
  engine.dragStartX = 0;
  engine.dragStartY = 0;
  engine.pointerId = null;
}

function scoreShot(engine: Engine, x: number, y: number): GameEvent {
  engine.combo += 1;
  engine.made += 1;
  const points = 100 + Math.max(0, engine.combo - 1) * 25;
  engine.score += points;
  engine.ball.mode = "scored";
  engine.ball.x = x;
  engine.ball.y = y;
  engine.ball.vx = 0;
  engine.ball.vy = 0;
  engine.ball.spin = 5;
  engine.ball.angle = 0;
  engine.settleTimer = 0.42;
  engine.shake = 11;
  burst(engine, x, y, 30, true);
  return { kind: "hit", points, combo: engine.combo };
}

function missShot(engine: Engine, x: number, y: number, rim: boolean): GameEvent {
  engine.misses += 1;
  engine.lives = Math.max(0, engine.lives - 1);
  engine.combo = 0;
  engine.ball.mode = "missed";
  engine.ball.x = clamp(x, engine.ball.radius, engine.width - engine.ball.radius);
  engine.ball.y = y;
  engine.ball.vx = 0;
  engine.ball.vy = 0;
  engine.ball.spin = 0;
  engine.ball.angle = Math.random() * 1.5 - 0.75;
  engine.settleTimer = 0.58;
  engine.shake = rim ? 8 : 6;
  engine.scraps.push({ x: engine.ball.x, y: getLayout(engine).groundY - engine.ball.radius * 0.5, angle: engine.ball.angle, scale: 0.72, life: 3.2 });
  if (engine.scraps.length > 9) engine.scraps.shift();
  burst(engine, x, y, rim ? 17 : 12, false);
  const gameOver = engine.lives <= 0;

  if (gameOver) engine.phase = "gameover";
  return { kind: "miss", livesLeft: engine.lives, rim, gameOver };
}

function burst(engine: Engine, x: number, y: number, count: number, celebratory: boolean): void {
  for (let i = 0; i < count; i += 1) {
    const angle = (Math.PI * 2 * i) / count + (Math.random() - 0.5) * 0.5;
    const speed = (celebratory ? 110 : 70) + Math.random() * (celebratory ? 250 : 155);
    const life = (celebratory ? 0.65 : 0.4) + Math.random() * 0.5;
    engine.particles.push({
      x,
      y,
      vx: Math.cos(angle) * speed,
      vy: Math.sin(angle) * speed - (celebratory ? 55 : 0),
      life,
      maxLife: life,
      size: 3 + Math.random() * 6,
      spin: (Math.random() - 0.5) * 12,
      angle: Math.random() * Math.PI,
      paper: Math.random() > 0.42,
      color: PARTICLE_COLORS[Math.floor(Math.random() * PARTICLE_COLORS.length)],
    });
  }
  if (engine.particles.length > 100) engine.particles.splice(0, engine.particles.length - 100);
}

function updateParticles(engine: Engine, dt: number): void {
  for (let i = engine.trails.length - 1; i >= 0; i -= 1) {
    engine.trails[i].life -= dt;
    if (engine.trails[i].life <= 0) engine.trails.splice(i, 1);
  }

  for (let i = engine.particles.length - 1; i >= 0; i -= 1) {
    const particle = engine.particles[i];
    particle.life -= dt;
    particle.x += particle.vx * dt;
    particle.y += particle.vy * dt;
    particle.vy += engine.height * 0.9 * dt;
    particle.vx *= 1 - Math.min(1, dt * 0.65);
    particle.angle += particle.spin * dt;
    if (particle.life <= 0) engine.particles.splice(i, 1);
  }

  for (let i = engine.scraps.length - 1; i >= 0; i -= 1) {
    engine.scraps[i].life -= dt;
    if (engine.scraps[i].life <= 0) engine.scraps.splice(i, 1);
  }
}

function drawRoom(ctx: CanvasRenderingContext2D, engine: Engine): void {
  const { width, height } = engine;
  const { groundY } = getLayout(engine);
  const wall = ctx.createLinearGradient(0, 0, 0, groundY);
  wall.addColorStop(0, "#d8d2c0");
  wall.addColorStop(1, "#e8e4d7");
  ctx.fillStyle = wall;
  ctx.fillRect(0, 0, width, groundY);

  ctx.save();
  ctx.strokeStyle = "rgba(63, 70, 57, 0.055)";
  ctx.lineWidth = 1;
  const spacing = Math.max(36, engine.height * 0.105);
  for (let x = spacing; x < width; x += spacing) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, groundY);
    ctx.stroke();
  }
  for (let y = spacing; y < groundY; y += spacing) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(width, y);
    ctx.stroke();
  }
  ctx.restore();

  drawWindow(ctx, engine);
  if (width > 650) drawWallNote(ctx, engine);

  const floor = ctx.createLinearGradient(0, groundY, 0, height);
  floor.addColorStop(0, "#c5c2ae");
  floor.addColorStop(1, "#a7a791");
  ctx.fillStyle = floor;
  ctx.fillRect(0, groundY, width, height - groundY);

  ctx.fillStyle = "#777c68";
  ctx.fillRect(0, groundY - 2, width, 4);
  ctx.fillStyle = "rgba(255, 255, 240, 0.38)";
  ctx.fillRect(0, groundY + 4, width, 2);

  ctx.save();
  ctx.strokeStyle = "rgba(48, 59, 47, 0.13)";
  ctx.lineWidth = 1;
  for (let y = groundY + height * 0.07; y < height; y += height * 0.085) {
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(width, y);
    ctx.stroke();
  }
  const tile = Math.max(74, height * 0.26);
  for (let x = -tile; x < width + tile; x += tile) {
    ctx.beginPath();
    ctx.moveTo(x, groundY);
    ctx.lineTo(x - tile * 0.42, height);
    ctx.stroke();
  }
  ctx.restore();

  const targetX = getTargetX(engine);
  ctx.fillStyle = "rgba(36, 47, 38, 0.17)";
  ctx.beginPath();
  ctx.ellipse(targetX + 4, groundY + 5, height * 0.17, height * 0.032, 0, 0, Math.PI * 2);
  ctx.fill();

  const homeX = width * 0.14;
  ctx.fillStyle = "rgba(36, 47, 38, 0.17)";
  ctx.beginPath();
  ctx.ellipse(homeX + 4, groundY + 4, height * 0.056, height * 0.015, 0, 0, Math.PI * 2);
  ctx.fill();
}

function drawWindow(ctx: CanvasRenderingContext2D, engine: Engine): void {
  const { width, height } = engine;
  const x = width * 0.51;
  const y = height * 0.11;
  const windowWidth = width * 0.275;
  const windowHeight = height * 0.29;

  ctx.save();
  ctx.fillStyle = "rgba(45, 54, 43, 0.12)";
  ctx.fillRect(x - 5, y + 5, windowWidth + 10, windowHeight + 10);
  ctx.fillStyle = "#f0ebdc";
  ctx.fillRect(x - 5, y - 5, windowWidth + 10, windowHeight + 10);
  const glass = ctx.createLinearGradient(x, y, x + windowWidth, y + windowHeight);
  glass.addColorStop(0, "#91aaa1");
  glass.addColorStop(1, "#b9c8b9");
  ctx.fillStyle = glass;
  ctx.fillRect(x, y, windowWidth, windowHeight);

  ctx.fillStyle = "rgba(248, 244, 222, 0.58)";
  ctx.beginPath();
  ctx.moveTo(x + windowWidth * 0.56, y);
  ctx.lineTo(x + windowWidth, y);
  ctx.lineTo(x + windowWidth, y + windowHeight);
  ctx.lineTo(x + windowWidth * 0.34, y + windowHeight);
  ctx.closePath();
  ctx.fill();

  ctx.strokeStyle = "#67786c";
  ctx.lineWidth = Math.max(3, height * 0.012);
  ctx.beginPath();
  ctx.moveTo(x + windowWidth * 0.52, y);
  ctx.lineTo(x + windowWidth * 0.52, y + windowHeight);
  ctx.moveTo(x, y + windowHeight * 0.56);
  ctx.lineTo(x + windowWidth, y + windowHeight * 0.56);
  ctx.stroke();

  ctx.fillStyle = "rgba(255, 250, 223, 0.4)";
  ctx.fillRect(x + windowWidth * 0.08, y + windowHeight * 0.1, windowWidth * 0.12, windowHeight * 0.3);
  ctx.restore();
}

function drawWallNote(ctx: CanvasRenderingContext2D, engine: Engine): void {
  const x = engine.width * 0.105;
  const y = engine.height * 0.18;
  const width = engine.width * 0.21;
  const height = engine.height * 0.19;

  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(-0.025);
  ctx.fillStyle = "rgba(45, 54, 43, 0.13)";
  ctx.fillRect(4, 5, width, height);
  ctx.fillStyle = "#e7d7ac";
  ctx.fillRect(0, 0, width, height);
  ctx.fillStyle = "#33443b";
  ctx.font = `800 ${Math.max(10, engine.height * 0.027)}px 'Arial Narrow', Arial, sans-serif`;
  ctx.fillText("REMINDER", width * 0.1, height * 0.27);
  ctx.fillStyle = "#78806c";
  ctx.fillRect(width * 0.1, height * 0.38, width * 0.72, 2);
  ctx.fillRect(width * 0.1, height * 0.51, width * 0.6, 2);
  ctx.fillRect(width * 0.1, height * 0.64, width * 0.67, 2);
  ctx.fillStyle = "#bf704d";
  ctx.beginPath();
  ctx.arc(width * 0.84, height * 0.78, Math.max(3, height * 0.045), 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawBin(ctx: CanvasRenderingContext2D, engine: Engine): void {
  const { height } = engine;
  const { groundY, binTop, binHeight, bodyHalf, openingHalf } = getLayout(engine);
  const x = getTargetX(engine);
  const bottomHalf = bodyHalf * 0.76;
  const lipY = binTop + Math.sin(engine.elapsed * 2.4) * 1.1;

  ctx.save();
  ctx.beginPath();
  ctx.moveTo(x - bodyHalf, lipY);
  ctx.lineTo(x + bodyHalf, lipY);
  ctx.lineTo(x + bottomHalf, groundY - 3);
  ctx.quadraticCurveTo(x, groundY + 1, x - bottomHalf, groundY - 3);
  ctx.closePath();

  const body = ctx.createLinearGradient(x - bodyHalf, 0, x + bodyHalf, 0);
  body.addColorStop(0, "#71826c");
  body.addColorStop(0.18, "#a9b58f");
  body.addColorStop(0.56, "#bac39b");
  body.addColorStop(1, "#74836d");
  ctx.fillStyle = body;
  ctx.fill();
  ctx.strokeStyle = "#34463b";
  ctx.lineWidth = Math.max(2, height * 0.0055);
  ctx.stroke();

  ctx.fillStyle = "rgba(244, 242, 221, 0.26)";
  ctx.beginPath();
  ctx.moveTo(x - bodyHalf * 0.77, lipY + 8);
  ctx.lineTo(x - bodyHalf * 0.36, lipY + 12);
  ctx.lineTo(x - bottomHalf * 0.43, groundY - 8);
  ctx.lineTo(x - bottomHalf * 0.7, groundY - 8);
  ctx.closePath();
  ctx.fill();

  const openingY = lipY + 1;
  ctx.fillStyle = "#263932";
  ctx.beginPath();
  ctx.ellipse(x, openingY, openingHalf, Math.max(7, height * 0.019), 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#31483a";
  ctx.lineWidth = Math.max(3, height * 0.012);
  ctx.beginPath();
  ctx.ellipse(x, openingY, bodyHalf, Math.max(9, height * 0.023), 0, Math.PI, Math.PI * 2);
  ctx.stroke();
  ctx.beginPath();
  ctx.ellipse(x, openingY, bodyHalf, Math.max(9, height * 0.023), 0, 0, Math.PI);
  ctx.stroke();

  drawRecycleMark(ctx, x, binTop + binHeight * 0.58, height * 0.041);
  ctx.restore();
}

function drawRecycleMark(ctx: CanvasRenderingContext2D, x: number, y: number, size: number): void {
  ctx.save();
  ctx.translate(x, y);
  ctx.strokeStyle = "rgba(44, 63, 49, 0.55)";
  ctx.lineWidth = Math.max(1.5, size * 0.12);
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  ctx.beginPath();
  ctx.moveTo(-size * 0.62, size * 0.27);
  ctx.lineTo(-size * 0.28, -size * 0.34);
  ctx.lineTo(-size * 0.04, -size * 0.02);
  ctx.moveTo(-size * 0.28, -size * 0.34);
  ctx.lineTo(-size * 0.25, -size * 0.59);
  ctx.moveTo(-size * 0.28, -size * 0.34);
  ctx.lineTo(-size * 0.54, -size * 0.29);
  ctx.moveTo(-size * 0.04, -size * 0.02);
  ctx.lineTo(size * 0.5, -size * 0.11);
  ctx.lineTo(size * 0.35, size * 0.28);
  ctx.moveTo(size * 0.5, -size * 0.11);
  ctx.lineTo(size * 0.67, -size * 0.28);
  ctx.moveTo(size * 0.5, -size * 0.11);
  ctx.lineTo(size * 0.68, size * 0.04);
  ctx.moveTo(size * 0.35, size * 0.28);
  ctx.lineTo(-size * 0.28, size * 0.31);
  ctx.lineTo(-size * 0.06, size * 0.04);
  ctx.stroke();
  ctx.restore();
}

function drawAimGuide(ctx: CanvasRenderingContext2D, engine: Engine): void {
  if (engine.ball.mode !== "ready" || engine.width === 0) return;
  const ball = engine.ball;
  const angle = engine.aimAngle;
  const dx = engine.dragging ? engine.dragX - ball.x : 0;
  const dy = engine.dragging ? engine.dragY - ball.y : 0;
  const pullLength = Math.hypot(dx, dy);
  const layout = getLayout(engine);
  const targetDistance = Math.max(1, getTargetX(engine) - ball.x);
  const rise = Math.max(1, ball.y - (layout.binTop + ball.radius * 0.15));
  const possibleRise = targetDistance * Math.tan(angle) - rise;
  const ideal = possibleRise > 1
    ? Math.sqrt((engine.height * 1.75 * targetDistance * targetDistance) / (2 * Math.cos(angle) ** 2 * possibleRise))
    : engine.height * 2.55;
  const speed = clamp(ideal * (0.74 + engine.aimPower * 0.52), engine.height * 0.95, engine.height * 3.4);
  const gravity = engine.height * 1.75;

  ctx.save();
  ctx.setLineDash([3, 8]);
  ctx.lineWidth = 2;
  ctx.strokeStyle = "rgba(38, 57, 47, 0.3)";
  ctx.beginPath();
  let reachedGround = false;
  for (let t = 0.1; t <= 1.75; t += 0.1) {
    const px = ball.x + speed * Math.cos(angle) * t;
    const py = ball.y - speed * Math.sin(angle) * t + 0.5 * gravity * t * t;
    if (px > engine.width || py > layout.groundY) {
      reachedGround = true;
      break;
    }
    if (t === 0.1) ctx.moveTo(px, py);
    else ctx.lineTo(px, py);
  }
  ctx.stroke();
  ctx.setLineDash([]);

  if (reachedGround) {
    ctx.fillStyle = "rgba(57, 75, 58, 0.28)";
    const markerX = clamp(ball.x + speed * Math.cos(angle) * 0.88, ball.x + 22, engine.width - 10);
    const markerY = Math.min(layout.groundY - 3, ball.y - speed * Math.sin(angle) * 0.88 + 0.5 * gravity * 0.88 * 0.88);
    ctx.beginPath();
    ctx.arc(markerX, markerY, 3, 0, Math.PI * 2);
    ctx.fill();
  }

  if (engine.dragging && pullLength > 5) {
    ctx.strokeStyle = "rgba(206, 222, 98, 0.98)";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(ball.x, ball.y);
    ctx.lineTo(engine.dragX, engine.dragY);
    ctx.stroke();
    ctx.fillStyle = "#dce87a";
    ctx.beginPath();
    ctx.arc(engine.dragX, engine.dragY, 5, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function drawBall(ctx: CanvasRenderingContext2D, engine: Engine, now: number): void {
  const ball = engine.ball;
  if (ball.mode === "missed" && engine.settleTimer < 0.35) return;

  let y = ball.y;
  let scale = 1;
  if (ball.mode === "ready") y += Math.sin(engine.elapsed * 2.6) * 1.2;
  if (ball.mode === "scored") {
    const progress = 1 - clamp(engine.settleTimer / 0.42, 0, 1);
    scale = Math.max(0.06, 1 - progress * 0.9);
    y += progress * ball.radius * 0.55;
  }
  if (ball.mode === "missed") scale = 0.7;

  ctx.save();
  ctx.translate(ball.x, y);
  ctx.rotate(ball.angle + (ball.mode === "ready" ? Math.sin(now * 0.0016) * 0.05 : 0));
  ctx.scale(scale, scale);
  drawPaperShape(ctx, ball.radius);
  ctx.restore();
}

function drawPaperShape(ctx: CanvasRenderingContext2D, radius: number): void {
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(-radius * 0.88, -radius * 0.3);
  ctx.lineTo(-radius * 0.63, -radius * 0.87);
  ctx.lineTo(-radius * 0.12, -radius * 0.99);
  ctx.lineTo(radius * 0.49, -radius * 0.75);
  ctx.lineTo(radius * 0.9, -radius * 0.38);
  ctx.lineTo(radius * 0.84, radius * 0.25);
  ctx.lineTo(radius * 0.4, radius * 0.83);
  ctx.lineTo(-radius * 0.23, radius * 0.91);
  ctx.lineTo(-radius * 0.82, radius * 0.52);
  ctx.closePath();

  const crumple = ctx.createLinearGradient(-radius, -radius, radius, radius);
  crumple.addColorStop(0, "#fffdf6");
  crumple.addColorStop(0.48, PAPER);
  crumple.addColorStop(1, "#d6d1c3");
  ctx.fillStyle = crumple;
  ctx.strokeStyle = "#737667";
  ctx.lineWidth = Math.max(1, radius * 0.075);
  ctx.fill();
  ctx.stroke();

  ctx.strokeStyle = "rgba(107, 110, 96, 0.42)";
  ctx.lineWidth = Math.max(0.7, radius * 0.045);
  ctx.beginPath();
  ctx.moveTo(-radius * 0.63, -radius * 0.67);
  ctx.lineTo(-radius * 0.13, -radius * 0.06);
  ctx.lineTo(radius * 0.5, -radius * 0.75);
  ctx.moveTo(-radius * 0.13, -radius * 0.06);
  ctx.lineTo(radius * 0.4, radius * 0.75);
  ctx.moveTo(-radius * 0.13, -radius * 0.06);
  ctx.lineTo(-radius * 0.76, radius * 0.47);
  ctx.stroke();
  ctx.restore();
}

function drawTrails(ctx: CanvasRenderingContext2D, engine: Engine): void {
  ctx.save();
  for (const trail of engine.trails) {
    const opacity = clamp(trail.life / 0.23, 0, 1) * 0.32;
    ctx.fillStyle = `rgba(248, 244, 232, ${opacity})`;
    ctx.beginPath();
    ctx.arc(trail.x, trail.y, 2 + (1 - opacity) * 2, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function drawParticles(ctx: CanvasRenderingContext2D, engine: Engine): void {
  ctx.save();
  for (const particle of engine.particles) {
    const opacity = clamp(particle.life / particle.maxLife, 0, 1);
    ctx.globalAlpha = opacity;
    if (particle.paper) {
      ctx.translate(particle.x, particle.y);
      ctx.rotate(particle.angle);
      ctx.fillStyle = particle.color;
      ctx.strokeStyle = "rgba(49, 59, 47, 0.27)";
      ctx.lineWidth = 0.75;
      ctx.beginPath();
      ctx.moveTo(-particle.size, -particle.size * 0.5);
      ctx.lineTo(particle.size * 0.45, -particle.size);
      ctx.lineTo(particle.size, particle.size * 0.5);
      ctx.lineTo(-particle.size * 0.4, particle.size);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.rotate(-particle.angle);
      ctx.translate(-particle.x, -particle.y);
    } else {
      ctx.fillStyle = particle.color;
      ctx.beginPath();
      ctx.arc(particle.x, particle.y, particle.size * 0.55, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  ctx.restore();
}

function drawScraps(ctx: CanvasRenderingContext2D, engine: Engine): void {
  ctx.save();
  for (const scrap of engine.scraps) {
    ctx.globalAlpha = clamp(scrap.life / 1.1, 0, 0.72);
    ctx.translate(scrap.x, scrap.y);
    ctx.rotate(scrap.angle);
    drawPaperShape(ctx, engine.ball.radius * scrap.scale);
    ctx.rotate(-scrap.angle);
    ctx.translate(-scrap.x, -scrap.y);
  }
  ctx.restore();
}

function drawCanvasMessage(ctx: CanvasRenderingContext2D, engine: Engine): void {
  const { height } = engine;
  if (engine.phase !== "playing" || engine.ball.mode !== "ready") return;
  if (engine.secondsLeft < 1) return;

  const text = engine.dragging ? "LET IT FLY" : "PULL BACK + RELEASE";
  const x = engine.width * 0.14;
  const y = engine.height * 0.67;
  ctx.save();
  ctx.font = `800 ${Math.max(9, Math.min(12, height * 0.027))}px Arial, sans-serif`;
  ctx.textAlign = "center";
  ctx.letterSpacing = "0.08em";
  ctx.fillStyle = "rgba(33, 47, 40, 0.68)";
  ctx.fillText(text, x, y);
  ctx.restore();
}

function clamp(value: number, minimum: number, maximum: number): number {
  return Math.max(minimum, Math.min(maximum, value));
}