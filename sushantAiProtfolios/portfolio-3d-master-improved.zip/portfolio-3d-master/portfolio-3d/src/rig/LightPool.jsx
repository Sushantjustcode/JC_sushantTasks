import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { rig } from './rig';
import { flicker } from './hooks';
import { fadeWindow, clamp01 } from '../shared/utils';
import { BEATS, B, LANTERNS, TRAIN, WORLD } from '../config/storyboard';

/**
 * A FIXED pool of two point lights that every scene borrows in turn.
 *
 * Why: three.js compiles a shader per light-count. The old scenes each owned point lights
 * inside a <SceneGroup>; whenever one toggled `visible`, the light count changed and EVERY
 * material in the world recompiled – a visible hitch in the middle of scrolling. Here the
 * count never changes, scenes only move/recolour/dim the two lights (intensity 0 = off).
 *
 *   slot A: door glow → loco headlamp → left lantern → booth bulb
 *   slot B:                              right lantern → booth sunset kicker
 */
const STONE = WORLD.stone.pos;
const lan = (i) => [STONE[0] + LANTERNS[i][0], STONE[1] + LANTERNS[i][1], STONE[2] + LANTERNS[i][2]];

export default function LightPool() {
  const a = useRef();
  const b = useRef();
  const regionA = useRef('');
  const regionB = useRef('');

  useFrame(({ clock }) => {
    const A = a.current;
    const Bl = b.current;
    if (!A || !Bl) return;
    const t = rig.time;
    const c = clock.elapsedTime;

    // ── slot A ──
    let region;
    if (t < 24) region = 'door';
    else if (t < BEATS.SKY_B) region = 'loco';
    else if (t < 150) region = 'lantern';
    else region = 'bulb';
    if (region !== regionA.current) {
      regionA.current = region;
      if (region === 'door') { A.color.set('#ffe2a8'); A.distance = 12; A.decay = 1.6; }
      if (region === 'loco') { A.color.set('#fff0c4'); A.distance = 9; A.decay = 2; }
      if (region === 'lantern') { A.color.set('#ffb25e'); A.distance = 14; A.decay = 1.8; }
      if (region === 'bulb') { A.color.set('#ffcf8a'); A.distance = 6; A.decay = 2; }
    }
    if (region === 'door') {
      A.position.set(0, 1.6, -0.6);
      A.intensity = rig.glow * 26 * flicker(c, 6, 0.06);
    } else if (region === 'loco') {
      A.position.set(rig.trainX - 0.4, 2.3, TRAIN.z + 0.6);
      A.intensity = fadeWindow(t, [BEATS.RAILS + 1.5, BEATS.TRAIN_IN + 1, BEATS.TRAIN_OUT - 4, BEATS.TRAIN_OUT]) * 3 * flicker(c, 8, 0.2);
    } else if (region === 'lantern') {
      A.position.set(...lan(0));
      A.intensity = fadeWindow(t, [BEATS.WALL_IN - 3, BEATS.WALL_IN + 1, BEATS.WALL_LAST_HOLD + 1, BEATS.WALL_LAST_HOLD + 4]) * 18 * flicker(c, 10, 0.3);
    } else {
      A.position.set(...B(0, 2.6, 0));
      A.intensity = fadeWindow(t, [BEATS.BOOTH_A - 6, BEATS.BOOTH_A - 2]) * 6 * flicker(c, 7, 0.25);
    }

    // ── slot B ──
    const rb = t < 150 ? 'lantern' : 'sunset';
    if (rb !== regionB.current) {
      regionB.current = rb;
      if (rb === 'lantern') { Bl.color.set('#ffb25e'); Bl.distance = 14; Bl.decay = 1.8; }
      else { Bl.color.set('#ff9a55'); Bl.distance = 14; Bl.decay = 1.6; }
    }
    if (rb === 'lantern') {
      Bl.position.set(...lan(1));
      Bl.intensity = fadeWindow(t, [BEATS.WALL_IN - 3, BEATS.WALL_IN + 1, BEATS.WALL_LAST_HOLD + 1, BEATS.WALL_LAST_HOLD + 4]) * 18 * flicker(c, 10, 0.3, 2.1);
    } else {
      Bl.position.set(...B(3, 2.5, 5));
      Bl.intensity = 6 * clamp01((rig.atmo - 4) * 1.2);
    }
  });

  return (
    <>
      <pointLight ref={a} intensity={0} />
      <pointLight ref={b} intensity={0} />
    </>
  );
}
