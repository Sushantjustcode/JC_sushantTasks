import { useRef, useState } from 'react';
import { useFrame } from '@react-three/fiber';
import { EffectComposer, DepthOfField, Bloom, Vignette, ToneMapping, SMAA } from '@react-three/postprocessing';
import { ToneMappingMode } from 'postprocessing';
import { rig } from './rig';
import { fx } from './fx';
import { WhipBlur } from './WhipBlur';

/**
 * Whip blur + chromatic split (camera-motion driven) · Bloom (door light, lit train windows, sunset)
 * · depth-of-field (oak scene only) · tone-map · vignette (pulses with camera speed) · SMAA.
 *
 * Performance / quality notes
 *  • multisampling={0} + <SMAA/> at the end. MSAA on an HDR buffer averages BRIGHT edge pixels
 *    before tone-mapping, which makes high-contrast edges (the glowing door against dark brick)
 *    shimmer and "flash" while moving. SMAA runs after tone-mapping, so edges stay stable – and
 *    it is much cheaper than 4× MSAA at high resolution.
 *  • The depth-of-field is a full-screen multi-pass effect and only matters in scenes 1–2. It is mounted
 *    from the start (so its shaders compile behind the entry gate, never mid-scroll) and dropped once the
 *    oak scene is over, which frees its passes for the other 80% of the story. Hysteresis (drop at 40,
 *    bring back below 36) avoids flapping; scrolling back up re-mounts it, which costs one small compile.
 *  • The whip-blur pass is always mounted and compiled behind the gate, but DISABLED while the camera is
 *    calm, so it costs nothing except during a transition.
 */
export default function Effects() {
  const composer = useRef();
  const dof = useRef();
  const bloom = useRef();
  const blur = useRef();
  const vig = useRef();
  const frames = useRef(0);
  const [dofOn, setDofOn] = useState(true);

  useFrame(() => {
    frames.current++;
    const want = rig.time < (dofOn ? 40 : 36);
    if (want !== dofOn) setDofOn(want);
    if (dof.current) dof.current.bokehScale = rig.dof * 6;
    if (bloom.current) bloom.current.intensity = rig.bloom;
    if (vig.current) vig.current.darkness = 0.5 + fx.energy * 0.3;

    const e = blur.current;
    if (e) {
      e.uniforms.get('uDir').value.set(fx.blurX, fx.blurY);
      e.uniforms.get('uZoom').value = fx.zoom;
      e.uniforms.get('uCA').value = fx.ca;
      // stay enabled for the first frames (behind the entry gate) so the shader is compiled before it is needed
      const active = frames.current < 60 || fx.blurX + fx.blurY + fx.zoom + fx.ca > 0.0007;
      const pass = composer.current?.passes?.find((p) => p.effects?.includes(e));
      if (pass && pass.enabled !== active) pass.enabled = active;
    }
  });

  return (
    <EffectComposer ref={composer} multisampling={0} enableNormalPass={false}>
      {dofOn ? <DepthOfField ref={dof} worldFocusDistance={11} worldFocusRange={9} bokehScale={0} height={480} /> : <></>}
      <WhipBlur ref={blur} />
      <Bloom ref={bloom} intensity={0.55} luminanceThreshold={1.15} luminanceSmoothing={0.25} mipmapBlur />
      <ToneMapping mode={ToneMappingMode.ACES_FILMIC} />
      <Vignette ref={vig} offset={0.25} darkness={0.5} />
      <SMAA />
    </EffectComposer>
  );
}
