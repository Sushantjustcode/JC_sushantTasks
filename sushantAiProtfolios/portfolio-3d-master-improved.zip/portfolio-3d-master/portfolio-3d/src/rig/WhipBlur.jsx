import { forwardRef, useMemo } from 'react';
import { BlendFunction, Effect, EffectAttribute } from 'postprocessing';
import { Uniform, Vector2 } from 'three';

/**
 * Camera-motion blur for the whips: a symmetric streak along (uDir) plus a radial "zoom" streak (uZoom),
 * and a chromatic split toward the screen edges (uCA). 8 taps per side, in HDR (before tone-mapping),
 * so bright things like the sky and the door glow smear properly.
 * Values come from rig/fx.js; Effects.jsx disables the pass entirely when they are ~0.
 */
const fragment = /* glsl */ `
  uniform vec2 uDir;
  uniform float uZoom;
  uniform float uCA;
  void mainImage(const in vec4 inputColor, const in vec2 uv, out vec4 outputColor) {
    vec2 c = uv - 0.5;
    vec4 acc = inputColor;
    float wsum = 1.0;
    for (int i = 1; i <= 8; i++) {
      float t = float(i) / 8.0;
      float w = 1.0 - 0.65 * t;
      vec2 o = uDir * t + c * uZoom * t;
      acc += (texture2D(inputBuffer, uv + o) + texture2D(inputBuffer, uv - o)) * w;
      wsum += 2.0 * w;
    }
    vec4 col = acc / wsum;
    if (uCA > 0.0) {
      vec2 co = c * uCA;
      col.r = mix(col.r, texture2D(inputBuffer, uv + co).r, 0.7);
      col.b = mix(col.b, texture2D(inputBuffer, uv - co).b, 0.7);
    }
    outputColor = col;
  }
`;

class WhipBlurEffect extends Effect {
  constructor() {
    super('WhipBlurEffect', fragment, {
      blendFunction: BlendFunction.NORMAL,
      attributes: EffectAttribute.CONVOLUTION, // samples the input at other UVs → own pass
      uniforms: new Map([
        ['uDir', new Uniform(new Vector2())],
        ['uZoom', new Uniform(0)],
        ['uCA', new Uniform(0)],
      ]),
    });
  }
}

export const WhipBlur = forwardRef(function WhipBlur(_, ref) {
  const effect = useMemo(() => new WhipBlurEffect(), []);
  return <primitive ref={ref} object={effect} dispose={null} />;
});
