/**
 * Motion-driven "transition" effects, written by CameraRig every frame from the camera's REAL speed
 * and read by Effects (blur / chromatic split / vignette) and the audio engine (air rush).
 * Because they come from actual camera motion, a slow scroll stays perfectly crisp, while a whip
 * (or a hard scroll through one) streaks – the effect is always proportional to what you see.
 */
export const fx = {
  blurX: 0, // directional streak, in screen UV (symmetric, so sign does not matter)
  blurY: 0,
  zoom: 0, // radial streak from forward travel
  ca: 0, // chromatic split strength
  energy: 0, // 0…1 overall camera speed (drives vignette pulse, fov kick, air-rush sound)
};
