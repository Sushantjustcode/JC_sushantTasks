import { makeTrack } from './keyframes';
import { CAMERA_HEAD, CAMERA_TAIL, ROAD_U_KEYS, BEATS, roadPose } from '../config/storyboard';

/**
 * The whole camera move as ONE 7-channel Hermite track: [pos xyz, yaw, pitch, roll, fov].
 *   • Orientation is stored as ANGLES (not a look-at point), so a whip turns at a uniform rate and
 *     can be shaped (overshoot, bank) directly. Keys given as look-at points are converted once, here.
 *   • Position, angles and fov are all velocity-continuous (no stop-and-go between shots).
 *   • The road drone is generated from the road-progress track, sampled densely, so it follows the
 *     real spline and rests at every milestone while the text is written.
 */
const roadU = makeTrack(ROAD_U_KEYS);
const roadKeys = [];
const STEP = 0.4;
for (let t = BEATS.ROAD_T0; t < BEATS.ROAD_T1 - 1e-6; t += STEP) {
  const { pos, look } = roadPose(roadU.at(t));
  roadKeys.push({ t, pos, look, fov: 48, s: 1, roll: 0 });
}
{
  const { pos, look } = roadPose(roadU.at(BEATS.ROAD_T1));
  roadKeys.push({ t: BEATS.ROAD_T1, pos, look, fov: 48, s: 0.6, roll: 0 });
}

const TAU = Math.PI * 2;
let prevYaw = null;
const rows = [...CAMERA_HEAD, ...roadKeys, ...CAMERA_TAIL].map((k) => {
  let yaw;
  let pitch;
  let roll;
  if (k.ang) [yaw, pitch, roll] = k.ang;
  else {
    const dx = k.look[0] - k.pos[0];
    const dy = k.look[1] - k.pos[1];
    const dz = k.look[2] - k.pos[2];
    yaw = Math.atan2(-dx, -dz);
    pitch = Math.atan2(dy, Math.hypot(dx, dz));
    roll = k.roll || 0;
  }
  if (prevYaw !== null) yaw += TAU * Math.round((prevYaw - yaw) / TAU); // keep the turn continuous (no 359° flips)
  prevYaw = yaw;
  return { t: k.t, v: [k.pos[0], k.pos[1], k.pos[2], yaw, pitch, roll, k.fov], s: k.s };
});

const track = makeTrack(rows);
const out = new Float64Array(7);

/** time → camera position (Vector3) and [yaw, pitch, roll] (array, radians); returns the fov in degrees. */
export function sampleCamera(time, outPos, outAng) {
  track.into(time, out);
  outPos.set(out[0], out[1], out[2]);
  outAng[0] = out[3];
  outAng[1] = out[4];
  outAng[2] = out[5];
  return out[6];
}
