import { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame, useThree } from '@react-three/fiber';
import { rig } from './rig';
import { fx } from './fx';
import { sampleCamera } from './path';
import { smooth } from '../shared/utils';
import { BEATS } from '../config/storyboard';

const SHUTTER = 0.026; // seconds of "exposure" used for the streak length
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

/**
 * Samples the camera track at the (already smoothed) story clock and applies it.
 * No extra lag here on purpose: smoothing happens ONCE, upstream, in the engine.
 *
 * It also measures how fast the camera is really turning / travelling and turns that into the
 * transition effects in rig/fx.js (motion blur, chromatic split, vignette pulse) plus a small FOV
 * kick, so the whips feel physical. A faint hand-held drift + gentle mouse parallax are added on
 * top, and fade to zero when the contact form locks the camera.
 */
export default function CameraRig() {
  const camera = useThree((s) => s.camera);
  const size = useThree((s) => s.size);
  const pos = useMemo(() => new THREE.Vector3(), []);
  const ang = useMemo(() => [0, 0, 0], []);
  const eul = useMemo(() => new THREE.Euler(0, 0, 0, 'YXZ'), []);
  const ptr = useRef({ x: 0, y: 0 });
  const prev = useRef({ ok: false, x: 0, y: 0, z: 0, yaw: 0, pitch: 0, roll: 0 });

  useFrame((state, dtRaw) => {
    const dbg = window.__story?.override; // `?debug` only: lets tests park the camera anywhere
    if (dbg) {
      camera.position.set(...dbg.pos);
      camera.lookAt(...dbg.look);
      if (camera.fov !== dbg.fov) {
        camera.fov = dbg.fov;
        camera.updateProjectionMatrix();
      }
      if (window.__story?.fxForce) Object.assign(fx, window.__story.fxForce);
      return;
    }

    const dt = clamp(dtRaw, 1 / 240, 0.1);
    let fov = sampleCamera(rig.time, pos, ang);

    // ── how fast is the camera really moving? ──
    const p = prev.current;
    if (p.ok) {
      const vYaw = (ang[0] - p.yaw) / dt;
      const vPitch = (ang[1] - p.pitch) / dt;
      const vRoll = (ang[2] - p.roll) / dt;
      const dx = pos.x - p.x;
      const dy = pos.y - p.y;
      const dz = pos.z - p.z;
      const cp = Math.cos(ang[1]);
      const fwd = (dx * -cp * Math.sin(ang[0]) + dy * Math.sin(ang[1]) + dz * -cp * Math.cos(ang[0])) / dt; // along the view direction
      const speed = Math.hypot(dx, dy, dz) / dt;
      const aspect = size.width / size.height;
      const vf = (camera.fov * Math.PI) / 180;
      const hf = 2 * Math.atan(Math.tan(vf / 2) * aspect);
      const omega = Math.hypot(vYaw * cp, vPitch, vRoll * 0.5);

      let bx = (Math.abs(vYaw * cp) / hf) * SHUTTER;
      let by = (Math.abs(vPitch) / vf) * SHUTTER;
      const len = Math.hypot(bx, by);
      if (len > 0.042) {
        bx *= 0.042 / len;
        by *= 0.042 / len;
      }
      const zoom = clamp(Math.max(0, fwd) * 0.0014, 0, 0.05);
      const energy = clamp(omega / 2.2 + speed / 38, 0, 1);

      // fast attack, slower release → streaks don't flicker, and fade out gracefully
      const k = (v, t) => 1 - Math.exp(-(t > v ? 20 : 7) * dt);
      fx.blurX += (bx - fx.blurX) * k(fx.blurX, bx);
      fx.blurY += (by - fx.blurY) * k(fx.blurY, by);
      fx.zoom += (zoom - fx.zoom) * k(fx.zoom, zoom);
      fx.energy += (energy - fx.energy) * k(fx.energy, energy);
      fx.ca = fx.energy * fx.energy * 0.008;
    }
    p.ok = true;
    p.x = pos.x; p.y = pos.y; p.z = pos.z;
    p.yaw = ang[0]; p.pitch = ang[1]; p.roll = ang[2];

    const aspect = size.width / size.height;
    fov *= 1 + Math.max(0, 1.15 - aspect) * 0.9; // widen on portrait phones so scenes still fit
    fov = Math.min(88, fov + fx.energy * 5); // a little extra stretch while moving fast

    const calm = 1 - smooth((rig.time - (BEATS.BOOTH_B + 1)) / 4); // 1 normally → 0 when the form locks
    // pointer is low-passed slowly so a flick of the mouse never jerks the picture
    const kp = 1 - Math.exp(-2.2 * dt);
    ptr.current.x += (state.pointer.x - ptr.current.x) * kp;
    ptr.current.y += (state.pointer.y - ptr.current.y) * kp;

    const t = state.clock.elapsedTime;
    const dxd = (Math.sin(t * 0.45) * 0.035 + ptr.current.x * 0.08) * calm;
    const dyd = (Math.sin(t * 0.63 + 1.3) * 0.025 + ptr.current.y * 0.04) * calm;
    camera.position.set(pos.x + dxd, pos.y + dyd, pos.z);
    camera.quaternion.setFromEuler(eul.set(ang[1] + (ptr.current.y * 0.006 + Math.sin(t * 0.63) * 0.002) * calm, ang[0] - ptr.current.x * 0.01 * calm, ang[2], 'YXZ'));
    if (Math.abs(camera.fov - fov) > 0.001) {
      camera.fov = fov;
      camera.updateProjectionMatrix();
    }
    if (window.__story?.fxForce) Object.assign(fx, window.__story.fxForce);
  });
  return null;
}
