# Sushant Chauhan: 3D scrollytelling portfolio

React + Vite, React Three Fiber, drei, Lenis, Tailwind v4, postprocessing, Web Audio.
One continuous camera flight through seven scenes. Scrolling is the only input.

```bash
npm install
npm run dev        # http://localhost:5173
npm run build
```

Open the site, press **Enter with sound** (browsers only allow audio after a click), then scroll *slowly*:
the story is paced to be read.

## 1. Directory structure

```
portfolio-3d/
├─ index.html                      fonts (Fraunces, Hanken Grotesk, Caveat)
├─ public/models/                  optional .glb files (see README inside)
└─ src/
   ├─ main.jsx  App.jsx  index.css
   ├─ config/
   │  ├─ cv.js                     ALL copy: bio, skills→coaches, projects, timeline
   │  └─ storyboard.js             beats, dwell stops, camera keys, world layout, FEEL knobs
   ├─ rig/                         the scroll → camera engine
   │  ├─ engine.js  Engine.jsx     Lenis → damped story clock → timeline (ONE pipeline)
   │  ├─ keyframes.js              Hermite tracks + SmoothDamp spring
   │  ├─ timeline.js               every animated value as a pure function of time
   │  ├─ path.js                   the camera as one 7-channel Hermite track [pos, yaw, pitch, roll, fov]
   │  ├─ rig.js                    shared mutable state (door, trainX, planeX, roadU, write[]…)
   │  ├─ CameraRig.jsx             applies the camera track; measures its speed → fx (+ faint drift, soft mouse parallax)
   │  ├─ fx.js  WhipBlur.jsx       motion-driven blur / chromatic split / vignette pulse
   │  ├─ Atmosphere.jsx            sky dome, fog, sun, distant mountain ranges (follow rig.atmo)
   │  ├─ LightPool.jsx             the two point lights every scene borrows (see §5)
   │  ├─ Effects.jsx               Bloom, depth-of-field (oak only), tone-map, vignette, SMAA
   │  ├─ SceneGroup.jsx            renders a scene only inside its time window
   │  └─ hooks.js                  useFade (DOM overlays), flicker()
   ├─ audio/ambient.js             procedural ambient sound (no audio files)
   ├─ scenes/                      Entrance, Meadow, Oak, Train, Sky, StoneWall, DirtRoad, PhoneBooth
   ├─ shared/                      Grass (instanced), Clouds (instanced), reliefMaterial (3D bricks),
   │                               textures, OptionalGLTF, utils
   └─ ui/                          EntryGate, IntroOverlay, ProgressHUD, SoundToggle, ContactForm
```

## 2. How the pieces connect

```
wheel/touch ─► Lenis (soft scroll position)
            ─► target time = scroll% × TOTAL
            ─► critically-damped spring, speed-capped ─► rig.time   (the "story clock")
            ─► timeline tracks ─► rig (plain object) ─► camera · scenes · lights · audio · HUD
```

* `#scroll-spacer` is `TOTAL × SCROLL_VH_PER_UNIT` vh tall. That height is the story length.
* Everything runs inside R3F's frame loop (`<Engine/>`, priority −100), so input → state → render happen in
  strict order each frame. There is no second animation loop.
* Scenes never listen to scroll. They read `rig.*` inside `useFrame` (never React state).

### Why it feels smooth

Smoothing happens **once**, upstream, in two stages, and everything downstream is a smooth function of that clock:

1. **Lenis** with `lerp` (frame-rate independent) and a reduced `wheelMultiplier`.
2. **A spring on the story clock itself** (`smoothDamp`). A wheel notch is a *step* in the target; first-order
   smoothing turns a step into an instant velocity jump, which reads as "reactive". The spring has to accelerate
   first, so every start and stop is soft. A speed cap means a hard fling can only ever play the story at a cinematic
   pace (a scrollbar drag, which has a large gap to cover, is allowed to fly faster).
3. All motion is **Hermite keyframe tracks** (`keyframes.js`): velocity is continuous at every key and tracks can
   never overshoot. The old camera eased every segment to a stop and spread waypoints evenly in `pathT` regardless of
   distance (the sky→wall flight covered ~66 world units in 5 scroll units, i.e. fast-forward).

Tune the feel in `storyboard.js → FEEL` (`wheel`, `lenisLerp`, `smoothTime`, `maxSpeed`).

### Pacing = dwell stops

Reading scenes are built from stops where things come to a near-rest, then glide to the next:

| Scene | What rests | Knob |
|---|---|---|
| 3 Train | each coach is centred and lit (loco nameplate first, then 7 coaches) | `TRAIN_STEP`, `TRAIN_HOLD` |
| 5 Wall | camera rests on each of the 5 project frames | `WALL_STEP`, `WALL_HOLD` |
| 6 Road | camera rests at each of the 8 milestones while the text is engraved by time (`rig.write[i]`), so the camera can never leave before the writing finishes | `ROAD_STEP`, `ROAD_HOLD`, `writeWindow()` |
| 7 Booth | rests on the contact signpost, then dollies right up to a small note | `BOOTH_*` |

### Transitions = whips

Every scene change is **rest → WHIP → land**: a short, sudden, eased burst with FOV punch and roll, between two rests
(see `CAMERA_HEAD` in `storyboard.js`):

| Transition | The move |
|---|---|
| Door → Oak | push in, then a wide-angle **rush** through the doorway (FOV 46→64) with a light flash |
| Oak → Train | **banking whip pan** to the right (yaw −46°, roll −9°), straightening out facing the rails |
| Train → Sky | **whip straight up** (pitch 64°, FOV 72): the frame is pure sky for a beat, then a tilt-down **reveal** of the horizon |
| Sky → Wall | tip over and **dive** (pitch −30°), crest over the hills, flare out with a small overshoot at the wall |
| Wall → Road | **banked swing** left (yaw 98°) off the wall, then a crane up to the drone |
| Road → Booth | low banked **swoop** around the booth while the FOV squeezes 64→40 |

* The camera is stored as **angles** (`pos, yaw, pitch, roll, fov`), not a look-at point, so a whip turns at a uniform rate
  and can be shaped (overshoot, bank) directly. `K(...)` keys aim at a point, `KA(...)` keys give angles; `path.js` converts.
* **Motion-driven effects.** `CameraRig` measures the camera's *real* angular and forward speed each frame and writes `rig/fx.js`:
  directional + radial **motion blur** and a **chromatic split** (`WhipBlur.jsx`), a **vignette pulse**, a small extra **FOV kick**,
  and the **air-rush sound** (pitch + volume sweep up). Because it is measured, a slow scroll stays crisp and a hard scroll streaks.
  The blur pass is disabled (zero cost) while the camera is calm.
* To change a transition: edit its keys. Shorter time between keys = more sudden; bigger angle/FOV/roll = more dramatic.

The story is ~194 units (`TOTAL`) = ~1940vh. Want it shorter or longer? Change the `*_STEP` constants, or
`SCROLL_VH_PER_UNIT`, and everything re-times (all beats derive from them).

The timeline is pure, so you can test it in Node without a browser: `evaluate(rig, 52); console.log(rig.trainX)`.

## 3. Scenes

| Scene | What happens |
|---|---|
| 1 Entrance | relief-shaded brick wall; door opens in three stages (it creaks as fast as it swings); light spills out; step through |
| 2 Oak | camera rests while the plaque is read; depth-of-field blurs the background; leaf notes fall slowly; then a banking whip pan |
| 3 Train | camera parked; `rig.trainX` glides the train past with a rest at each coach |
| 4 Sky | whip up into pure sky, tilt-down reveal of the horizon, hazy mountain ranges, clouds at four depths; a plane flies a diagonal through depth (far right → near left) with yaw and bank, trailing a lit, rippling banner; then a dive over the hills to the wall |
| 5 Wall | camera descends past five framed projects, resting on each |
| 6 Road | drone along the road, resting at each milestone while a stick engraves it |
| 7 Booth | rest on the signpost; dolly in to a small paper note on the glass (0.44×0.60 units, camera 1.27 away); the form is pinned to it |

## 4. The complex bits

* **3D bricks** (`shared/reliefMaterial.js`): a `MeshStandardMaterial` patched with a procedural brick height-field in
  *world space*: steep-parallax ray-march (mortar genuinely recesses as the camera moves), bump normals from the
  height gradient, per-brick colour, grime, joint AO, and a distance fade (`fwidth`) so it can never shimmer. No textures.
* **Grass** (`shared/Grass.jsx`): tapered, curved 4-segment blades, scattered in clumps, one draw call per patch.
  Wind is a travelling wave in world space; blades shrink to nothing with distance instead of becoming sub-pixel slivers.
* **Door** (`scenes/EntranceScene.jsx`): leaf group's origin is the hinge; a drei `<Html transform>` sign is a child, so
  the DOM swings with the door. Light = HDR portal plane + additive cones + sparkles; Bloom turns HDR into glow.
* **Train** (`scenes/TrainScene.jsx`): one group moved by `rig.trainX`; each coach computes its distance from screen centre
  → `lit`, which drives emissive window planes and the CSS variable `--lit` on the DOM panel.
* **Sky** (`rig/Atmosphere.jsx`): a gradient sky dome plus three hazy mountain rings; fog is tinted with the horizon colour.

## 5. Performance notes (what was changed and why)

* **Constant light count.** three.js compiles shaders per light-count; scenes used to own point lights inside
  `<SceneGroup>`s, so every time one toggled `visible`, *every* material recompiled mid-scroll (a hitch).
  `LightPool.jsx` keeps two point lights alive for the whole story and moves/dims them per scene.
* **Pre-warm.** `<Preload all/>` compiles every program and uploads every texture behind the entry gate.
* **Instancing.** Clouds: ~130 meshes → 1 draw call. Grass: one draw call per patch.
* **No coplanar faces / no HDR-MSAA.** See the changelog (door flicker). `multisampling={0}` + SMAA.
* **Depth-of-field only mounts while visible** (oak scene). The whip-blur pass is compiled behind the gate, then disabled while the camera is calm.
* **Adaptive resolution.** `<PerformanceMonitor>` steps the pixel ratio 1.5 → 1 → 0.75 on slow GPUs and back up.
* **DOM panels use `display:none` when faded out** (not just `opacity`/`visibility`), so hidden panels cost no layout/paint.
* **GSAP/ScrollTrigger removed.** They were only used for the scrub; two animation loops are now one.

Debug: add `?debug` to the URL → `window.__story.goto(t)` jumps the story clock, `__story.gl.info` has renderer stats.

## 6. Sound

`audio/ambient.js` synthesises every sound with the Web Audio API (no files to ship or license). Each scene has a bed
that crossfades with the story clock, and many react to what is on screen: door creak ∝ door speed, rail clacks ∝ train
distance travelled, plane drone with Doppler + stereo pan from the plane's position, stick scratching while text is written.
A global air-whoosh follows camera speed. The mute button is bottom-left. Levels sit around −26 dBFS RMS (under the content).
To use recorded audio instead, replace a bed's builder in `BEDS` with an `<audio>`/buffer source routed to the same bus.

## 7. Gotchas worth knowing

* **drei `<Html transform>` sizing:** 1 DOM px = `distanceFactor / 400` world units. Use
  `dfFor(pxPerUnit)` from `shared/utils.js`. On-screen text scale ≈ `(screenH / visibleWorldH) / pxPerUnit`.
  Each panel's `PX` constant is the one knob to turn if text looks too big/small on your screen.
* CSS3D panels sit on top of the canvas (no occlusion), so every panel fades by story time (`useFade`).
* Textures are generated on canvas (stone, sand, paper, banner, meadow soil), so there are no image files to load.
  Fonts load from Google Fonts; canvas text redraws when they arrive.
* The fixed canvas has `pointer-events` on, but wheel/touch still scroll the page because those events bubble.

## 8. Content map (CV → site)

All text lives in `config/cv.js`. Everything is from the CV except: the one-line `hook`, and three links
the CV only shows as labels (`email`, `linkedin`, `portfolio`, marked `TODO`). Hackathon dates are not in
the CV, so they appear as "Hackathons" rather than a year.

The storyboard mentioned "Jal-Dhara" and "VOD web platforms". Neither is in the CV, so the wall shows the five
projects that are: Student Management System, Library Management System, Personal Portfolio Websites,
Horror Game: Forest Level Design, 3D Modeling: Game Assets. Add them to `PROJECTS` if you want them
(add a frame position to `WALL_FRAMES` in `storyboard.js`, then add a stop in the camera keys).

## 9. Contact form

`ContactForm.jsx` POSTs `{ name, email, message }` JSON to `VITE_CONTACT_ENDPOINT` (default `/api/contact`).
Point it at Formspree, a Resend/Nodemailer serverless function, or your Express route.

## 10. Changelog

### Smoothness
* New scroll engine (Lenis lerp → spring-damped story clock → Hermite tracks), replacing ScrollTrigger scrub +
  per-segment eased tweens. Lower wheel sensitivity, speed cap, one smoothing stage instead of several.
* Reading scenes got real dwell stops; the road text is written by time and finishes before the camera leaves.
* Story re-timed to ~194 units; the sky→wall flight is 9.7 (was ~13+) world units per scroll unit at peak.

### Transitions
* Restored and extended the sudden whips (up into the sky, down onto the wall) and gave every scene change its own move:
  door rush, banking whip pan, whip-up + reveal, dive + flare, banked swing, swoop. Orientation is now keyed as angles.
* Motion blur, chromatic split, vignette pulse, FOV kick and air-rush sound, all driven by the camera's actual speed.

### Fixes
* **Door flashing:** frame/brick coplanar faces (z-fighting), duplicate ground planes at y=0, texture stretched across the
  jambs, and HDR-MSAA edge crawl. All removed (see the header comment in `EntranceScene.jsx`).
* **Train first coach:** the loco nameplate now rests dead-centre on arrival with coach 1 entering beside it; neighbouring
  coaches stay softly lit; text is larger.
* **Phone booth:** the note is small in the world (0.44×0.60) and the camera ends 1.27 away so it fills the screen.
* Pre-existing: black screen from `.toArray()` on `BOOTH.sunPos` (already an array) is still fixed.

### New
* Procedural 3D brick shader; dense clumped wind grass + flowers; gradient sky dome and layered distant mountains;
  detailed airplane flying a diagonal in depth; instanced layered clouds; ambient sound for every scene; entry gate;
  clickable chapter dots; adaptive resolution.

