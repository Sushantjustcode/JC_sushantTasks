import { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { Html, RoundedBox, Sparkles } from '@react-three/drei';
import { rig } from '../rig/rig';
import { SceneGroup } from '../rig/SceneGroup';
import { OptionalGLTF } from '../shared/OptionalGLTF';
import { useGradientAlpha } from '../shared/textures';
import { createReliefMaterial } from '../shared/reliefMaterial';
import { clamp01, dfFor, mulberry32 } from '../shared/utils';
import { MODELS, WORLD } from '../config/storyboard';

/**
 * SCENE 1: THE ENTRANCE
 * ─────────────────────
 * 3D: relief-shaded red brick wall (see shared/reliefMaterial.js), hanging vines + flowers,
 *     white wooden door that swings open, additive light-shaft cones + dust motes.
 * HTML interplay:
 *   • <DoorSign/> is a drei <Html transform> child of the door-leaf group, so the DOM
 *     sign swings open WITH the 3D door and fades as it opens.
 *   • The big intro overlay lives in the DOM (ui/IntroOverlay) and is faded by the
 *     same story clock that opens the door, so both are on one clock.
 * Driven by rig.door / rig.glow (see rig/timeline.js). The warm door light is a slot in
 * rig/LightPool.jsx – no light lives in this scene any more.
 *
 * ── Why the door used to "flash" (all fixed here) ──────────────────────────────────────
 *  1. The frame posts/header sat INSIDE the brick boxes, so their inner faces were coplanar
 *     with the brick jambs → z-fighting. Now the brick opening is cut wider than the frame and
 *     every frame face is offset from every brick face by ≥ 1 cm (no coplanar overlaps).
 *  2. A separate "lawn" plane lay at y=0 on top of the meadow plane at y=0 → z-fighting on the
 *     grass in front of the door. The lawn is gone; there is one ground plane for the story.
 *  3. The brick texture was UV-stretched across the narrow jambs → shimmering. Bricks are now
 *     a world-space shader with distance fade (no minified high-frequency texture).
 *  4. HDR MSAA made the bright portal edge crawl → SMAA after tone-mapping (rig/Effects.jsx).
 */

const { doorW: DW, doorH: DH, wallW: WW, wallH: WH, wallT: WT } = WORLD.entrance;
const OPEN = THREE.MathUtils.degToRad(105);
const WHITE = '#f3efe6';
const FR = 0.12; // frame member width
const OPEN_W = DW + FR * 2 - 0.02; // opening cut in the brick (frame overlaps it by 1 cm per side)
const OPEN_H = DH + FR - 0.01;

const brickMat = createReliefMaterial({});
const plinthMat = createReliefMaterial({ brick: [0.9, 0.28], mortar: 0.04, relief: 0.06, colA: '#6e6a62', colB: '#8d887c', colC: '#4e4b46', mortarCol: '#9a948a', roughness: 1 });
const frameMat = new THREE.MeshStandardMaterial({ color: WHITE, roughness: 0.6 });
const stoneMat = new THREE.MeshStandardMaterial({ color: '#a29c90', roughness: 1 });

/** Hanging vines (tube + leaf blobs + flower heads) that sway on their own phase. */
function Vines() {
  const refs = useRef([]);
  const vines = useMemo(() => {
    const r = mulberry32(21);
    const palette = ['#ff8fb1', '#ffd34d', '#ffffff', '#ff6f61'];
    return Array.from({ length: 10 }, (_, i) => {
      const len = 1.2 + r() * 2.4;
      const pts = Array.from({ length: 6 }, (_, k) => new THREE.Vector3(Math.sin(k * 1.3 + i) * 0.14, (-k / 5) * len, 0));
      const curve = new THREE.CatmullRomCurve3(pts);
      return {
        x: (i / 9 - 0.5) * (WW - 1.5) + (r() - 0.5) * 0.6,
        curve,
        phase: r() * 6,
        leaves: Array.from({ length: 9 }, () => ({ p: curve.getPoint(r()), s: 0.07 + r() * 0.06, a: r() * 3 })),
        flowers: Array.from({ length: 3 + Math.floor(r() * 4) }, () => ({ p: curve.getPoint(0.2 + r() * 0.8), s: 0.06 + r() * 0.05, c: palette[Math.floor(r() * 4)] })),
      };
    });
  }, []);
  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    refs.current.forEach((g, i) => g && (g.rotation.z = Math.sin(t * 0.8 + vines[i].phase) * 0.045));
  });
  return (
    <group>
      {vines.map((v, i) => (
        <group key={i} ref={(el) => (refs.current[i] = el)} position={[v.x, WH - 0.05, WT / 2 + 0.06]}>
          <mesh>
            <tubeGeometry args={[v.curve, 24, 0.022, 5]} />
            <meshStandardMaterial color="#3f7d34" roughness={0.9} />
          </mesh>
          {v.leaves.map((l, k) => (
            <mesh key={k} position={l.p} scale={[l.s * 1.6, l.s, l.s * 0.5]} rotation={[0, 0, l.a]}>
              <icosahedronGeometry args={[1, 0]} />
              <meshStandardMaterial color="#4f9a3d" flatShading />
            </mesh>
          ))}
          {v.flowers.map((f, k) => (
            <mesh key={k} position={f.p} scale={f.s}>
              <icosahedronGeometry args={[1, 1]} />
              <meshStandardMaterial color={f.c} roughness={0.7} flatShading />
            </mesh>
          ))}
        </group>
      ))}
    </group>
  );
}

/** A DOM sign mounted ON the door: it is a child of the leaf group, so it rotates with the 3D door. */
function DoorSign() {
  const ref = useRef();
  useFrame(() => {
    if (ref.current) ref.current.style.opacity = String(1 - clamp01(rig.door * 4));
  });
  return (
    <Html transform center distanceFactor={dfFor(130)} position={[(DW - 0.04) / 2, 2.25, 0.05]}>
      <div ref={ref} className="door-sign">
        Come in
        <small>scroll to open the door</small>
      </div>
    </Html>
  );
}

function ProceduralEntrance({ leafRef }) {
  const sideW = (WW - OPEN_W) / 2;
  const frameZ = 0.065;
  const frameD = 0.73; // z from -0.30 to 0.43: never flush with the brick's -0.35 / +0.35 faces
  return (
    <group>
      {/* brick: two piers + a lintel, cut around a slightly wider opening than the frame needs */}
      <mesh material={brickMat} position={[-(OPEN_W / 2 + sideW / 2), WH / 2, 0]}><boxGeometry args={[sideW, WH, WT]} /></mesh>
      <mesh material={brickMat} position={[OPEN_W / 2 + sideW / 2, WH / 2, 0]}><boxGeometry args={[sideW, WH, WT]} /></mesh>
      <mesh material={brickMat} position={[0, OPEN_H + (WH - OPEN_H) / 2, 0]}><boxGeometry args={[OPEN_W, WH - OPEN_H, WT]} /></mesh>

      {/* stone plinth (split around the doorway) + stone lintel slab */}
      {[-1, 1].map((sd) => {
        const x0 = DW / 2 + FR; // outer face of the frame post
        const len = WW / 2 + 0.1 - x0;
        return (
          <mesh key={sd} material={plinthMat} position={[sd * (x0 + len / 2), 0.14, 0]}>
            <boxGeometry args={[len, 0.28, WT + 0.12]} />
          </mesh>
        );
      })}
      <mesh material={stoneMat} position={[0, DH + FR + 0.1, 0.15]}><boxGeometry args={[DW + 0.9, 0.2, 0.58]} /></mesh>

      {/* white door frame – inner faces are the visible jambs; nothing else shares their plane */}
      {[-1, 1].map((sd) => (
        <mesh key={sd} material={frameMat} position={[sd * (DW / 2 + FR / 2), DH / 2, frameZ]}>
          <boxGeometry args={[FR, DH, frameD]} />
        </mesh>
      ))}
      <mesh material={frameMat} position={[0, DH + FR / 2, frameZ]}><boxGeometry args={[DW + FR * 2, FR, frameD]} /></mesh>

      {/* stone step: starts in front of the frame so it never overlaps the doorway */}
      <mesh material={stoneMat} position={[0, 0.06, 0.83]}><boxGeometry args={[DW + 0.7, 0.12, 0.76]} /></mesh>

      {/* door leaf: group origin = hinge, so rotation.y swings it around the hinge edge */}
      <group ref={leafRef} position={[-DW / 2 + 0.02, 0, 0.14]}>
        <RoundedBox args={[DW - 0.04, DH - 0.02, 0.07]} radius={0.012} smoothness={3} position={[(DW - 0.04) / 2, DH / 2, 0]} material={frameMat} />
        {[0.5, 1.45, 2.4].map((y, i) => (
          <RoundedBox key={i} args={[DW - 0.5, i === 1 ? 0.7 : 0.55, 0.035]} radius={0.01} smoothness={3} position={[(DW - 0.04) / 2, y, 0.05]}>
            <meshStandardMaterial color="#e3ddcf" roughness={0.55} />
          </RoundedBox>
        ))}
        <mesh position={[DW - 0.2, 1.05, 0.085]}>
          <sphereGeometry args={[0.045, 16, 16]} />
          <meshStandardMaterial color="#c9a35a" metalness={0.85} roughness={0.28} />
        </mesh>
        <DoorSign />
      </group>

      <Vines />
    </group>
  );
}

/** Portal glow + volumetric-looking cones + dust motes (the warm point light is in rig/LightPool). */
function LightPouring() {
  const alpha = useGradientAlpha();
  const portal = useRef();
  const cones = useRef();
  const portalMat = useMemo(() => {
    const m = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false });
    m.color.setRGB(1.75, 1.55, 1.15); // HDR (>1) so bloom picks it up, but not so hot that the doorway whites out
    return m;
  }, []);
  const coneMats = useMemo(
    () =>
      [0.9, 0.8, 0.7].map(() => {
        const m = new THREE.MeshBasicMaterial({ alphaMap: alpha, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false });
        m.color.setRGB(1.6, 1.45, 1.1);
        return m;
      }),
    [alpha]
  );

  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    const fl = 1 + Math.sin(t * 7.3) * 0.04 + Math.sin(t * 13.1 + 2) * 0.03;
    const open = clamp01(rig.door * 1.6);
    portalMat.opacity = clamp01(rig.glow) * 0.88;
    coneMats.forEach((m, i) => (m.opacity = open * (0.07 + i * 0.03) * fl * (0.6 + 0.4 * Math.sin(t * 0.6 + i * 2))));
  });

  return (
    <group>
      <mesh ref={portal} position={[0, DH / 2, -0.12]} material={portalMat}>
        <planeGeometry args={[DW - 0.04, DH - 0.02]} />
      </mesh>
      <group ref={cones} position={[0, DH / 2 - 0.1, 0.1]}>
        {[2.6, 1.8, 1.1].map((r, i) => (
          <mesh key={i} position={[0, 0, 3.1]} rotation={[Math.PI / 2, 0, 0]} material={coneMats[i]}>
            <cylinderGeometry args={[r, 0.25, 6, 32, 1, true]} />
          </mesh>
        ))}
      </group>
      <Sparkles count={50} scale={[3.5, 3, 5]} position={[0, 1.6, 3]} size={4} speed={0.4} opacity={0.8} color="#fff6d8" />
    </group>
  );
}

export default function EntranceScene() {
  const leaf = useRef(null);
  useFrame(() => {
    if (leaf.current) leaf.current.rotation.y = rig.door * OPEN;
  });
  return (
    <SceneGroup id="entrance">
      <OptionalGLTF
        url={MODELS.entrance}
        onReady={(root) => {
          leaf.current = root.getObjectByName('DoorLeaf');
        }}
        fallback={<ProceduralEntrance leafRef={leaf} />}
      />
      <LightPouring />
    </SceneGroup>
  );
}
