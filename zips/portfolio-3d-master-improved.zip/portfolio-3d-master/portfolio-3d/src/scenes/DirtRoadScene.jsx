import { useEffect, useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { Sparkles } from '@react-three/drei';
import { rig } from '../rig/rig';
import { SceneGroup } from '../rig/SceneGroup';
import { GrassInstances, GRASS_DENSITY } from '../shared/Grass';
import { useSandTexture } from '../shared/textures';
import { clamp01, mulberry32 } from '../shared/utils';
import { TIMELINE } from '../config/cv';
import { ROAD, MILESTONE_U } from '../config/storyboard';

/**
 * SCENE 6: THE DIRT ROAD (career / education timeline)
 * A sand ribbon is extruded along ROAD (the same spline the drone camera follows).
 * Each TIMELINE entry is "written" into a clearing with a stick: a canvas texture is
 * re-drawn with a growing clip (line by line, left → right) while a 3D stick tip follows
 * the writing front. Progress comes from rig.roadU, the camera's position on the road.
 */

const N = TIMELINE.length;
const roadWidth = (u) => {
  let w = 3.2;
  for (let i = 0; i < N; i++) w += 6.4 * Math.exp(-(((u - MILESTONE_U(i)) / 0.032) ** 2)); // clearing at each milestone
  return w;
};

function RoadRibbon() {
  const sand = useSandTexture();
  const geo = useMemo(() => {
    const SEG = 240;
    const total = ROAD.getLength();
    const pos = [];
    const uv = [];
    const idx = [];
    for (let i = 0; i <= SEG; i++) {
      const u = i / SEG;
      const p = ROAD.getPointAt(u);
      const t = ROAD.getTangentAt(u);
      const w = roadWidth(u) / 2;
      pos.push(p.x - t.z * w, 0.02, p.z + t.x * w, p.x + t.z * w, 0.02, p.z - t.x * w);
      uv.push(0, (u * total) / 5, 1, (u * total) / 5);
      if (i < SEG) {
        const a = i * 2;
        idx.push(a, a + 2, a + 1, a + 1, a + 2, a + 3);
      }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    g.setIndex(idx);
    g.computeVertexNormals();
    return g;
  }, []);
  return (
    <mesh geometry={geo}>
      <meshStandardMaterial map={sand} roughness={1} side={THREE.DoubleSide} />
    </mesh>
  );
}

function RoadGrass() {
  // Dense verges: blades are clumped along both sides of the road and thin out with distance.
  const data = useMemo(() => {
    const r = mulberry32(77);
    const gauss = () => Math.sqrt(-2 * Math.log(Math.max(1e-6, r()))) * Math.cos(6.2831853 * r());
    const total = ROAD.getLength();
    const out = [];
    const step = 0.42 / total;
    for (let u = 0.004; u < 0.998; u += step) {
      const p = ROAD.getPointAt(u);
      const t = ROAD.getTangentAt(u);
      for (const side of [-1, 1]) {
        const half = roadWidth(u) / 2;
        for (let c = 0; c < 3; c++) {
          const off = half + 0.15 + -Math.log(1 - r() * 0.98) * 2.2;
          const cx = p.x - t.z * off * side;
          const cz = p.z + t.x * off * side;
          const rad = 0.35 + r() * 0.5;
          const hf = 0.7 + r() * 0.7;
          const tint = r();
          for (let k = 0; k < Math.round(11 * GRASS_DENSITY); k++) {
            const x = cx + gauss() * rad;
            const z = cz + gauss() * rad;
            if ((x - p.x) ** 2 + (z - p.z) ** 2 < half * half * 0.9) continue; // keep the road surface itself clear
            out.push(x, z, hf * (0.75 + r() * 0.5), 0.9 + r() * 0.8, r() * 6.2832, Math.min(1, tint * 0.6 + r() * 0.4));
          }
        }
      }
    }
    return new Float32Array(out);
  }, []);
  return <GrassInstances data={data} height={0.85} colors={['#587a2e', '#d2c56a']} />;
}

const CW = 1024;
const CH = 400;
const PLANE_W = 9.2;
const PLANE_H = (PLANE_W * CH) / CW;

function fit(g, text, size, weight, family) {
  let s = size;
  g.font = `${weight} ${s}px ${family}`;
  while (g.measureText(text).width > CW - 90 && s > 20) {
    s -= 2;
    g.font = `${weight} ${s}px ${family}`;
  }
  return s;
}

/** One engraved entry. Re-draws its canvas only while the reveal progress is changing. */
function Milestone({ item, u, index }) {
  const stick = useRef();
  const last = useRef(-1);
  const p = ROAD.getPointAt(u);
  const t = ROAD.getTangentAt(u);
  const rotY = Math.atan2(-t.x, -t.z); // text reads left→right on screen when heading along the road

  const { canvas, tex, ctx, lines } = useMemo(() => {
    const canvas = document.createElement('canvas');
    canvas.width = CW;
    canvas.height = CH;
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 8;
    const lines = [
      { text: item.when, size: 130, weight: 700, y: 120, family: 'Caveat, "Segoe Script", cursive' },
      { text: item.title, size: 76, weight: 700, y: 215, family: 'Caveat, "Segoe Script", cursive' },
      { text: item.place, size: 54, weight: 600, y: 285, family: 'Caveat, "Segoe Script", cursive' },
      ...(item.note ? [{ text: item.note, size: 48, weight: 600, y: 345, family: 'Caveat, "Segoe Script", cursive' }] : []),
    ];
    return { canvas, tex, ctx: canvas.getContext('2d'), lines };
  }, [item]);

  const draw = (prog) => {
    ctx.clearRect(0, 0, CW, CH);
    const L = lines.length;
    let front = { x: 0, y: 0 };
    lines.forEach((ln, k) => {
      const lp = clamp01(prog * L - k);
      if (lp <= 0) return;
      const size = fit(ctx, ln.text, ln.size, ln.weight, ln.family);
      const w = ctx.measureText(ln.text).width;
      const x0 = (CW - w) / 2;
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, 0, x0 + w * lp + 6, CH);
      ctx.clip();
      ctx.font = `${ln.weight} ${size}px ${ln.family}`;
      ctx.textBaseline = 'alphabetic';
      ctx.fillStyle = 'rgba(255,236,196,0.7)'; // sunlit lip of the groove
      ctx.fillText(ln.text, x0 + 2.5, ln.y + 2.5);
      ctx.fillStyle = '#5a3a1a'; // shadowed bottom of the groove
      ctx.fillText(ln.text, x0, ln.y);
      ctx.restore();
      if (lp < 1 || k === L - 1) front = { x: x0 + w * lp, y: ln.y };
    });
    tex.needsUpdate = true;
    return front;
  };

  useEffect(() => {
    document.fonts?.ready.then(() => (last.current = -1)); // redraw once Caveat has loaded
    return () => tex.dispose();
  }, [tex]);

  useFrame(({ clock }) => {
    const prog = rig.write[index]; // 0…1, driven by story time (rig/timeline.js) – never outruns the reader
    if (Math.abs(prog - last.current) > 0.002) {
      last.current = prog;
      const f = draw(prog);
      if (stick.current) {
        stick.current.position.set((f.x / CW - 0.5) * PLANE_W, 0.05, (f.y / CH - 0.5) * PLANE_H);
        stick.current.visible = prog > 0 && prog < 0.999;
      }
    }
    if (stick.current?.visible) stick.current.position.y = 0.05 + Math.sin(clock.elapsedTime * 20) * 0.015; // scratching wobble
  });

  return (
    <group position={[p.x, 0, p.z]} rotation-y={rotY}>
      <mesh rotation-x={-Math.PI / 2} position={[0, 0.05, 0]}>
        <planeGeometry args={[PLANE_W, PLANE_H]} />
        <meshStandardMaterial map={tex} transparent depthWrite={false} roughness={1} polygonOffset polygonOffsetFactor={-2} />
      </mesh>
      <group ref={stick} visible={false}>
        <mesh position={[0.45, 0.8, 0]} rotation={[0, 0, -0.8]}>
          <cylinderGeometry args={[0.035, 0.05, 1.8, 6]} />
          <meshStandardMaterial color="#6b4a2b" roughness={1} />
        </mesh>
      </group>
    </group>
  );
}

export default function DirtRoadScene() {
  const mid = ROAD.getPointAt(0.5);
  return (
    <>
      <SceneGroup id="road">
        <RoadRibbon />
        <RoadGrass />
        {TIMELINE.map((item, i) => (
          <Milestone key={item.title + item.when} item={item} u={MILESTONE_U(i)} index={i} />
        ))}
        <Sparkles count={120} scale={[90, 5, 80]} position={[mid.x, 2.5, mid.z]} size={6} speed={0.3} color="#ffe29a" />
      </SceneGroup>
    </>
  );
}
