import { useCallback, useMemo } from 'react';
import { SceneGroup } from '../rig/SceneGroup';
import { GrassPatch, FlowerPatch } from '../shared/Grass';
import { useMeadowGroundTexture } from '../shared/textures';
import { TRAIN, TOTAL, BEATS } from '../config/storyboard';

/**
 * The world's ground (ONE plane for the whole story – the old per-scene planes overlapped at
 * y=0 and z-fought), plus the dense swaying grass, wild flowers and low hills that scenes
 * 1–5 share. Far hills live in the mountain ring (see rig/Atmosphere.jsx).
 */
const OAK = [-1.8, -13];
const GROUND_END = TOTAL + 1;

export default function MeadowScene() {
  const ground = useMeadowGroundTexture();
  useMemo(() => ground.repeat.set(44, 36), [ground]);

  // keep clear: the track bed, the doorstep and the oak trunk
  const exclude = useCallback(
    (x, z) =>
      Math.abs(z - TRAIN.z) < 2.5 ||
      (Math.abs(x) < 1.6 && z > -1 && z < 1.7) ||
      (x - OAK[0]) ** 2 + (z - OAK[1]) ** 2 < 3.4,
    []
  );

  // short, lush lawn in front of the door (so the step and door stay visible) …
  const lawn = useMemo(() => [{ x0: -13, x1: 13, z0: -0.4, z1: 9.5, density: 60 }, { x0: -40, x1: 40, z0: -0.4, z1: 14, density: 8 }], []);
  // … and the tall meadow behind the wall, which the camera walks into after the door opens
  const near = useMemo(() => [{ x0: -14, x1: 14, z0: -27, z1: -0.4, density: 30 }], []);
  const wide = useMemo(() => [{ x0: -46, x1: 46, z0: -27, z1: -0.4, density: 4.5 }], []);
  const trainFront = useMemo(() => [{ x0: -24, x1: 24, z0: -36.2, z1: -27, density: 34 }], []);
  const far = useMemo(() => [{ x0: -60, x1: 60, z0: -92, z1: -39, density: 2.6 }], []);
  const wallBase = useMemo(() => [{ x0: -16, x1: 16, z0: -109, z1: -101, density: 36 }, { x0: -40, x1: 40, z0: -112, z1: -96, density: 3 }], []);
  const flowerRects = useMemo(() => [{ x0: -16, x1: 16, z0: -27, z1: 9 }, { x0: -22, x1: 22, z0: -36.2, z1: -27 }], []);
  const hills = useMemo(
    () => [[-72, -92, 36, 9], [64, -96, 40, 10], [104, -70, 34, 9], [-112, -60, 30, 7], [-30, -178, 70, 18], [44, -184, 62, 15]],
    []
  );

  return (
    <>
      <SceneGroup range={[0, GROUND_END]}>
        <mesh rotation-x={-Math.PI / 2} position={[0, 0, -80]}>
          <planeGeometry args={[640, 520]} />
          <meshStandardMaterial map={ground} roughness={1} />
        </mesh>
      </SceneGroup>
      <SceneGroup range={[0, BEATS.WALL_LAST_HOLD + 6]}>
        <GrassPatch rects={lawn} exclude={exclude} seed={3} height={0.36} colors={['#2f6a30', '#98c452']} />
        <GrassPatch rects={near} exclude={exclude} seed={4} height={0.85} />
        <GrassPatch rects={wide} exclude={exclude} seed={14} height={0.95} colors={['#2d6430', '#8fbf4a']} />
        <GrassPatch rects={trainFront} exclude={exclude} seed={24} height={0.9} />
        <GrassPatch rects={far} exclude={exclude} seed={34} height={1.25} clump={14} colors={['#2f6a32', '#86b84a']} />
        <GrassPatch rects={wallBase} seed={44} height={0.95} colors={['#2a5a2c', '#7fae45']} />
        <FlowerPatch rects={flowerRects} exclude={exclude} seed={6} density={0.28} />
        {hills.map(([x, z, w, h], i) => (
          <mesh key={i} position={[x, -2, z]} scale={[w, h, 18]}>
            <sphereGeometry args={[1, 24, 14]} />
            <meshStandardMaterial color={i % 2 ? '#5f9552' : '#6aa35a'} roughness={1} flatShading />
          </mesh>
        ))}
      </SceneGroup>
    </>
  );
}
