import { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { rig } from '../rig/rig';
import { SceneGroup } from '../rig/SceneGroup';
import CloudField from '../shared/Clouds';
import { OptionalGLTF } from '../shared/OptionalGLTF';
import { useBannerTexture } from '../shared/textures';
import { BEATS, MODELS, PLANE_PATH } from '../config/storyboard';

/**
 * SCENE 4: THE SKY
 * ─────────────────
 * The camera looks up from the meadow with the HORIZON in the lower third of the frame, so the
 * shot has real depth: hazy mountain ranges (rig/Atmosphere), layered clouds at different
 * distances, and a plane that flies a DIAGONAL through depth (far right → near left) with yaw
 * and bank. Because it approaches the camera it grows and shows a 3/4 view instead of a flat
 * side-on cut-out. rig.planeX (timeline) places it; the banner flaps like cloth and is lit.
 */
const { X0, X1, Z0, Z1, Y0, Y1, SCALE } = PLANE_PATH; // far end → near end of the flight path
const HEADING = Math.atan2(Z1 - Z0, X0 - X1); // yaw so the nose (−x) points along the path
const BW = 20; // banner length
const BH = BW / 4.375; // matches the 1400×320 texture

const matBody = new THREE.MeshStandardMaterial({ color: '#f3ecd9', roughness: 0.38, metalness: 0.15 });
const matRed = new THREE.MeshStandardMaterial({ color: '#c4382a', roughness: 0.4, metalness: 0.15 });
const matGlass = new THREE.MeshStandardMaterial({ color: '#16202f', roughness: 0.1, metalness: 0.6 });
const matDark = new THREE.MeshStandardMaterial({ color: '#202327', roughness: 0.8 });
const matMetal = new THREE.MeshStandardMaterial({ color: '#aab2bb', roughness: 0.3, metalness: 0.9 });

/** Fuselage / cowling: revolve a profile around the x axis. Nose at −x. */
const lathe = (pts, seg = 28) => {
  const g = new THREE.LatheGeometry(pts.map(([r, y]) => new THREE.Vector2(r, y)), seg);
  g.rotateZ(Math.PI / 2); // lathe Y axis → −X
  return g;
};

/** An airfoil section extruded along the span (z), with an elliptical taper so tips are round. */
function wingGeometry(chord, thick, span, taper = 0.55) {
  const c = chord;
  const t = thick;
  const s = new THREE.Shape();
  s.moveTo(-0.45 * c, 0);
  s.bezierCurveTo(-0.45 * c, t * 0.9, -0.15 * c, t * 1.15, 0.1 * c, t * 0.8);
  s.lineTo(0.55 * c, t * 0.12);
  s.lineTo(0.55 * c, -t * 0.04);
  s.lineTo(0.1 * c, -t * 0.28);
  s.bezierCurveTo(-0.3 * c, -t * 0.45, -0.45 * c, -t * 0.5, -0.45 * c, 0);
  const g = new THREE.ExtrudeGeometry(s, { depth: span, bevelEnabled: false, steps: 1, curveSegments: 10 });
  g.translate(0, 0, -span / 2);
  const p = g.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const k = Math.abs(p.getZ(i)) / (span / 2);
    const f = 1 - taper * k * k;
    p.setX(i, p.getX(i) * f);
    p.setY(i, p.getY(i) * f);
  }
  g.computeVertexNormals();
  return g;
}

/** A thin cylinder from a to b. */
function Strut({ a, b, r = 0.025, material = matMetal }) {
  const { pos, quat, len } = useMemo(() => {
    const va = new THREE.Vector3(...a);
    const vb = new THREE.Vector3(...b);
    const d = vb.clone().sub(va);
    return {
      pos: va.clone().add(vb).multiplyScalar(0.5).toArray(),
      quat: new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.clone().normalize()),
      len: d.length(),
    };
  }, [a, b]);
  return (
    <mesh position={pos} quaternion={quat} material={material}>
      <cylinderGeometry args={[r, r, len, 6]} />
    </mesh>
  );
}

function PlaneBody({ prop }) {
  const fuselage = useMemo(
    () => lathe([[0.02, -2.4], [0.1, -2.25], [0.2, -1.65], [0.32, -0.95], [0.42, -0.25], [0.47, 0.5], [0.48, 1.0], [0.47, 1.45]]),
    []
  );
  const cowl = useMemo(() => lathe([[0.47, 1.4], [0.5, 1.6], [0.46, 1.95], [0.34, 2.15], [0.18, 2.27], [0.0, 2.3]]), []);
  const wing = useMemo(() => wingGeometry(1.25, 0.2, 5.8), []);
  const stab = useMemo(() => wingGeometry(0.62, 0.09, 2.0, 0.4), []);
  const fin = useMemo(() => {
    const s = new THREE.Shape();
    s.moveTo(0, 0);
    s.lineTo(0.7, 0);
    s.quadraticCurveTo(0.55, 0.55, 0.42, 0.95);
    s.lineTo(0.12, 0.95);
    s.quadraticCurveTo(0.02, 0.5, 0, 0);
    const g = new THREE.ExtrudeGeometry(s, { depth: 0.07, bevelEnabled: true, bevelSize: 0.015, bevelThickness: 0.015, bevelSegments: 2 });
    g.translate(0, 0, -0.035);
    return g;
  }, []);
  return (
    <group>
      <mesh geometry={fuselage} material={matBody} scale={[1, 1, 0.92]} />
      <mesh geometry={cowl} material={matRed} scale={[1, 1, 0.92]} />
      {/* red stripe */}
      <mesh geometry={lathe([[0.4, 0.0], [0.44, 0.35], [0.475, 0.6], [0.475, 0.75], [0.44, 0.9]])} material={matRed} scale={[1.001, 1.001, 0.93]} />
      {/* cockpit */}
      <mesh position={[-0.2, 0.3, 0]} scale={[0.95, 0.62, 0.55]} material={matGlass}>
        <sphereGeometry args={[0.5, 20, 12, 0, Math.PI * 2, 0, Math.PI / 2]} />
      </mesh>
      {/* high wing + struts */}
      <mesh geometry={wing} material={matBody} position={[-0.25, 0.5, 0]} rotation={[0, 0, 0.03]} />
      <mesh geometry={wing} material={matRed} position={[-0.25, 0.505, 0]} rotation={[0, 0, 0.03]} scale={[0.42, 1.05, 1.001]} />
      {[-1, 1].map((s) => (
        <group key={s}>
          <Strut a={[-0.25, -0.18, s * 0.28]} b={[-0.15, 0.48, s * 1.9]} />
          <Strut a={[0.15, -0.18, s * 0.28]} b={[0.2, 0.46, s * 1.9]} r={0.018} />
        </group>
      ))}
      {/* tail */}
      <mesh geometry={stab} material={matBody} position={[1.95, 0.08, 0]} />
      <mesh geometry={fin} material={matRed} position={[1.62, 0.1, 0]} />
      {/* landing gear */}
      {[-1, 1].map((s) => (
        <group key={s}>
          <Strut a={[-0.1, -0.3, s * 0.2]} b={[-0.55, -0.62, s * 0.48]} r={0.03} material={matDark} />
          <mesh position={[-0.55, -0.62, s * 0.5]} rotation={[Math.PI / 2, 0, 0]} material={matDark}>
            <cylinderGeometry args={[0.19, 0.19, 0.1, 18]} />
          </mesh>
          <mesh position={[-0.55, -0.62, s * 0.5]} rotation={[Math.PI / 2, 0, 0]} material={matMetal}>
            <cylinderGeometry args={[0.08, 0.08, 0.115, 12]} />
          </mesh>
        </group>
      ))}
      <mesh position={[1.95, -0.1, 0]} rotation={[Math.PI / 2, 0, 0]} material={matDark}>
        <cylinderGeometry args={[0.07, 0.07, 0.05, 10]} />
      </mesh>
      {/* propeller: blades spin about x, a translucent disc sells the blur */}
      <group ref={prop} position={[-2.33, 0, 0]}>
        <mesh material={matDark}><boxGeometry args={[0.04, 1.55, 0.11]} /></mesh>
        <mesh material={matDark} rotation={[Math.PI / 2, 0, 0]}><boxGeometry args={[0.04, 1.55, 0.11]} /></mesh>
        <mesh material={matRed} position={[-0.05, 0, 0]}><sphereGeometry args={[0.11, 12, 10]} /></mesh>
      </group>
      <mesh position={[-2.34, 0, 0]} rotation={[0, Math.PI / 2, 0]}>
        <circleGeometry args={[0.78, 28]} />
        <meshBasicMaterial color="#ffffff" transparent opacity={0.12} depthWrite={false} side={THREE.DoubleSide} />
      </mesh>
      {/* tow line */}
      <Strut a={[2.4, -0.05, 0]} b={[2.4 + 2.3, -0.2, 0]} r={0.012} material={matDark} />
    </group>
  );
}

function Airplane() {
  const g = useRef();
  const prop = useRef();
  const tex = useBannerTexture('PROJECTS');
  const geo = useMemo(() => new THREE.PlaneGeometry(BW, BH, 40, 6), []);
  const base = useMemo(() => Float32Array.from(geo.attributes.position.array), [geo]);

  useFrame(({ clock }, dt) => {
    const t = clock.elapsedTime;
    const u = (rig.planeX - X0) / (X1 - X0); // 0 → 1 along the flight path
    const G = g.current;
    G.visible = rig.time > BEATS.planeFrom - 1 && rig.time < BEATS.planeTo + 0.5; // gone once it has flown out of frame
    if (!G.visible) return; // …and then costs nothing (no banner cloth update)
    G.position.set(rig.planeX, Y0 + (Y1 - Y0) * u + Math.sin(t * 0.8) * 0.35, Z0 + (Z1 - Z0) * u);
    G.rotation.set(0.1 + Math.sin(t * 0.7) * 0.035, HEADING, -0.035 + Math.sin(t * 0.55) * 0.015); // order YZX: yaw, pitch, roll(x)
    if (prop.current) prop.current.rotation.x += dt * 60;

    const pos = geo.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      const k = (base[i * 3] + BW / 2) / BW; // 0 at the tow rope → 1 at the free end
      pos.setZ(i, Math.sin(k * 9 - t * 5) * 0.55 * k);
      pos.setY(i, base[i * 3 + 1] + Math.sin(k * 5 - t * 3) * 0.14 * k);
    }
    pos.needsUpdate = true;
    geo.computeVertexNormals();
  });

  return (
    <group ref={g} scale={SCALE} rotation-order="YZX">
      <OptionalGLTF url={MODELS.plane} fallback={<PlaneBody prop={prop} />} />
      <mesh geometry={geo} position={[4.7 + BW / 2, -0.2, 0]}>
        <meshStandardMaterial map={tex} emissiveMap={tex} emissive="#ffffff" emissiveIntensity={0.55} roughness={0.9} side={THREE.DoubleSide} />
      </mesh>
    </group>
  );
}

export default function SkyScene() {
  return (
    <>
      <SceneGroup range={[0, BEATS.WALL_IN + 2]}>
        <CloudField />
      </SceneGroup>
      <SceneGroup id="sky">
        <Airplane />
      </SceneGroup>
    </>
  );
}
