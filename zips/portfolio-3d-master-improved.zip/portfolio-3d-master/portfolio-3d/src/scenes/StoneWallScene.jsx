import { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Html } from '@react-three/drei';
import { SceneGroup } from '../rig/SceneGroup';
import { useFade, flicker } from '../rig/hooks';
import { OptionalGLTF } from '../shared/OptionalGLTF';
import { useStoneTexture } from '../shared/textures';
import { dfFor } from '../shared/utils';
import { PROJECTS } from '../config/cv';
import { BEATS, MODELS, WORLD, WALL_FRAMES, LANTERNS } from '../config/storyboard';

/**
 * SCENE 5: THE STONE WALL (project showcase)
 * Camera travels DOWN the wall (the wall keys in storyboard.js). Each CV project hangs in a rustic frame;
 * the card inside is real, interactive DOM (hover = lift + subtle 3D tilt).
 */
const { pos, w: WALL_W, h: WALL_H } = WORLD.stone;
const PX = 130;
const FW = 4.6;
const FH = 3.15;
const FADE = [BEATS.SKY_B + 2, BEATS.WALL_IN - 1.5, BEATS.WALL_LAST_HOLD + 0.8, BEATS.WALL_LAST_HOLD + 3.2];
const FRAMES = WALL_FRAMES;
const TILT = [0.012, -0.015, 0.01, -0.008, 0.014];

function Card({ project, index, innerRef }) {
  const onMove = (e) => {
    const r = e.currentTarget.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width - 0.5;
    const py = (e.clientY - r.top) / r.height - 0.5;
    e.currentTarget.style.transform = `rotateY(${px * 8}deg) rotateX(${-py * 8}deg) translateZ(8px)`;
  };
  const onLeave = (e) => (e.currentTarget.style.transform = '');
  return (
    <article ref={innerRef} className="project-card" style={{ width: (FW - 0.3) * PX, height: (FH - 0.3) * PX, opacity: 0, display: 'none' }} onMouseMove={onMove} onMouseLeave={onLeave}>
      <div className="kind"><span>{project.kind}</span><span>{index + 1} of {PROJECTS.length}</span></div>
      <h4>{project.title}</h4>
      <div className="tags">{project.stack.map((s) => <span key={s}>{s}</span>)}</div>
      <ul>{project.bullets.map((b) => <li key={b}>{b}</li>)}</ul>
    </article>
  );
}

function ProjectFrame({ project, index }) {
  const [x, y] = FRAMES[index];
  const g = useRef();
  const card = useRef();
  useFade(card, FADE);
  useFrame(({ clock }) => {
    g.current.rotation.z = TILT[index] + Math.sin(clock.elapsedTime * 0.7 + index) * 0.006; // frames hang slightly alive
  });
  const bars = [
    [0, FH / 2, FW + 0.16, 0.16],
    [0, -FH / 2, FW + 0.16, 0.16],
    [-FW / 2, 0, 0.16, FH],
    [FW / 2, 0, 0.16, FH],
  ];
  return (
    <group ref={g} position={[x, y, 0.5]}>
      <mesh position={[0.12, -0.14, 0.02]}>
        <planeGeometry args={[FW + 0.3, FH + 0.3]} />
        <meshBasicMaterial color="#000" transparent opacity={0.3} />
      </mesh>
      <mesh position={[0, 0, 0.05]}><planeGeometry args={[FW, FH]} /><meshStandardMaterial color="#1a1714" roughness={1} /></mesh>
      {bars.map(([bx, by, bw, bh], i) => (
        <mesh key={i} position={[bx, by, 0.09]}>
          <boxGeometry args={[bw, bh, 0.14]} />
          <meshStandardMaterial color="#6b4a2b" roughness={0.9} />
        </mesh>
      ))}
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * (FW / 2 - 0.05), FH / 2 - 0.05, 0.18]} rotation={[Math.PI / 2, 0, 0]}>
          <cylinderGeometry args={[0.05, 0.05, 0.1, 8]} />
          <meshStandardMaterial color="#2b2b2b" metalness={0.8} roughness={0.4} />
        </mesh>
      ))}
      <Html transform center distanceFactor={dfFor(PX)} position={[0, 0, 0.13]}>
        <Card project={project} index={index} innerRef={card} />
      </Html>
    </group>
  );
}

function Lantern({ position }) {
  const glow = useRef();
  useFrame(({ clock }) => {
    if (glow.current) glow.current.scale.setScalar(flicker(clock.elapsedTime, 10, 0.12, position[1]));
  });
  return (
    <group position={position}>
      <mesh><boxGeometry args={[0.28, 0.4, 0.28]} /><meshStandardMaterial color="#1c1c1c" metalness={0.7} roughness={0.5} /></mesh>
      <mesh ref={glow}><sphereGeometry args={[0.1, 12, 12]} /><meshBasicMaterial color={[3, 2, 0.9]} toneMapped={false} /></mesh>
    </group>
  );
}

export default function StoneWallScene() {
  const tex = useStoneTexture();
  const map = useMemo(() => {
    const t = tex.clone();
    t.repeat.set(WALL_W / 6, WALL_H / 6);
    t.needsUpdate = true;
    return t;
  }, [tex]);
  return (
    <SceneGroup id="wall" position={pos}>
      <OptionalGLTF
        url={MODELS.stoneWall}
        fallback={
          <mesh position={[0, WALL_H / 2, 0]}>
            <boxGeometry args={[WALL_W, WALL_H, 1]} />
            <meshStandardMaterial map={map} bumpMap={map} bumpScale={1.5} roughness={1} />
          </mesh>
        }
      />
      {LANTERNS.map((p) => (
        <Lantern key={p.join()} position={p} />
      ))}
      {PROJECTS.map((p, i) => (
        <ProjectFrame key={p.title} project={p} index={i} />
      ))}
    </SceneGroup>
  );
}
