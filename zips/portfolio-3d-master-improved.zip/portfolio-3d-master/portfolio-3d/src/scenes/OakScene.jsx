import { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { Html } from '@react-three/drei';
import { rig } from '../rig/rig';
import { SceneGroup } from '../rig/SceneGroup';
import { useFade } from '../rig/hooks';
import { OptionalGLTF } from '../shared/OptionalGLTF';
import { dfFor, fadeWindow, mulberry32, smooth } from '../shared/utils';
import { BIO, LEAF_NOTES, PROFILE } from '../config/cv';
import { BEATS, MODELS, WORLD } from '../config/storyboard';

/**
 * SCENE 2: THE OAK TREE (About me)
 * Bio is carved on a flat "blaze" hewn into the trunk (HTML on a 3D plank),
 * extra facts ride on falling 3D leaves (a leaf mesh + a screen-space <Html> tag).
 */

const FADE = [BEATS.OAK_IN - 5, BEATS.OAK_IN - 1.5, BEATS.OAK_OUT + 1, BEATS.OAK_OUT + 4.5];
const LEAF_FADE = [BEATS.OAK_IN, BEATS.OAK_IN + 2, BEATS.OAK_OUT + 1, BEATS.OAK_OUT + 4];
const matBark = new THREE.MeshStandardMaterial({ color: '#5b3d25', roughness: 1, flatShading: true });

/** DOM text, anchored where the trunk's flat blaze sits (works with the procedural oak or your own .glb). */
function Plaque() {
  const ref = useRef();
  useFade(ref, FADE);
  return (
    <Html transform center distanceFactor={dfFor(140)} position={[0, 2.6, 1.67]}>
      <div ref={ref} className="plaque" style={{ width: 2.6 * 140, height: 3.2 * 140, opacity: 0, display: 'none' }}>
        <h3>About me</h3>
        {BIO.map((p) => (
          <p key={p}>{p}</p>
        ))}
        <div className="chips">
          {PROFILE.chips.map((c) => (
            <span className="chip" key={c}>{c}</span>
          ))}
        </div>
      </div>
    </Html>
  );
}

function ProceduralOak() {
  const canopy = useRef();
  const blobs = useMemo(() => {
    const r = mulberry32(3);
    const cols = ['#3f7d34', '#4c8f3b', '#356f2f', '#5a9a42'];
    return Array.from({ length: 22 }, (_, i) => {
      const a = r() * Math.PI * 2;
      const rad = 1 + r() * 3.6;
      return { p: [Math.cos(a) * rad, 7.2 + r() * 3.2 + (3.6 - rad) * 0.35, Math.sin(a) * rad * 0.9], s: 1.5 + r() * 1.5, c: cols[i % 4], ph: r() * 6 };
    });
  }, []);
  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    canopy.current.children.forEach((m, i) => {
      m.position.y = blobs[i].p[1] + Math.sin(t * 0.9 + blobs[i].ph) * 0.07; // leaves breathing in the wind
      m.rotation.z = Math.sin(t * 0.6 + blobs[i].ph) * 0.05;
    });
  });
  return (
    <group>
      <mesh material={matBark} position={[0, 3.6, 0]}><cylinderGeometry args={[1.05, 1.7, 7.2, 14]} /></mesh>
      {[0, 1, 2, 3, 4].map((i) => (
        <mesh key={i} material={matBark} position={[Math.cos(i * 1.26) * 1.5, 0.35, Math.sin(i * 1.26) * 1.5]} rotation={[Math.sin(i * 1.26) * 0.9, 0, -Math.cos(i * 1.26) * 0.9]}>
          <coneGeometry args={[0.55, 1.6, 6]} />
        </mesh>
      ))}
      {[-1, 1].map((s) => (
        <mesh key={s} material={matBark} position={[s * 1.7, 7, 0]} rotation={[0, 0, -s * 0.9]}>
          <cylinderGeometry args={[0.3, 0.5, 3.4, 8]} />
        </mesh>
      ))}
      <group ref={canopy}>
        {blobs.map((b, i) => (
          <mesh key={i} position={b.p} scale={b.s}>
            <icosahedronGeometry args={[1, 1]} />
            <meshStandardMaterial color={b.c} flatShading roughness={1} />
          </mesh>
        ))}
      </group>
      {/* flat hewn face of the trunk that the bio text sits on */}
      <mesh position={[0, 2.6, 1.1]}>
        <boxGeometry args={[2.8, 3.4, 1.1]} />
        <meshStandardMaterial color="#a97a4a" roughness={0.9} />
      </mesh>
    </group>
  );
}

const leafGeo = (() => {
  const s = new THREE.Shape();
  s.moveTo(0, 0);
  s.quadraticCurveTo(0.35, 0.25, 0, 1);
  s.quadraticCurveTo(-0.35, 0.25, 0, 0);
  const g = new THREE.ShapeGeometry(s);
  g.translate(0, -0.5, 0);
  g.scale(0.55, 0.55, 0.55);
  return g;
})();

// base x, z (oak-local) and phase of each falling leaf; positions keep clear of the plaque
const LEAF_SLOTS = [[-3.0, 3.4, 0.0], [2.9, 3.0, 0.33], [-2.3, 4.2, 0.62], [3.3, 4.4, 0.18], [-3.5, 2.6, 0.82], [2.4, 3.8, 0.5]];
const LEAF_COLORS = ['#d98b2b', '#8fb339', '#c9672a', '#a3b83a', '#e0a63a', '#b7cf45'];

function FallingLeaf({ note, slot, color }) {
  const g = useRef();
  const tag = useRef();
  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    const frac = (t / 24 + slot[2]) % 1; // 24 s fall cycle (slow, so each note can be read)
    const sway = Math.sin(t * 0.9 + slot[2] * 9);
    g.current.position.set(slot[0] + sway * 0.6, 8.5 - frac * 8.2, slot[1]);
    g.current.rotation.set(Math.sin(t * 1.3 + slot[2] * 5) * 0.9, t * 0.6 + slot[2] * 6, Math.cos(t * 1.1 + slot[2] * 3) * 0.7);
    if (tag.current) {
      const o = fadeWindow(rig.time, LEAF_FADE) * smooth(frac * 8) * (1 - smooth((frac - 0.9) * 10));
      tag.current.style.opacity = o.toFixed(3);
      tag.current.style.display = o < 0.01 ? 'none' : '';
    }
  });
  return (
    <group ref={g}>
      <mesh geometry={leafGeo}>
        <meshStandardMaterial color={color} side={THREE.DoubleSide} roughness={0.8} />
      </mesh>
      <Html center zIndexRange={[20, 0]} style={{ pointerEvents: 'none' }}>
        <div ref={tag} className="leaf-note" style={{ opacity: 0, display: 'none' }}>
          <b>{note.title}</b>
          {note.text}
        </div>
      </Html>
    </group>
  );
}

export default function OakScene() {
  return (
    <SceneGroup id="oak" position={WORLD.oak.pos}>
      <OptionalGLTF url={MODELS.oak} fallback={<ProceduralOak />} />
      <Plaque />
      {LEAF_NOTES.map((n, i) => (
        <FallingLeaf key={n.title} note={n} slot={LEAF_SLOTS[i]} color={LEAF_COLORS[i]} />
      ))}
    </SceneGroup>
  );
}
