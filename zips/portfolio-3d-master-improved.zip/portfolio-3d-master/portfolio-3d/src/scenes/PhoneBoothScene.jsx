import { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { Html } from '@react-three/drei';
import { SceneGroup } from '../rig/SceneGroup';
import { useFade } from '../rig/hooks';
import { OptionalGLTF } from '../shared/OptionalGLTF';
import { usePaperTexture } from '../shared/textures';
import { dfFor } from '../shared/utils';
import ContactForm from '../ui/ContactForm';
import { PROFILE } from '../config/cv';
import { BEATS, BOOTH, MODELS, PAPER } from '../config/storyboard';

/**
 * SCENE 7: THE RED TELEPHONE BOOTH (contact)
 *  Step 1 – camera shows the booth full-frame and rests on the signpost with the contact details.
 *  Step 2 – camera dollies toward the glass.
 *  Step 3 – camera glides right up to a SMALL note taped on the glass (PAPER in the storyboard:
 *           0.44 × 0.60 world units, 1.27 away) so it fills the screen; the DOM form fades in over it.
 * The form is a drei <Html transform> child of the paper mesh, so it is pinned to the paper in 3D.
 * The booth's lights (bulb + sunset kicker) are slots in rig/LightPool.jsx.
 */

const BW = 1.8; // booth width / depth
const BH = 3.2;
const FORM_PX = 1000; // DOM px per world unit on the note → the 0.44×0.6 note is a 440×600 px form
const SIGN_PX = 170;
const matRed = new THREE.MeshStandardMaterial({ color: '#c4161c', roughness: 0.45, metalness: 0.1 });
const matGlass = new THREE.MeshStandardMaterial({ color: '#bfe6ff', transparent: true, opacity: 0.16, roughness: 0.1, metalness: 0.1, side: THREE.DoubleSide, depthWrite: false });
const matDark = new THREE.MeshStandardMaterial({ color: '#1b1b1d', roughness: 0.7 });

function BoothBody() {
  const sign = useMemo(() => {
    const c = document.createElement('canvas');
    c.width = 512;
    c.height = 96;
    const g = c.getContext('2d');
    g.fillStyle = '#fff6dc';
    g.fillRect(0, 0, 512, 96);
    g.fillStyle = '#c4161c';
    g.font = '700 58px Fraunces, Georgia, serif';
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.fillText('TELEPHONE', 256, 52);
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    document.fonts?.ready.then(() => {
      g.fillStyle = '#fff6dc';
      g.fillRect(0, 0, 512, 96);
      g.fillStyle = '#c4161c';
      g.fillText('TELEPHONE', 256, 52);
      t.needsUpdate = true;
    });
    return t;
  }, []);
  const posts = [[-1, -1], [1, -1], [-1, 1], [1, 1]];
  const panes = [
    { p: [0, 1.8, BW / 2 - 0.04], r: 0, w: BW - 0.12 },
    { p: [0, 1.8, -BW / 2 + 0.04], r: 0, w: BW - 0.12 },
    { p: [BW / 2 - 0.04, 1.8, 0], r: Math.PI / 2, w: BW - 0.12 },
    { p: [-BW / 2 + 0.04, 1.8, 0], r: Math.PI / 2, w: BW - 0.12 },
  ];
  return (
    <group>
      <mesh material={matRed} position={[0, 0.35, 0]}><boxGeometry args={[BW + 0.15, 0.7, BW + 0.15]} /></mesh>
      {posts.map(([x, z], i) => (
        <mesh key={i} material={matRed} position={[x * (BW / 2 - 0.05), 0.7 + 1.1, z * (BW / 2 - 0.05)]}><boxGeometry args={[0.1, 2.2, 0.1]} /></mesh>
      ))}
      {panes.map((a, i) => (
        <group key={i} position={a.p} rotation={[0, a.r, 0]}>
          <mesh material={matGlass}><boxGeometry args={[a.w, 2.0, 0.02]} /></mesh>
          {[-0.3, 0.3].map((x) => (
            <mesh key={x} material={matRed} position={[x, 0, 0.01]}><boxGeometry args={[0.04, 2.0, 0.03]} /></mesh>
          ))}
          {[-0.65, -0.1, 0.45, 0.95].map((y) => (
            <mesh key={y} material={matRed} position={[0, y, 0.01]}><boxGeometry args={[a.w, 0.04, 0.03]} /></mesh>
          ))}
        </group>
      ))}
      <mesh material={matRed} position={[0, BH - 0.1, 0]}><boxGeometry args={[BW + 0.2, 0.22, BW + 0.2]} /></mesh>
      <mesh material={matRed} position={[0, BH + 0.1, 0]}><boxGeometry args={[BW - 0.2, 0.18, BW - 0.2]} /></mesh>
      <mesh material={matRed} position={[0, BH + 0.26, 0]}><boxGeometry args={[BW - 0.7, 0.14, BW - 0.7]} /></mesh>
      <mesh position={[0, BH - 0.44, BW / 2 + 0.01]}>
        <planeGeometry args={[BW - 0.2, 0.34]} />
        <meshBasicMaterial map={sign} />
      </mesh>
      {/* inside: phone (the bulb light is in rig/LightPool) */}
      <mesh material={matDark} position={[0, 1.5, -BW / 2 + 0.2]}><boxGeometry args={[0.4, 0.55, 0.16]} /></mesh>
      <mesh position={[0, 2.6, 0]}><sphereGeometry args={[0.07, 10, 10]} /><meshBasicMaterial color={[3, 2.3, 1.2]} toneMapped={false} /></mesh>
    </group>
  );
}

function Paper() {
  const paperTex = usePaperTexture();
  const form = useRef();
  useFade(form, [BEATS.BOOTH_B + 1.2, BEATS.BOOTH_C - 1.2, 999, 1000]); // fades in as the camera arrives, never fades out
  return (
    <group position={[0, PAPER.y, PAPER.z]} rotation={[0, 0, 0.012]}>
      {/* soft contact shadow so the note sits ON the glass */}
      <mesh position={[0.012, -0.014, -0.004]}>
        <planeGeometry args={[PAPER.w + 0.03, PAPER.h + 0.03]} />
        <meshBasicMaterial color="#000" transparent opacity={0.22} depthWrite={false} />
      </mesh>
      <mesh>
        <planeGeometry args={[PAPER.w, PAPER.h]} />
        <meshStandardMaterial map={paperTex} roughness={0.9} />
      </mesh>
      <Html transform center distanceFactor={dfFor(FORM_PX)} position={[0, 0, 0.004]}>
        <div ref={form} className="paper" style={{ width: PAPER.w * FORM_PX, height: PAPER.h * FORM_PX, opacity: 0, display: 'none' }}>
          <ContactForm />
        </div>
      </Html>
    </group>
  );
}

function ContactSign() {
  const ref = useRef();
  useFade(ref, [BEATS.BOOTH_A - 1.5, BEATS.BOOTH_A + 0.8, BEATS.BOOTH_B - 2.2, BEATS.BOOTH_B + 0.4]);
  const links = [
    ['Phone', PROFILE.phone, `tel:${PROFILE.phone.replace(/[^+\d]/g, '')}`],
    ['Email', PROFILE.email, `mailto:${PROFILE.email}`],
    ['LinkedIn', 'linkedin', PROFILE.linkedin],
    ['Portfolio', 'portfolio', PROFILE.portfolio],
  ];
  return (
    <group position={[BW / 2 + 1.7, 0, BW / 2 + 0.4]} rotation={[0, -0.22, 0]}>
      <mesh position={[0, 1, 0]}><boxGeometry args={[0.12, 2, 0.12]} /><meshStandardMaterial color="#5a3d22" roughness={1} /></mesh>
      <mesh position={[0, 1.75, 0]}><boxGeometry args={[2.0, 1.45, 0.08]} /><meshStandardMaterial color="#7a5430" roughness={0.9} /></mesh>
      <Html transform center distanceFactor={dfFor(SIGN_PX)} position={[0, 1.75, 0.05]}>
        <div ref={ref} className="booth-sign" style={{ width: 1.85 * SIGN_PX, height: 1.3 * SIGN_PX, opacity: 0, display: 'none' }}>
          <h3>Get in touch</h3>
          <p>{PROFILE.location}</p>
          <ul>
            {links.map(([label, text, href]) => (
              <li key={label}><span>{label}</span><a href={href} target="_blank" rel="noreferrer">{text}</a></li>
            ))}
          </ul>
        </div>
      </Html>
    </group>
  );
}

export default function PhoneBoothScene() {
  return (
    <SceneGroup id="booth" position={BOOTH.pos} rotation-y={BOOTH.rotY}>
      <OptionalGLTF url={MODELS.booth} fallback={<BoothBody />} />
      <Paper />
      <ContactSign />
    </SceneGroup>
  );
}
