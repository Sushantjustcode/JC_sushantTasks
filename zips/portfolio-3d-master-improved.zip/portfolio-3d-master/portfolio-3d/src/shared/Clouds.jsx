import { useLayoutEffect, useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { mulberry32 } from './utils';

const geo = new THREE.IcosahedronGeometry(1, 1);
const mat = new THREE.MeshStandardMaterial({
  color: '#ffffff',
  emissive: '#eef4ff',
  emissiveIntensity: 0.62, // bright undersides: clouds read WHITE, not grey
  flatShading: true,
  roughness: 1,
});

/**
 * Cloud layers at different depths = parallax + a sense of distance.
 *   mid / high  : cumulus around the airplane
 *   near        : a few low clouds close to the camera
 *   horizon     : huge flat banks far away, sinking into the fog (aerial perspective)
 * ALL puffs of ALL layers are ONE InstancedMesh (≈400 puffs, 1 draw call; the old version was
 * ~130 separate meshes). Drift is a pure function of time, so there is no per-cloud state.
 */
export const CLOUD_LAYERS = [
  { count: 15, area: [260, 16, 80], center: [0, 25, -88], size: [4, 8], speed: 0.9, seed: 11 },
  { count: 13, area: [320, 14, 90], center: [0, 41, -125], size: [5, 9], speed: 0.6, seed: 12 },
  { count: 4, area: [170, 4, 24], center: [0, 3, -50], size: [3, 5], speed: 1.2, seed: 13 }, // low, near the horizon: frames the shot without hiding the banner
  { count: 28, area: [760, 9, 70], center: [0, 8, -235], size: [14, 26], speed: 0.15, seed: 14, flat: 0.45 },
];

export default function CloudField({ layers = CLOUD_LAYERS }) {
  const mesh = useRef();
  const { puffs, clouds } = useMemo(() => {
    const puffs = [];
    const clouds = [];
    layers.forEach((L, li) => {
      const r = mulberry32(L.seed);
      for (let c = 0; c < L.count; c++) {
        const s = L.size[0] + r() * (L.size[1] - L.size[0]);
        const cloud = {
          x: (r() - 0.5) * L.area[0],
          y: L.center[1] + (r() - 0.5) * L.area[1],
          z: L.center[2] + (r() - 0.5) * L.area[2],
          v: L.speed * (0.6 + r() * 0.8),
          w: L.area[0] + 60,
          first: puffs.length,
        };
        const n = 6 + Math.floor(r() * 3);
        for (let i = 0; i < n; i++) {
          const rad = 0.8 + r() * 0.8;
          puffs.push({
            cloud: clouds.length,
            ox: (i - n / 2) * 0.9 * s * 0.5 + r() * 0.5 * s,
            oy: r() * 0.7 * s * (L.flat ?? 1) + (1 - Math.abs(i - n / 2) / (n / 2)) * 0.35 * s * (L.flat ?? 1),
            oz: (r() - 0.5) * 0.9 * s,
            sx: rad * 1.15 * s * 0.55,
            sy: rad * 0.8 * s * 0.55 * (L.flat ?? 1),
            sz: rad * s * 0.55,
          });
        }
        clouds.push(cloud);
      }
    });
    return { puffs, clouds };
  }, [layers]);

  useLayoutEffect(() => {
    const a = mesh.current.instanceMatrix.array;
    puffs.forEach((p, i) => {
      const o = i * 16;
      a.fill(0, o, o + 16);
      a[o] = p.sx;
      a[o + 5] = p.sy;
      a[o + 10] = p.sz;
      a[o + 13] = clouds[p.cloud].y + p.oy;
      a[o + 14] = clouds[p.cloud].z + p.oz;
      a[o + 15] = 1;
    });
    mesh.current.instanceMatrix.needsUpdate = true;
  }, [puffs, clouds]);

  useFrame(({ clock }) => {
    const m = mesh.current;
    if (!m || !m.parent?.visible) return; // scene window closed → no work
    const t = clock.elapsedTime;
    const a = m.instanceMatrix.array;
    for (let i = 0; i < puffs.length; i++) {
      const p = puffs[i];
      const c = clouds[p.cloud];
      const x = ((((c.x + c.v * t + c.w / 2) % c.w) + c.w) % c.w) - c.w / 2;
      a[i * 16 + 12] = x + p.ox;
    }
    m.instanceMatrix.needsUpdate = true;
  });

  return <instancedMesh ref={mesh} args={[geo, mat, puffs.length]} frustumCulled={false} />;
}
