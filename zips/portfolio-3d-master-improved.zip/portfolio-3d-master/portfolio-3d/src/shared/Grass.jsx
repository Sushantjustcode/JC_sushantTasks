import { useLayoutEffect, useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { mulberry32 } from './utils';

/**
 * GRASS – dense, clumped, wind-swept, still one draw call per patch.
 *
 *  • Each blade is a tapered, curved 4-segment strip (not a cone), with a dark-root →
 *    bright-tip vertex gradient, so a field has depth even before any light hits it.
 *  • Blades are scattered in CLUMPS with bare gaps between them (uniform scatter looks like
 *    a spray of needles). Clump size, height and tint vary.
 *  • Wind is a travelling wave in WORLD space, so the whole field ripples coherently
 *    instead of every blade wobbling on its own phase.
 *  • Blades shrink to nothing with distance (uFade*) instead of being drawn as sub-pixel
 *    slivers: that is both a perf win and removes the far-field shimmer.
 *  • Normals are blended toward "up" so the field is lit like the ground it grows from.
 */
const U = { uTime: { value: 0 }, uFadeNear: { value: 42 }, uFadeFar: { value: 82 } };

/** Mount once inside <Canvas>: advances the wind clock. */
export function SwayTicker() {
  useFrame(({ clock }) => {
    U.uTime.value = clock.elapsedTime;
  });
  return null;
}

function bladeGeometry(segs = 4) {
  const pos = [];
  const col = [];
  const idx = [];
  for (let i = 0; i < segs; i++) {
    const t = i / segs;
    const w = 0.04 * Math.pow(1 - t, 0.75); // half-width, tapering
    const z = t * t * 0.2; // curve forward
    pos.push(-w, t, z, w, t, z);
    const c = 0.3 + 0.7 * t;
    col.push(c, c, c, c, c, c);
  }
  pos.push(0, 1, 0.2);
  col.push(1, 1, 1);
  for (let i = 0; i < segs - 1; i++) {
    const a = i * 2;
    idx.push(a, a + 1, a + 2, a + 1, a + 3, a + 2);
  }
  const a = (segs - 1) * 2;
  idx.push(a, a + 1, segs * 2);
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3));
  g.setIndex(idx);
  g.computeVertexNormals();
  g.computeBoundingSphere();
  return g;
}
let _blade;
const blade = () => (_blade ||= bladeGeometry());

let _mat;
function grassMaterial() {
  if (_mat) return _mat;
  _mat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.92, side: THREE.DoubleSide });
  _mat.onBeforeCompile = (shader) => {
    Object.assign(shader.uniforms, U);
    shader.vertexShader = shader.vertexShader
      .replace('#include <common>', '#include <common>\nuniform float uTime; uniform float uFadeNear; uniform float uFadeFar;')
      .replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
         vec3 gRoot = (modelMatrix * instanceMatrix * vec4(0.0, 0.0, 0.0, 1.0)).xyz;
         float gFade = 1.0 - smoothstep(uFadeNear, uFadeFar, distance(gRoot, cameraPosition));
         transformed *= gFade;`
      )
      .replace(
        '#include <project_vertex>',
        `vec4 mvPosition = instanceMatrix * vec4(transformed, 1.0);
         float gH = position.y * length(instanceMatrix[1].xyz);
         float gBend = gH * gH;
         vec4 gW = modelMatrix * mvPosition;
         float gw = sin(uTime * 1.35 + gRoot.x * 0.21 + gRoot.z * 0.16) * 0.6
                  + sin(uTime * 2.6 + gRoot.x * 0.65 - gRoot.z * 0.5) * 0.25
                  + sin(uTime * 0.55 + gRoot.z * 0.08) * 0.35;
         gW.x += gw * 0.30 * gBend;
         gW.z += (cos(uTime * 1.1 + gRoot.x * 0.19) * 0.5 + 0.25) * gw * 0.18 * gBend;
         mvPosition = viewMatrix * gW;
         gl_Position = projectionMatrix * mvPosition;`
      );
    shader.fragmentShader = shader.fragmentShader.replace(
      '#include <normal_fragment_begin>',
      `#include <normal_fragment_begin>
       normal = normalize(mix(normal, normalize((viewMatrix * vec4(0.0, 1.0, 0.0, 0.0)).xyz), 0.72));`
    );
  };
  return _mat;
}

/** Phones / coarse-pointer devices get half the blades: grass is the heaviest thing in the scene. */
const LOW_END = typeof window !== 'undefined' && (window.matchMedia('(pointer: coarse)').matches || window.innerWidth < 700);
export const GRASS_DENSITY = LOW_END ? 0.5 : 1;

const gauss = (r) => Math.sqrt(-2 * Math.log(Math.max(1e-6, r()))) * Math.cos(6.2831853 * r());

/**
 * rects: [{ x0, x1, z0, z1, density }]  (density = blades per m²)
 * exclude(x, z) → true to keep that spot clear (track bed, road…)
 */
export function scatterGrass({ rects, seed = 1, exclude, clump = 12 }) {
  const r = mulberry32(seed);
  const out = [];
  for (const R of rects) {
    const area = (R.x1 - R.x0) * (R.z1 - R.z0);
    const n = Math.round(area * R.density * GRASS_DENSITY);
    const centres = Math.ceil(n / clump);
    for (let c = 0; c < centres; c++) {
      const cx = R.x0 + r() * (R.x1 - R.x0);
      const cz = R.z0 + r() * (R.z1 - R.z0);
      const rad = 0.3 + r() * 0.8;
      const hf = 0.65 + r() * 0.75;
      const tint = r();
      for (let b = 0; b < clump; b++) {
        const x = cx + gauss(r) * rad;
        const z = cz + gauss(r) * rad;
        if (x < R.x0 || x > R.x1 || z < R.z0 || z > R.z1) continue;
        if (exclude && exclude(x, z)) continue;
        out.push(x, z, hf * (0.75 + r() * 0.5), 0.9 + r() * 0.8, r() * 6.2832, Math.min(1, Math.max(0, tint * 0.6 + r() * 0.4)));
      }
    }
  }
  return new Float32Array(out);
}

/** Renders pre-computed blade data: Float32Array of [x, z, heightK, widthK, rotY, tint] × N. */
export function GrassInstances({ data, height = 0.8, colors = ['#2a5e2a', '#9cc64c'] }) {
  const ref = useRef();
  const count = data.length / 6;
  useLayoutEffect(() => {
    const m = ref.current;
    if (!m) return;
    const o = new THREE.Object3D();
    const c = new THREE.Color();
    const A = new THREE.Color(colors[0]);
    const Bc = new THREE.Color(colors[1]);
    for (let i = 0; i < count; i++) {
      const k = i * 6;
      o.position.set(data[k], 0, data[k + 1]);
      o.rotation.set(0, data[k + 4], 0);
      o.scale.set(data[k + 3], data[k + 2] * height, data[k + 3]);
      o.updateMatrix();
      m.setMatrixAt(i, o.matrix);
      m.setColorAt(i, c.copy(A).lerp(Bc, data[k + 5]));
    }
    m.instanceMatrix.needsUpdate = true;
    if (m.instanceColor) m.instanceColor.needsUpdate = true;
    m.computeBoundingSphere();
  }, [data, count, height, colors]);
  return <instancedMesh key={count} ref={ref} args={[blade(), grassMaterial(), count]} />;
}

/** Scatter inside rectangles (see scatterGrass) and render. */
export function GrassPatch({ rects, exclude, seed = 1, clump = 12, ...rest }) {
  const data = useMemo(() => scatterGrass({ rects, seed, exclude, clump }), [rects, seed, exclude, clump]);
  return <GrassInstances data={data} {...rest} />;
}

/** A sprinkle of wild flowers: thin stem + faceted head, two instanced meshes. */
export function FlowerPatch({ rects, exclude, seed = 5, density = 0.5, colors = ['#ffffff', '#ffd34d', '#ff8fb1', '#c9a7ff', '#ff6f61'] }) {
  const stems = useRef();
  const heads = useRef();
  const data = useMemo(() => scatterGrass({ rects: rects.map((q) => ({ ...q, density })), seed, exclude, clump: 4 }), [rects, seed, exclude, density]);
  const count = data.length / 6;
  const stemGeo = useMemo(() => new THREE.CylinderGeometry(0.006, 0.01, 1, 4).translate(0, 0.5, 0), []);
  const headGeo = useMemo(() => new THREE.OctahedronGeometry(0.04, 0).scale(1, 0.55, 1), []);
  useLayoutEffect(() => {
    if (!stems.current || !heads.current) return;
    const rnd = mulberry32(seed + 1);
    const o = new THREE.Object3D();
    const c = new THREE.Color();
    for (let i = 0; i < count; i++) {
      const k = i * 6;
      const h = 0.32 + rnd() * 0.3;
      o.position.set(data[k], 0, data[k + 1]);
      o.rotation.set((rnd() - 0.5) * 0.18, data[k + 4], (rnd() - 0.5) * 0.18);
      o.scale.set(1, h, 1);
      o.updateMatrix();
      stems.current.setMatrixAt(i, o.matrix);
      o.position.set(data[k], h * Math.cos(o.rotation.x), data[k + 1]);
      o.scale.setScalar(0.8 + rnd() * 0.7);
      o.updateMatrix();
      heads.current.setMatrixAt(i, o.matrix);
      heads.current.setColorAt(i, c.set(colors[Math.floor(rnd() * colors.length)]));
    }
    [stems.current, heads.current].forEach((m) => {
      m.instanceMatrix.needsUpdate = true;
      m.computeBoundingSphere();
    });
    if (heads.current.instanceColor) heads.current.instanceColor.needsUpdate = true;
  }, [data, count, colors, seed]);
  return (
    <group key={count}>
      <instancedMesh ref={stems} args={[stemGeo, undefined, count]}>
        <meshStandardMaterial color="#4c8a37" roughness={1} />
      </instancedMesh>
      <instancedMesh ref={heads} args={[headGeo, undefined, count]}>
        <meshStandardMaterial roughness={0.7} flatShading emissive="#ffffff" emissiveIntensity={0.08} />
      </instancedMesh>
    </group>
  );
}
