import * as THREE from 'three';

/**
 * PROCEDURAL RELIEF BRICKS
 * ────────────────────────
 * A MeshStandardMaterial patched with a brick height-field, evaluated in WORLD space:
 *   • Steep-parallax ray-march against the height-field → mortar joints genuinely recess
 *     and bricks occlude them as the camera moves (the "3D bricks" look).
 *   • Bump normals from the height-field gradient (lit by the sun + point lights).
 *   • Per-brick colour variation, burnt bricks, mottling, mortar grit, grime toward the ground,
 *     and ambient occlusion in the joints.
 *   • World-space planar mapping that picks its plane from the face normal, so the pattern keeps
 *     the SAME scale on the front, the door jambs and the top (the old texture was stretched
 *     ~6× across the jambs, which shimmered like crazy while the camera moved past the door).
 *   • Everything fades to a flat average colour by pixel footprint (fwidth) → no moiré, no shimmer.
 * No textures at all, so there is nothing to upload.
 */
const vert = {
  common: /* glsl */ `#include <common>
    varying vec3 vWPos; varying vec3 vWNrm;`,
  begin: /* glsl */ `#include <begin_vertex>
    vWPos = (modelMatrix * vec4(transformed, 1.0)).xyz;
    vWNrm = normalize(mat3(modelMatrix) * objectNormal);`,
};

const fragCommon = /* glsl */ `#include <common>
  varying vec3 vWPos; varying vec3 vWNrm;
  uniform vec2 uBrick; uniform float uMortar; uniform float uRelief;
  uniform vec3 uColA; uniform vec3 uColB; uniform vec3 uColC; uniform vec3 uMortarCol;

  float hash21(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
  float vnoise(vec2 p) {
    vec2 i = floor(p); vec2 f = fract(p); f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash21(i), hash21(i + vec2(1.0, 0.0)), f.x), mix(hash21(i + vec2(0.0, 1.0)), hash21(i + vec2(1.0, 1.0)), f.x), f.y);
  }
  // running bond: every other course is offset by half a brick
  vec2 brickCell(vec2 p, out vec2 id) {
    float row = floor(p.y / uBrick.y);
    vec2 q = vec2(p.x / uBrick.x + 0.5 * mod(row, 2.0), p.y / uBrick.y);
    id = vec2(floor(q.x), row);
    return fract(q);
  }
  // cheap height for the ray-march: bevelled brick = 1, mortar = 0
  float brickHCheap(vec2 p) {
    vec2 id; vec2 l = brickCell(p, id);
    vec2 d = min(l, 1.0 - l) * uBrick;
    return smoothstep(uMortar * 0.5, uMortar * 0.5 + 0.024, min(d.x, d.y));
  }
  // full height: + chipped edges + pitting
  float brickH(vec2 p, out vec2 id, out float edge) {
    vec2 l = brickCell(p, id);
    vec2 d = min(l, 1.0 - l) * uBrick;
    float e = min(d.x, d.y) + (vnoise(p * 55.0 + hash21(id) * 17.0) - 0.5) * 0.012;
    edge = e;
    return smoothstep(uMortar * 0.5, uMortar * 0.5 + 0.024, e) * (0.94 + 0.06 * vnoise(p * 90.0));
  }
`;

// replaces #include <map_fragment>: computes the parallax hit, colour, AO and bumped normal
const fragMain = /* glsl */ `
  vec3 Nw = normalize(vWNrm);
  vec3 an = abs(Nw);
  vec3 Ua = vec3(1.0, 0.0, 0.0);
  vec3 Va = vec3(0.0, 1.0, 0.0);
  if (an.x > 0.5) { Ua = vec3(0.0, 0.0, 1.0); } else if (an.y > 0.5) { Va = vec3(0.0, 0.0, 1.0); }

  vec3 Vw = normalize(cameraPosition - vWPos);
  float vn = max(dot(Vw, Nw), 0.18);
  vec2 p0 = vec2(dot(vWPos, Ua), dot(vWPos, Va));
  vec2 vuv = vec2(dot(Vw, Ua), dot(Vw, Va)) / vn;

  float fw = length(fwidth(p0));                    // world size of one pixel on the wall
  float lod = 1.0 - smoothstep(0.014, 0.055, fw);   // 1 = full detail, 0 = flat average
  float relief = uRelief * lod;

  const int STEPS = 10;
  vec2 dP = -vuv * relief / float(STEPS);
  vec2 pp = p0;
  float rayH = 1.0;
  float hC = brickHCheap(pp);
  vec2 ppPrev = pp; float hPrev = hC; float rayPrev = rayH;
  for (int i = 0; i < STEPS; i++) {
    if (rayH <= hC) break;
    ppPrev = pp; hPrev = hC; rayPrev = rayH;
    pp += dP; rayH -= 1.0 / float(STEPS); hC = brickHCheap(pp);
  }
  float a1 = hC - rayH; float a0 = hPrev - rayPrev;
  pp = mix(pp, ppPrev, clamp(a1 / (a1 - a0 + 1e-5), 0.0, 1.0));

  vec2 bid; float edgeD;
  float h = brickH(pp, bid, edgeD);
  float eps = 0.006; vec2 id2; float e2;
  float hx = brickH(pp + vec2(eps, 0.0), id2, e2);
  float hy = brickH(pp + vec2(0.0, eps), id2, e2);
  vec2 grad = vec2(hx - h, hy - h) / eps * relief;
  vec3 nT = normalize(vec3(-grad, 1.0));
  vec3 Nbump = normalize(Ua * nT.x + Va * nT.y + Nw * nT.z);

  float r1 = hash21(bid); float r2 = hash21(bid + 7.31); float r3 = hash21(bid * 1.7 + 3.1);
  vec3 brickCol = mix(uColA, uColB, r1);
  brickCol = mix(brickCol, uColC, step(0.9, r2) * 0.85);
  brickCol *= 0.86 + 0.26 * r3;
  brickCol *= 0.82 + 0.34 * (vnoise(pp * 14.0 + r1 * 20.0) * 0.5 + vnoise(pp * 46.0) * 0.5);
  vec3 mortar = uMortarCol * (0.82 + 0.34 * vnoise(pp * 62.0));
  float isBrick = smoothstep(uMortar * 0.5 - 0.004, uMortar * 0.5 + 0.02, edgeD);
  vec3 albedo = mix(mortar, brickCol, isBrick);
  albedo *= mix(0.62, 1.0, smoothstep(0.0, 1.1, vWPos.y));                         // grime near the ground
  albedo *= 1.0 - 0.14 * vnoise(vec2(pp.x * 5.0, pp.y * 0.6)) * smoothstep(0.5, 6.0, vWPos.y); // rain streaks
  float bAO = mix(0.42, 1.0, pow(h, 0.65));

  vec3 avgCol = mix(mix(uColA, uColB, 0.5), uMortarCol, 0.14) * 0.93;
  albedo = mix(avgCol, albedo, lod);
  bAO = mix(0.82, bAO, lod);
  Nbump = normalize(mix(Nw, Nbump, lod));
  diffuseColor.rgb = albedo;
`;

/**
 * opts: brick [w,h] incl. mortar, mortar width, relief depth (world units), colA/colB (brick range),
 *       colC (burnt bricks), mortarCol – all CSS colours.
 */
export function createReliefMaterial({
  brick = [0.46, 0.15],
  mortar = 0.032,
  relief = 0.05,
  colA = '#9a3b27',
  colB = '#c2603a',
  colC = '#5a2a22',
  mortarCol = '#b8b0a0',
  roughness = 0.95,
} = {}) {
  const m = new THREE.MeshStandardMaterial({ roughness, color: '#ffffff' });
  const uniforms = {
    uBrick: { value: new THREE.Vector2(...brick) },
    uMortar: { value: mortar },
    uRelief: { value: relief },
    uColA: { value: new THREE.Color(colA) },
    uColB: { value: new THREE.Color(colB) },
    uColC: { value: new THREE.Color(colC) },
    uMortarCol: { value: new THREE.Color(mortarCol) },
  };
  m.onBeforeCompile = (shader) => {
    Object.assign(shader.uniforms, uniforms);
    shader.vertexShader = shader.vertexShader.replace('#include <common>', vert.common).replace('#include <begin_vertex>', vert.begin);
    shader.fragmentShader = shader.fragmentShader
      .replace('#include <common>', fragCommon)
      .replace('#include <map_fragment>', fragMain)
      .replace('#include <normal_fragment_maps>', '#include <normal_fragment_maps>\n  normal = normalize((viewMatrix * vec4(Nbump, 0.0)).xyz);')
      .replace('#include <aomap_fragment>', '#include <aomap_fragment>\n  reflectedLight.indirectDiffuse *= bAO; reflectedLight.directDiffuse *= mix(1.0, bAO, 0.6);');
  };
  m.customProgramCacheKey = () => 'relief-brick-v1';
  m.userData.uniforms = uniforms;
  return m;
}
