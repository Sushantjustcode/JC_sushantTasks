import { Suspense, useCallback, useEffect, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { PerformanceMonitor, Preload } from '@react-three/drei';
import Engine from './rig/Engine';
import { subscribe } from './rig/engine';
import CameraRig from './rig/CameraRig';
import Atmosphere from './rig/Atmosphere';
import LightPool from './rig/LightPool';
import Effects from './rig/Effects';
import { SwayTicker } from './shared/Grass';
import EntranceScene from './scenes/EntranceScene';
import MeadowScene from './scenes/MeadowScene';
import OakScene from './scenes/OakScene';
import TrainScene from './scenes/TrainScene';
import SkyScene from './scenes/SkyScene';
import StoneWallScene from './scenes/StoneWallScene';
import DirtRoadScene from './scenes/DirtRoadScene';
import PhoneBoothScene from './scenes/PhoneBoothScene';
import IntroOverlay from './ui/IntroOverlay';
import ProgressHUD from './ui/ProgressHUD';
import SoundToggle from './ui/SoundToggle';
import EntryGate from './ui/EntryGate';
import { audio } from './audio/ambient';
import { SCROLL_VH_PER_UNIT, TOTAL } from './config/storyboard';

/**
 * Layout:
 *   z-0   fixed full-screen <Canvas> (also hosts every drei <Html> panel)
 *   z-10  DOM intro overlay          z-20 chapter HUD          z-30 sound button
 *   z-50  entry gate (pre-warm + audio unlock)
 *   -     a tall invisible #scroll-spacer: its scroll distance IS the story's length
 *
 * Resolution adapts: <PerformanceMonitor> steps the pixel ratio down on slow GPUs and back up
 * when there is headroom, so frame-rate (= smoothness) wins over sharpness.
 */
const DPR_LEVELS = [0.75, 1, [1, 1.5]];

/** Fires once the pre-warm (<Preload>) has run in the layout phase just before this mounts. */
function Ready({ onReady }) {
  useEffect(() => {
    const id = setTimeout(onReady, 250);
    return () => clearTimeout(id);
  }, [onReady]);
  return null;
}

export default function App() {
  const [ready, setReady] = useState(false);
  const [entered, setEntered] = useState(false);
  const [gone, setGone] = useState(false);
  const [sound, setSound] = useState(false);
  const [level, setLevel] = useState(2);

  const onReady = useCallback(() => setReady(true), []);
  useEffect(() => {
    if (window.__story) window.__story.audio = audio; // `?debug` only
  }, []);

  // drive the audio from the same per-frame tick as everything else
  useEffect(() => {
    let last = performance.now();
    return subscribe(() => {
      const n = performance.now();
      audio.update(Math.min(0.1, (n - last) / 1000));
      last = n;
    });
  }, []);

  const enter = (withSound) => {
    setEntered(true);
    if (withSound) audio.start().then(setSound); // called inside the click → allowed to start audio
    setTimeout(() => setGone(true), 900);
  };
  const toggleSound = () => {
    if (sound) {
      audio.stop();
      setSound(false);
    } else audio.start().then(setSound);
  };

  return (
    <>
      <div className="fixed inset-0 z-0">
        <Canvas
          dpr={DPR_LEVELS[level]}
          gl={{ antialias: false, powerPreference: 'high-performance', stencil: false }}
          camera={{ fov: 42, near: 0.2, far: 800, position: [0, 1.7, 9.5] }}
        >
          <Engine paused={!entered} />
          {entered && (
            <PerformanceMonitor
              flipflops={4}
              onDecline={() => setLevel((l) => Math.max(0, l - 1))}
              onIncline={() => setLevel((l) => Math.min(2, l + 1))}
              onFallback={() => setLevel(0)}
            />
          )}
          <SwayTicker />
          <CameraRig />
          <Atmosphere />
          <LightPool />
          <Suspense fallback={null}>
            <EntranceScene />
            <MeadowScene />
            <OakScene />
            <TrainScene />
            <SkyScene />
            <StoneWallScene />
            <DirtRoadScene />
            <PhoneBoothScene />
            <Preload all />
            <Ready onReady={onReady} />
          </Suspense>
          <Effects />
        </Canvas>
      </div>
      <IntroOverlay />
      <ProgressHUD />
      {entered && <SoundToggle on={sound} onToggle={toggleSound} />}
      {!gone && <EntryGate ready={ready} leaving={entered} onEnter={enter} />}
      <div id="scroll-spacer" aria-hidden style={{ height: `${TOTAL * SCROLL_VH_PER_UNIT}vh` }} />
    </>
  );
}
