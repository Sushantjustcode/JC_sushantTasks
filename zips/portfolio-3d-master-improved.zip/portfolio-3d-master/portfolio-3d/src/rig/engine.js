import Lenis from 'lenis';
import { rig, resetRig } from './rig';
import { evaluate } from './timeline';
import { smoothDamp } from './keyframes';
import { FEEL, TOTAL } from '../config/storyboard';

/**
 * THE SCROLL ENGINE – one pipeline, one place:
 *
 *   wheel / touch ──► Lenis (soft, frame-rate independent scroll position)
 *                 ──► target story time  = scroll progress × TOTAL
 *                 ──► critically-damped spring ► rig.time   (velocity-continuous, speed-capped)
 *                 ──► timeline tracks ► rig.* ► camera, scenes, audio, HUD
 *
 * The spring is the important part. A mouse-wheel notch is a *step* in the target; first-order
 * smoothing turns a step into an instant velocity jump (that is what felt "reactive" and like
 * fast-forward). The spring has to accelerate first, so every start and stop is soft, and the
 * speed cap means a hard fling can only ever play the story at a cinematic pace.
 *
 * It runs inside R3F's frame loop (see Engine.jsx) so input → state → render happen in
 * strict order every frame, with no second requestAnimationFrame loop to drift against.
 */

const listeners = new Set();
/** Subscribe a DOM-side updater (HUD, intro overlay…). Called once per frame after rig is updated. */
export const subscribe = (fn) => {
  listeners.add(fn);
  return () => listeners.delete(fn);
};

export const engine = { lenis: null, spring: { v: 0 }, reduced: false };

export function startEngine() {
  if ('scrollRestoration' in history) history.scrollRestoration = 'manual';
  window.scrollTo(0, 0);
  resetRig();
  engine.spring.v = 0;
  engine.reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const lenis = new Lenis({
    lerp: engine.reduced ? 1 : FEEL.lenisLerp,
    wheelMultiplier: FEEL.wheel,
    touchMultiplier: FEEL.touch,
    smoothWheel: !engine.reduced,
    autoRaf: false,
  });
  engine.lenis = lenis;
  evaluate(rig, 0);
  return () => {
    lenis.destroy();
    engine.lenis = null;
  };
}

/** Scroll the page (smoothly) so the story clock lands on `time`. Used by the HUD chapter dots. */
export function jumpToTime(time) {
  const l = engine.lenis;
  if (!l) return;
  l.scrollTo((time / TOTAL) * l.limit, { duration: 2.4, easing: (t) => 1 - Math.pow(1 - t, 3) });
}

// `?debug` in the URL exposes window.__story for screenshots / tests: goto(t) jumps the story clock instantly.
if (typeof window !== 'undefined' && new URLSearchParams(window.location.search).has('debug')) {
  window.__story = {
    rig,
    override: null, // { pos, look, fov }
    goto(time) {
      const l = engine.lenis;
      if (!l) return;
      l.scrollTo((time / TOTAL) * l.limit, { immediate: true, force: true });
      engine.spring.v = 0;
      evaluate(rig, time);
    },
  };
}

export function stepEngine(dtRaw) {
  const lenis = engine.lenis;
  if (!lenis) return;
  const dt = Math.min(Math.max(dtRaw, 1 / 240), 0.05);
  lenis.raf(performance.now());

  const limit = lenis.limit || 1;
  const progress = Math.min(1, Math.max(0, lenis.animatedScroll / limit));
  const target = progress * TOTAL;
  rig.target = target;

  const gap = Math.abs(target - rig.time);
  const maxSpeed = FEEL.maxSpeed + FEEL.maxSpeedPerGap * gap;
  const prev = rig.time;
  const next = smoothDamp(rig.time, target, engine.spring, engine.reduced ? 0.08 : FEEL.smoothTime, maxSpeed, dt);
  evaluate(rig, next);
  rig.speed += (Math.abs(next - prev) / dt - rig.speed) * (1 - Math.exp(-8 * dt)); // lightly smoothed

  listeners.forEach((fn) => fn(rig));
}
