import { useEffect, useLayoutEffect } from 'react';
import { useFrame, useThree } from '@react-three/fiber';
import { startEngine, stepEngine, engine } from './engine';

/**
 * Mount once inside <Canvas>. Priority -100 → runs before every other useFrame,
 * so the rig is fully up to date when the camera and scenes read it.
 * `paused` holds the story still (and locks scrolling) while the entry gate is up.
 */
export default function Engine({ paused = false }) {
  const gl = useThree((s) => s.gl);
  useEffect(() => {
    if (window.__story) window.__story.gl = gl; // `?debug` only: lets tests read renderer.info
  }, [gl]);
  useLayoutEffect(() => startEngine(), []);
  useLayoutEffect(() => {
    const l = engine.lenis;
    if (!l) return;
    if (paused) l.stop();
    else l.start();
  }, [paused]);
  useFrame((_, dt) => {
    stepEngine(dt);
    const g = window.__story?.gl; // `?debug`: accumulate renderer.info across ALL passes of a frame
    if (g) {
      g.info.autoReset = false;
      g.info.reset();
    }
  }, -100);
  return null;
}
