import { makeTrack } from './keyframes';
import { CAMERA_HEAD, CAMERA_TAIL, ROAD_U_KEYS, BEATS, roadPose } from '../config/storyboard';

/**
 * The whole camera move as ONE 7-channel Hermite track: [pos xyz, look-at xyz, fov].
 *   • Position, look-at and fov are all velocity-continuous (no stop-and-go between shots).
 *   • The road drone is generated from the road-progress track, sampled densely, so it
 *     follows the real spline and rests at every milestone while the text is written.
 */
const roadU = makeTrack(ROAD_U_KEYS);
const roadKeys = [];
const STEP = 0.4;
for (let t = BEATS.ROAD_T0; t < BEATS.ROAD_T1 - 1e-6; t += STEP) {
  const { pos, look } = roadPose(roadU.at(t));
  roadKeys.push({ t, pos, look, fov: 48, s: 1 });
}
{
  const { pos, look } = roadPose(roadU.at(BEATS.ROAD_T1));
  roadKeys.push({ t: BEATS.ROAD_T1, pos, look, fov: 48, s: 0.6 });
}

const ALL = [...CAMERA_HEAD, ...roadKeys, ...CAMERA_TAIL];
const track = makeTrack(ALL.map((k) => ({ t: k.t, v: [...k.pos, ...k.look, k.fov], s: k.s })));
const out = new Float64Array(7);

/** time → camera position, look-at target; returns the fov. */
export function sampleCamera(time, outPos, outLook) {
  track.into(time, out);
  outPos.set(out[0], out[1], out[2]);
  outLook.set(out[3], out[4], out[5]);
  return out[6];
}
