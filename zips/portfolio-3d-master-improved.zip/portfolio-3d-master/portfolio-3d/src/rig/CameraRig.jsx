import { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame, useThree } from '@react-three/fiber';
import { rig } from './rig';
import { sampleCamera } from './path';
import { smooth } from '../shared/utils';
import { BEATS } from '../config/storyboard';

/**
 * Samples the camera track at the (already smoothed) story clock and applies it.
 * No extra lag here on purpose: smoothing happens ONCE, upstream, in the engine –
 * stacking several smoothers is what made the old version feel mushy AND twitchy.
 * Adds only a faint hand-held drift + gentle mouse parallax, which fade to zero when
 * the contact form locks the camera.
 */
export default function CameraRig() {
  const camera = useThree((s) => s.camera);
  const size = useThree((s) => s.size);
  const tp = useMemo(() => new THREE.Vector3(), []);
  const tl = useMemo(() => new THREE.Vector3(), []);
  const ptr = useRef({ x: 0, y: 0 });

  useFrame((state, dt) => {
    const dbg = window.__story?.override; // `?debug` only: lets tests park the camera anywhere
    if (dbg) {
      camera.position.set(...dbg.pos);
      camera.lookAt(...dbg.look);
      if (camera.fov !== dbg.fov) {
        camera.fov = dbg.fov;
        camera.updateProjectionMatrix();
      }
      return;
    }
    let fov = sampleCamera(rig.time, tp, tl);

    const aspect = size.width / size.height;
    fov *= 1 + Math.max(0, 1.15 - aspect) * 0.9; // widen on portrait phones so scenes still fit

    const calm = 1 - smooth((rig.time - (BEATS.BOOTH_B + 1)) / 4); // 1 normally → 0 when the form locks
    // pointer is low-passed slowly so a flick of the mouse never jerks the picture
    const k = 1 - Math.exp(-2.2 * Math.min(dt, 0.1));
    ptr.current.x += (state.pointer.x - ptr.current.x) * k;
    ptr.current.y += (state.pointer.y - ptr.current.y) * k;

    const t = state.clock.elapsedTime;
    const dx = (Math.sin(t * 0.45) * 0.035 + ptr.current.x * 0.08) * calm;
    const dy = (Math.sin(t * 0.63 + 1.3) * 0.025 + ptr.current.y * 0.04) * calm;
    camera.position.set(tp.x + dx, tp.y + dy, tp.z);
    camera.lookAt(tl.x + dx * 0.5, tl.y + dy * 0.5, tl.z);
    if (Math.abs(camera.fov - fov) > 0.001) {
      camera.fov = fov;
      camera.updateProjectionMatrix();
    }
  });
  return null;
}
