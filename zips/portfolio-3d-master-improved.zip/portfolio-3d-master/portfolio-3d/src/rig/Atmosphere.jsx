import { useLayoutEffect, useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame, useThree } from '@react-three/fiber';
import { rig } from './rig';
import { BOOTH } from '../config/storyboard';
import { mulberry32 } from '../shared/utils';

// zenith / horizon = the sky gradient (the fog is tinted with the horizon colour, so the
// ground melts into the sky at the horizon). mtn = colour of the distant mountain ranges.
const P = (zenith, horizon, mtn, sun, sunI, hemiI, fog, sunPos) => ({
  zenith: new THREE.Color(zenith),
  horizon: new THREE.Color(horizon),
  mtn: new THREE.Color(mtn),
  sun: new THREE.Color(sun),
  sunI,
  hemiI,
  fog,
  sunPos: new THREE.Vector3(...sunPos),
});

// Index = rig.atmo. Fractions blend between neighbours.
const PALETTE = [
  P('#7fa9cf', '#e6edf0', '#7d93ab', '#fff1d4', 2.6, 1.7, 0.012, [5, 9, 12]), // 0 entrance: soft morning
  P('#3f8fe3', '#cfe7f6', '#5f86b0', '#fff7e6', 3.2, 1.8, 0.009, [-6, 16, 8]), // 1 meadow & train: bright day
  P('#1f5fcf', '#b7d6f0', '#4f77aa', '#ffffff', 3.0, 2.0, 0.0045, [8, 25, 4]), // 2 high sky
  P('#5e8fd0', '#d6e0ec', '#6382a8', '#ffe3b8', 2.8, 1.6, 0.006, [7, 12, 14]), // 3 stone wall
  P('#6f86b8', '#f7c488', '#7a6a82', '#ffc27a', 3.0, 1.5, 0.008, [10, 5, -12]), // 4 golden hour road
  P('#4a4f8c', '#f3935f', '#3f3a63', '#ff9a55', 3.4, 1.3, 0.010, BOOTH.sunPos), // 5 sunset booth
];

const _zen = new THREE.Color();
const _hor = new THREE.Color();
const _mtn = new THREE.Color();
const _v = new THREE.Vector3();
const WHITE = new THREE.Color('#ffffff');

/* ── Sky dome: a gradient from horizon haze to deep zenith, plus a soft sun glow ───────── */
const domeVert = /* glsl */ `
  varying vec3 vDir;
  void main() {
    vDir = position;
    // rotation-only view → the dome is always centred on the camera; push it to the far plane
    vec4 p = projectionMatrix * vec4(mat3(viewMatrix) * position, 1.0);
    gl_Position = p.xyww;
  }
`;
const domeFrag = /* glsl */ `
  uniform vec3 uZenith; uniform vec3 uHorizon; uniform vec3 uSunColor; uniform vec3 uSunDir;
  varying vec3 vDir;
  void main() {
    vec3 d = normalize(vDir);
    float h = d.y;
    float t = smoothstep(-0.02, 0.7, h);
    vec3 col = mix(uHorizon, uZenith, pow(t, 0.7));
    col = mix(col, uHorizon, smoothstep(0.0, -0.25, h));
    float s = max(dot(d, normalize(uSunDir)), 0.0);
    col += uSunColor * (pow(s, 900.0) * 2.2 + pow(s, 28.0) * 0.30 + pow(s, 5.0) * 0.07);
    col += uHorizon * 0.10 * exp(-abs(h) * 9.0);
    gl_FragColor = vec4(col, 1.0);
  }
`;

/* ── Mountain ring: three hazy ranges around the world = the "distant view" ───────────── */
const RANGES = [
  { r: 330, base: 10, amp: 38, haze: 0.42, seed: 3 },
  { r: 395, base: 14, amp: 52, haze: 0.62, seed: 8 },
  { r: 460, base: 18, amp: 70, haze: 0.80, seed: 15 },
];
function ridgeGeometry({ r, base, amp, seed }) {
  const N = 360;
  const rnd = mulberry32(seed);
  const ph = Array.from({ length: 6 }, () => rnd() * 6.28);
  const pos = [];
  const aH = [];
  const idx = [];
  for (let i = 0; i <= N; i++) {
    const a = (i / N) * Math.PI * 2;
    const n =
      0.5 * Math.sin(3 * a + ph[0]) + 0.3 * Math.sin(7 * a + ph[1]) + 0.2 * Math.sin(13 * a + ph[2]) +
      0.12 * Math.sin(29 * a + ph[3]) + 0.07 * Math.sin(61 * a + ph[4]);
    const h = base + amp * Math.pow(Math.max(0, (n + 0.9) / 1.9), 1.5);
    pos.push(Math.cos(a) * r, -30, Math.sin(a) * r, Math.cos(a) * r, h, Math.sin(a) * r);
    aH.push(0, 1);
    if (i < N) {
      const k = i * 2;
      idx.push(k, k + 1, k + 2, k + 1, k + 3, k + 2);
    }
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
  g.setAttribute('aH', new THREE.Float32BufferAttribute(aH, 1));
  g.setIndex(idx);
  return g;
}
const mtnVert = /* glsl */ `
  attribute float aH; varying float vH;
  void main() { vH = aH; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }
`;
const mtnFrag = /* glsl */ `
  uniform vec3 uMtn; uniform vec3 uHaze; varying float vH;
  void main() { gl_FragColor = vec4(mix(uHaze, uMtn, smoothstep(0.35, 1.0, vH)), 1.0); }
`;

/** Sky colour, fog, sun, fill light and distant mountains all follow rig.atmo, so scenes dissolve into each other. */
export default function Atmosphere() {
  const scene = useThree((s) => s.scene);
  const camera = useThree((s) => s.camera);
  const sun = useRef();
  const hemi = useRef();
  const ring = useRef();

  const dome = useMemo(
    () =>
      new THREE.ShaderMaterial({
        vertexShader: domeVert,
        fragmentShader: domeFrag,
        uniforms: {
          uZenith: { value: new THREE.Color() },
          uHorizon: { value: new THREE.Color() },
          uSunColor: { value: new THREE.Color() },
          uSunDir: { value: new THREE.Vector3(0, 1, 0) },
        },
        depthTest: false,
        depthWrite: false,
        side: THREE.BackSide,
        fog: false,
      }),
    []
  );
  const ranges = useMemo(
    () =>
      RANGES.map((R) => ({
        R,
        geo: ridgeGeometry(R),
        mat: new THREE.ShaderMaterial({
          vertexShader: mtnVert,
          fragmentShader: mtnFrag,
          uniforms: { uMtn: { value: new THREE.Color() }, uHaze: { value: new THREE.Color() } },
          side: THREE.DoubleSide,
          fog: false,
        }),
      })),
    []
  );

  useLayoutEffect(() => {
    scene.background = null;
    scene.fog = new THREE.FogExp2(PALETTE[0].horizon.getHex(), PALETTE[0].fog);
  }, [scene]);

  useFrame(() => {
    if (!scene.fog) return; // first frame can run before the effect above
    const i = Math.min(Math.floor(rig.atmo), PALETTE.length - 2);
    const f = rig.atmo - i;
    const A = PALETTE[i];
    const Bp = PALETTE[i + 1];
    _zen.copy(A.zenith).lerp(Bp.zenith, f);
    _hor.copy(A.horizon).lerp(Bp.horizon, f);
    _mtn.copy(A.mtn).lerp(Bp.mtn, f);
    _v.copy(A.sunPos).lerp(Bp.sunPos, f);

    scene.fog.color.copy(_hor);
    scene.fog.density = A.fog + (Bp.fog - A.fog) * f;

    const u = dome.uniforms;
    u.uZenith.value.copy(_zen);
    u.uHorizon.value.copy(_hor);
    u.uSunDir.value.copy(_v);

    if (sun.current) {
      sun.current.color.copy(A.sun).lerp(Bp.sun, f);
      u.uSunColor.value.copy(sun.current.color).multiplyScalar(0.55);
      sun.current.intensity = A.sunI + (Bp.sunI - A.sunI) * f;
      sun.current.position.copy(_v);
    }
    if (hemi.current) {
      hemi.current.color.copy(_zen).lerp(WHITE, 0.45);
      hemi.current.intensity = A.hemiI + (Bp.hemiI - A.hemiI) * f;
    }
    ranges.forEach(({ R, mat }) => {
      mat.uniforms.uHaze.value.copy(_hor);
      mat.uniforms.uMtn.value.copy(_mtn).lerp(_hor, R.haze);
    });
    if (ring.current) ring.current.position.set(camera.position.x, 0, camera.position.z);
  });

  return (
    <>
      <mesh renderOrder={-1000} frustumCulled={false} material={dome}>
        <sphereGeometry args={[1, 32, 16]} />
      </mesh>
      <group ref={ring}>
        {ranges.map(({ geo, mat }, i) => (
          <mesh key={i} geometry={geo} material={mat} frustumCulled={false} renderOrder={-900 + i} />
        ))}
      </group>
      <directionalLight ref={sun} />
      <hemisphereLight ref={hemi} args={['#ffffff', '#4b4a38', 1.6]} />
    </>
  );
}
