import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { rig } from './rig';
import { fadeWindow } from '../shared/utils';

/**
 * Fades a DOM node that lives inside a drei <Html> using story time.
 *   win = [fadeInStart, fadeInEnd, fadeOutStart, fadeOutEnd]
 * Fully faded nodes get display:none – that removes them from layout/paint entirely (cheap)
 * and means they can't be tabbed into. Give the node  style={{ opacity: 0, display: 'none' }}
 * to avoid a first-frame flash.
 */
export function useFade(ref, win) {
  const last = useRef(-1);
  useFrame(() => {
    const el = ref.current;
    if (!el) return;
    const o = fadeWindow(rig.time, win);
    if (Math.abs(o - last.current) < 0.004 && (o > 0.01) === (last.current > 0.01)) return;
    last.current = o;
    el.style.opacity = o.toFixed(3);
    el.style.display = o < 0.01 ? 'none' : '';
    el.style.pointerEvents = o > 0.7 ? 'auto' : 'none';
  });
}

/** Organic flicker factor (sum of three sines ≈ candle), centred on 1. */
export const flicker = (t, speed = 9, amp = 0.15, phase = 0) =>
  1 + (Math.sin(t * speed + phase) * 0.5 + Math.sin(t * speed * 2.37 + 1.7 + phase) * 0.3 + Math.sin(t * speed * 5.11 + 0.4 + phase) * 0.2) * amp;
