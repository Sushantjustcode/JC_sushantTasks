import { makeTrack } from './keyframes';
import { SCALAR_KEYS, TRAIN_KEYS, ROAD_U_KEYS, writeWindow } from '../config/storyboard';
import { TIMELINE } from '../config/cv';
import { clamp01 } from '../shared/utils';

/**
 * Every animated value, as a pure function of story time. Pure (no DOM, no React), so:
 *   evaluate(rig, 52) → rig.trainX, rig.door … is unit-testable in Node.
 * Compared to the old GSAP tweens these are Hermite tracks (see keyframes.js): velocity
 * is continuous at every key, so nothing "kicks" when one move hands over to the next.
 */
const scalar = {};
for (const [name, keys] of Object.entries(SCALAR_KEYS)) {
  scalar[name] = makeTrack(keys.map(([t, v, s]) => ({ t, v, s: s ?? 0 })));
}
const trainX = makeTrack(TRAIN_KEYS);
const roadU = makeTrack(ROAD_U_KEYS);
const windows = TIMELINE.map((_, i) => writeWindow(i));

export function evaluate(rig, time) {
  rig.time = time;
  for (const name in scalar) rig[name] = scalar[name].at(time);
  rig.trainX = trainX.at(time);
  rig.roadU = roadU.at(time);
  for (let i = 0; i < windows.length; i++) rig.write[i] = clamp01((time - windows[i][0]) / (windows[i][1] - windows[i][0]));
}
