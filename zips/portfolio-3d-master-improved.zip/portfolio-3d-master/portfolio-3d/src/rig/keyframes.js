/**
 * Keyframe tracks – the reason the camera and every animated value move SMOOTHLY.
 *
 *   const t = makeTrack([ { t: 0, v: 0, s: 0 }, { t: 4, v: 10 }, { t: 9, v: 12, s: 0 } ]);
 *   t.at(2.5)          // → number            (scalar track)
 *   t.into(2.5, out)   // → fills `out` array (vector track, no allocation)
 *
 * Between two keys the value follows a cubic Hermite curve, so VELOCITY is continuous
 * everywhere (the old setup eased every segment to a stop, which read as stop-and-go).
 *   • Tangents use the non-uniform 3-point slope and are forced to 0 at local extrema,
 *     so a track can never overshoot or wobble between keys.
 *   • `s` scales the tangent of a key:  0 = come to rest here (ease-in/out),
 *                                       1 = keep flowing through (default),
 *                                       0.3 = pass through slowly.
 *   • First and last key always rest.
 */
export function makeTrack(keys) {
  const n = keys.length;
  const vec = Array.isArray(keys[0].v);
  const dims = vec ? keys[0].v.length : 1;
  const T = new Float64Array(n);
  const V = new Float64Array(n * dims);
  const M = new Float64Array(n * dims);

  keys.forEach((k, i) => {
    T[i] = k.t;
    if (i > 0 && !(k.t > keys[i - 1].t)) throw new Error(`keyframe times must increase (key ${i}: ${k.t})`);
    for (let d = 0; d < dims; d++) V[i * dims + d] = vec ? k.v[d] : k.v;
  });

  for (let i = 1; i < n - 1; i++) {
    const h0 = T[i] - T[i - 1];
    const h1 = T[i + 1] - T[i];
    const s = keys[i].s ?? 1;
    for (let d = 0; d < dims; d++) {
      const d0 = (V[i * dims + d] - V[(i - 1) * dims + d]) / h0;
      const d1 = (V[(i + 1) * dims + d] - V[i * dims + d]) / h1;
      let m = 0;
      if (d0 * d1 > 0) {
        m = (h1 * d0 + h0 * d1) / (h0 + h1);
        const lim = 3 * Math.min(Math.abs(d0), Math.abs(d1)); // Fritsch–Carlson: stay monotone
        m = Math.sign(m) * Math.min(Math.abs(m), lim);
      }
      M[i * dims + d] = m * s;
    }
  }

  let seg = 0;
  const locate = (t) => {
    if (t <= T[0]) return 0;
    if (t >= T[n - 1]) return n - 2;
    if (t >= T[seg] && t < T[seg + 1]) return seg; // usually the same segment as last frame
    let lo = 0;
    let hi = n - 1;
    while (hi - lo > 1) {
      const mid = (lo + hi) >> 1;
      if (T[mid] <= t) lo = mid;
      else hi = mid;
    }
    return (seg = lo);
  };

  const evalInto = (t, out) => {
    const i = locate(t);
    const h = T[i + 1] - T[i];
    const u = Math.min(1, Math.max(0, (t - T[i]) / h));
    const u2 = u * u;
    const u3 = u2 * u;
    const h00 = 2 * u3 - 3 * u2 + 1;
    const h10 = u3 - 2 * u2 + u;
    const h01 = -2 * u3 + 3 * u2;
    const h11 = u3 - u2;
    for (let d = 0; d < dims; d++) {
      const a = i * dims + d;
      const b = (i + 1) * dims + d;
      out[d] = h00 * V[a] + h10 * h * M[a] + h01 * V[b] + h11 * h * M[b];
    }
    return out;
  };

  const tmp = new Float64Array(1);
  return {
    dims,
    start: T[0],
    end: T[n - 1],
    into: evalInto,
    at: (t) => evalInto(t, tmp)[0],
  };
}

/**
 * Smoothly damped follow (Unity's SmoothDamp): a critically-damped spring that keeps
 * velocity in `state.v`. Because it is second-order, the output has continuous velocity –
 * a sudden jump in `target` (one mouse-wheel notch) turns into a soft ease, never a jerk.
 * `maxSpeed` (units / second) stops violent flings from fast-forwarding the story.
 */
export function smoothDamp(current, target, state, smoothTime, maxSpeed, dt) {
  smoothTime = Math.max(1e-4, smoothTime);
  const omega = 2 / smoothTime;
  const x = omega * dt;
  const e = 1 / (1 + x + 0.48 * x * x + 0.235 * x * x * x);
  const maxChange = maxSpeed * smoothTime;
  let change = current - target;
  change = Math.min(maxChange, Math.max(-maxChange, change));
  const clampedTarget = current - change;
  const temp = (state.v + omega * change) * dt;
  state.v = (state.v - omega * temp) * e;
  let out = clampedTarget + (change + temp) * e;
  if (target - current > 0 === out > target) {
    out = target; // never overshoot
    state.v = 0;
  }
  return out;
}
