import { TRAIN, ROAD_U0 } from '../config/storyboard';
import { TIMELINE } from '../config/cv';

/**
 * The shared, MUTABLE scene state.
 *   rig/timeline.js (driven by the damped story clock) writes it → components read it in useFrame.
 * It is deliberately NOT React state: it changes 60×/s and must never trigger re-renders.
 */
const initial = () => ({
  time: 0, // story clock in scroll units (0 … TOTAL), already smoothed
  target: 0, // where the scroll wants the clock to be (un-smoothed)
  speed: 0, // |d time / d t| in units per second (used for audio + rumble)
  door: 0, // 0 closed … 1 fully open
  glow: 0, // light pouring out of the doorway
  bloom: 0.55, // post-processing bloom intensity
  dof: 0, // depth-of-field strength (scene 2 background blur)
  atmo: 0, // palette index (0 entrance … 5 sunset), fractional = blend
  trainX: TRAIN.x0, // world x of the loco's nose
  planeX: 66, // world x of the airplane
  roadU: ROAD_U0, // camera progress along the dirt road
  write: new Array(TIMELINE.length).fill(0), // 0…1 "how much of milestone i has been written"
});

export const rig = initial();
export const resetRig = () => Object.assign(rig, initial());
