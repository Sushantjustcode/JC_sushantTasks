import { rig } from '../rig/rig';
import { BEATS, PLANE_PATH } from '../config/storyboard';
import { fadeWindow, clamp01 } from '../shared/utils';

/**
 * AMBIENT SOUND – synthesised live with the Web Audio API (no audio files to ship or license).
 *
 * Every scene has its own bed that crossfades with the story clock, and the beds REACT to what is
 * on screen, so sound is tied to the motion:
 *   door      lonely wind through gaps, a low hollow drone, far-off owl and a ghostly echoing tone;
 *             the door CREAKS in proportion to how fast it is actually swinging
 *   oak       leaves rustling in a breeze + birdsong
 *   train     diesel idle + rail rumble; wheel CLACKS are triggered by distance actually travelled
 *             (so scrolling faster = faster clatter), plus air-brake hiss and a two-tone horn
 *   sky       high-altitude wind + a propeller drone with real DOPPLER and stereo PAN taken from the
 *             plane's position, swelling as it crosses
 *   wall      cold wind whistling through stone, crackling lantern fire (left / right), a distant bell
 *   road      warm breeze, evening crickets, soft birds – and a stick SCRATCHING while text is written
 *   booth     dusk crickets, buzzing bulb, a British double-ring telephone
 * plus a global air "whoosh" that follows the camera's speed.
 *
 * Browsers only allow audio after a user gesture, so start() is called from the entry gate / sound
 * button. Everything is quiet by design: it sits under the content, never on top of it.
 */
/** Overall level. The beds are synthesised hot and then trimmed so they sit UNDER the content (≈ −26 dBFS RMS). */
const MASTER = 0.35;
const rand = (a, b) => a + Math.random() * (b - a);
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];

// ── tiny node helpers ────────────────────────────────────────────────────────────────────
const gain = (A, v = 0) => {
  const g = A.ctx.createGain();
  g.gain.value = v;
  return g;
};
const biquad = (A, type, f, q = 0.7) => {
  const b = A.ctx.createBiquadFilter();
  b.type = type;
  b.frequency.value = f;
  b.Q.value = q;
  return b;
};
const newOsc = (A, type, f) => {
  const o = A.ctx.createOscillator();
  o.type = type;
  o.frequency.value = f;
  return o;
};
const osc = (A, type, f) => {
  const o = newOsc(A, type, f);
  o.start();
  return o;
};
const chain = (...n) => {
  for (let i = 0; i < n.length - 1; i++) n[i].connect(n[i + 1]);
  return n[n.length - 1];
};
const lfo = (A, freq, depth, param, type = 'sine') => {
  const o = osc(A, type, freq);
  const g = gain(A, depth);
  o.connect(g);
  g.connect(param);
  return o;
};
const noiseSrc = (A, buf, rate = 1) => {
  const s = A.ctx.createBufferSource();
  s.buffer = buf;
  s.loop = true;
  s.playbackRate.value = rate;
  s.start(0, Math.random() * buf.duration);
  return s;
};
const ramp = (A, param, v, tc = 0.2) => param.setTargetAtTime(v, A.now(), tc);
const sendEcho = (A, node, amt = 0.5) => {
  const s = gain(A, amt);
  node.connect(s);
  s.connect(A.echo);
};

/** Stereo noise, normalised to a steady level, with an equal-power loop seam (no click when it repeats). */
function noiseBuffer(ctx, seconds, type) {
  const F = Math.floor(ctx.sampleRate * 0.4);
  const n = Math.floor(ctx.sampleRate * seconds);
  const buf = ctx.createBuffer(2, n, ctx.sampleRate);
  for (let ch = 0; ch < 2; ch++) {
    const raw = new Float32Array(n + F);
    let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0, last = 0;
    for (let i = 0; i < raw.length; i++) {
      const w = Math.random() * 2 - 1;
      if (type === 'white') raw[i] = w;
      else if (type === 'pink') {
        b0 = 0.99886 * b0 + w * 0.0555179; b1 = 0.99332 * b1 + w * 0.0750759; b2 = 0.969 * b2 + w * 0.153852;
        b3 = 0.8665 * b3 + w * 0.3104856; b4 = 0.55 * b4 + w * 0.5329522; b5 = -0.7616 * b5 - w * 0.016898;
        raw[i] = b0 + b1 + b2 + b3 + b4 + b5 + b6 + w * 0.5362;
        b6 = w * 0.115926;
      } else {
        last = (last + 0.02 * w) / 1.02;
        raw[i] = last;
      }
    }
    let ss = 0;
    for (let i = 0; i < raw.length; i++) ss += raw[i] * raw[i];
    const k = 0.25 / Math.sqrt(ss / raw.length); // RMS ≈ −12 dBFS
    const d = buf.getChannelData(ch);
    for (let i = 0; i < n; i++) {
      let v = raw[i] * k;
      if (i < F) {
        const a = (i / F) * (Math.PI / 2);
        v = raw[i] * k * Math.sin(a) + raw[n + i] * k * Math.cos(a);
      }
      d[i] = v;
    }
  }
  return buf;
}

// ── one-shot sounds ──────────────────────────────────────────────────────────────────────
function chirp(A, out, { base = 3200, notes = 4, gainV = 0.05, pan = 0 } = {}) {
  const ctx = A.ctx;
  const p = ctx.createStereoPanner();
  p.pan.value = pan;
  p.connect(out);
  let t = A.now() + 0.02;
  const t0 = t;
  for (let i = 0; i < notes; i++) {
    const o = newOsc(A, 'sine', base);
    const g = gain(A, 0);
    const f0 = base * rand(0.85, 1.35);
    const f1 = Math.max(400, f0 * rand(0.6, 1.5));
    const d = rand(0.045, 0.12);
    o.frequency.setValueAtTime(f0, t);
    o.frequency.exponentialRampToValueAtTime(f1, t + d);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(gainV, t + 0.012);
    g.gain.exponentialRampToValueAtTime(0.0001, t + d + 0.03);
    o.connect(g);
    g.connect(p);
    o.start(t);
    o.stop(t + d + 0.06);
    t += d + rand(0.025, 0.09);
  }
  setTimeout(() => p.disconnect(), (t - t0 + 0.6) * 1000);
}

function cuckoo(A, out, gainV = 0.03) {
  const t = A.now() + 0.02;
  [[0, 640, 500], [0.34, 560, 430]].forEach(([off, f0, f1]) => {
    const o = newOsc(A, 'sine', f0);
    const g = gain(A, 0);
    o.frequency.setValueAtTime(f0, t + off);
    o.frequency.linearRampToValueAtTime(f1, t + off + 0.22);
    g.gain.setValueAtTime(0, t + off);
    g.gain.linearRampToValueAtTime(gainV, t + off + 0.04);
    g.gain.linearRampToValueAtTime(0, t + off + 0.26);
    o.connect(g);
    g.connect(out);
    sendEcho(A, g, 0.5);
    o.start(t + off);
    o.stop(t + off + 0.3);
  });
}

function owl(A, out) {
  const t = A.now() + 0.02;
  [[0, 0.5], [0.75, 0.9]].forEach(([off, len]) => {
    const o = newOsc(A, 'sine', 300);
    const g = gain(A, 0);
    o.frequency.setValueAtTime(330, t + off);
    o.frequency.linearRampToValueAtTime(285, t + off + len);
    g.gain.setValueAtTime(0, t + off);
    g.gain.linearRampToValueAtTime(0.045, t + off + 0.12);
    g.gain.linearRampToValueAtTime(0, t + off + len);
    o.connect(g);
    g.connect(out);
    sendEcho(A, g, 0.9);
    o.start(t + off);
    o.stop(t + off + len + 0.05);
  });
}

function ghostNote(A, out, f) {
  const t = A.now() + 0.02;
  const o = newOsc(A, 'sine', f);
  const g = gain(A, 0);
  const vib = newOsc(A, 'sine', 4.6);
  const vg = gain(A, f * 0.006);
  vib.connect(vg);
  vg.connect(o.frequency);
  g.gain.setValueAtTime(0, t);
  g.gain.linearRampToValueAtTime(0.03, t + 2.8);
  g.gain.linearRampToValueAtTime(0, t + 8);
  o.connect(g);
  g.connect(out);
  sendEcho(A, g, 1);
  [o, vib].forEach((n) => {
    n.start(t);
    n.stop(t + 8.1);
  });
}

function bell(A, out, f = 392, g0 = 0.05) {
  const t = A.now() + 0.02;
  [[1, 6, 0.5], [2.0, 3.8, 0.25], [2.76, 2.4, 0.14], [5.4, 1.1, 0.06]].forEach(([r, d, v]) => {
    const o = newOsc(A, 'sine', f * r);
    const g = gain(A, 0);
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(g0 * v, t + 0.01);
    g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(g);
    g.connect(out);
    sendEcho(A, g, 0.7);
    o.start(t);
    o.stop(t + d + 0.1);
  });
}

function horn(A, out, dur = 1.5) {
  const t = A.now() + 0.02;
  const lp = biquad(A, 'lowpass', 1500, 0.9);
  const g = gain(A, 0);
  lp.connect(g);
  g.connect(out);
  sendEcho(A, g, 0.35);
  [[277.2, -5], [277.2, 6], [349.2, -4], [349.2, 5], [415.3, 0]].forEach(([f, c]) => {
    const o = newOsc(A, 'sawtooth', f);
    o.detune.value = c;
    const og = gain(A, 0.2);
    o.connect(og);
    og.connect(lp);
    o.frequency.setValueAtTime(f * 1.012, t);
    o.frequency.linearRampToValueAtTime(f, t + 0.25);
    o.frequency.setValueAtTime(f, t + dur);
    o.frequency.linearRampToValueAtTime(f * 0.97, t + dur + 0.6);
    o.start(t);
    o.stop(t + dur + 0.65);
  });
  g.gain.setValueAtTime(0, t);
  g.gain.linearRampToValueAtTime(0.15, t + 0.14);
  g.gain.setValueAtTime(0.15, t + dur);
  g.gain.linearRampToValueAtTime(0, t + dur + 0.6);
}

function clack(A, out, g0, pan) {
  const ctx = A.ctx;
  const t = A.now() + 0.01;
  const p = ctx.createStereoPanner();
  p.pan.value = pan;
  p.connect(out);
  [0, 0.078].forEach((off, k) => {
    const s = ctx.createBufferSource();
    s.buffer = A.click;
    const bp = biquad(A, 'bandpass', rand(900, 1500), 1.4);
    const ge = gain(A, 0);
    const v = g0 * (k ? 0.75 : 1);
    ge.gain.setValueAtTime(0, t + off);
    ge.gain.linearRampToValueAtTime(v, t + off + 0.003);
    ge.gain.exponentialRampToValueAtTime(0.0008, t + off + 0.075);
    chain(s, bp, ge).connect(p);
    s.start(t + off);
    const th = newOsc(A, 'sine', 120);
    const tg = gain(A, 0);
    th.frequency.exponentialRampToValueAtTime(55, t + off + 0.08);
    tg.gain.setValueAtTime(0, t + off);
    tg.gain.linearRampToValueAtTime(v * 1.1, t + off + 0.004);
    tg.gain.exponentialRampToValueAtTime(0.0008, t + off + 0.09);
    chain(th, tg).connect(p);
    th.start(t + off);
    th.stop(t + off + 0.1);
  });
  setTimeout(() => p.disconnect(), 600);
}

function hiss(A, out) {
  const t = A.now() + 0.02;
  const s = A.ctx.createBufferSource();
  s.buffer = A.white;
  const hp = biquad(A, 'highpass', 2800, 0.6);
  const g = gain(A, 0);
  g.gain.setValueAtTime(0, t);
  g.gain.linearRampToValueAtTime(0.045, t + 0.05);
  g.gain.exponentialRampToValueAtTime(0.0005, t + 1.6);
  chain(s, hp, g).connect(out);
  s.start(t, Math.random() * 2);
  s.stop(t + 1.7);
}

function pop(A, out, pan, g0) {
  const ctx = A.ctx;
  const t = A.now() + 0.005;
  const s = ctx.createBufferSource();
  s.buffer = A.click;
  const bp = biquad(A, 'bandpass', rand(1800, 5200), 2.2);
  const g = gain(A, 0);
  const p = ctx.createStereoPanner();
  p.pan.value = pan;
  const d = rand(0.008, 0.04);
  g.gain.setValueAtTime(g0, t);
  g.gain.exponentialRampToValueAtTime(0.0005, t + d);
  chain(s, bp, g, p).connect(out);
  s.start(t, Math.random() * 0.02);
  s.stop(t + d + 0.02);
}

function phoneRing(A, out, g0 = 0.05) {
  const t = A.now() + 0.05;
  [0, 0.6].forEach((off) => {
    const am = gain(A, 0.5);
    const env = gain(A, 0);
    const lp = biquad(A, 'lowpass', 2600, 0.5);
    const o1 = newOsc(A, 'sine', 400);
    const o2 = newOsc(A, 'sine', 450);
    const l = newOsc(A, 'sine', 25);
    const ld = gain(A, 0.5);
    l.connect(ld);
    ld.connect(am.gain);
    o1.connect(am);
    o2.connect(am);
    chain(am, env, lp).connect(out);
    sendEcho(A, lp, 0.45);
    env.gain.setValueAtTime(0, t + off);
    env.gain.linearRampToValueAtTime(g0, t + off + 0.01);
    env.gain.setValueAtTime(g0, t + off + 0.39);
    env.gain.linearRampToValueAtTime(0, t + off + 0.41);
    [o1, o2, l].forEach((n) => {
      n.start(t + off);
      n.stop(t + off + 0.45);
    });
  });
}

// ── building blocks for beds ─────────────────────────────────────────────────────────────
function wind(A, out, { f = 380, q = 0.6, lp = 1100, g = 0.5, gust = 0.07, depth = 160, mod = 0.35 }) {
  const bp = biquad(A, 'bandpass', f, q);
  const gn = gain(A, g);
  chain(noiseSrc(A, A.pink), bp, biquad(A, 'lowpass', lp, 0.5), gn).connect(out);
  lfo(A, gust, depth, bp.frequency);
  lfo(A, gust * 1.7, g * mod, gn.gain);
  return gn;
}

function crickets(A, out) {
  const master = gain(A, 0);
  master.connect(out);
  [[4300, 31, 2.4, 0.016], [4700, 36, 2.9, 0.013], [5150, 28, 1.9, 0.011], [3900, 24, 3.3, 0.01]].forEach(([f, r1, r2, v]) => {
    const o = osc(A, 'sine', f);
    const a1 = gain(A, 0.5);
    const a2 = gain(A, 0.5);
    const g = gain(A, v);
    const p = A.ctx.createStereoPanner();
    p.pan.value = rand(-0.8, 0.8);
    [[r1, a1, 70], [r2, a2, 20]].forEach(([r, a, cut]) => {
      const l = osc(A, 'square', r * rand(0.98, 1.02));
      chain(l, biquad(A, 'lowpass', cut, 0.5), gain(A, 0.5)).connect(a.gain);
    });
    chain(o, a1, a2, g, p).connect(master);
  });
  return master;
}

const birdScheduler = (A, out, { rate = 1, gainV = 0.045, song = 0.12 } = {}) => {
  let next = A.clock + rand(0.5, 2);
  return (w) => {
    if (A.clock < next || w < 0.05) return;
    next = A.clock + rand(0.7, 3.2) / Math.max(0.2, rate);
    const pan = rand(-0.85, 0.85);
    if (Math.random() < song) chirp(A, out, { base: rand(2600, 3800), notes: 8 + Math.floor(Math.random() * 6), gainV: gainV * 0.9, pan });
    else chirp(A, out, { base: rand(2200, 4800), notes: 2 + Math.floor(Math.random() * 4), gainV, pan });
  };
};

// ── the seven beds ───────────────────────────────────────────────────────────────────────
function entranceBed(A, out) {
  wind(A, out, { f: 380, lp: 1100, g: 0.9, gust: 0.07 });
  const whistle = gain(A, 0.05);
  const wbp = biquad(A, 'bandpass', 1250, 18);
  chain(noiseSrc(A, A.pink), wbp, whistle).connect(out);
  lfo(A, 0.05, 240, wbp.frequency);
  lfo(A, 0.09, 0.03, whistle.gain);
  const dl = biquad(A, 'lowpass', 220, 0.7);
  const dg = gain(A, 0.13);
  chain(dl, dg).connect(out);
  [[55, 'triangle', 0.5], [55.8, 'triangle', 0.5], [82.4, 'sine', 0.22]].forEach(([f, t, v]) => {
    const o = osc(A, t, f);
    chain(o, gain(A, v)).connect(dl);
  });
  const co = osc(A, 'sawtooth', 90);
  const cg = gain(A, 0);
  chain(co, biquad(A, 'bandpass', 850, 9), cg).connect(out);
  lfo(A, 7.3, 12, co.frequency);
  let nextGhost = A.clock + 4;
  let nextOwl = A.clock + 12;
  let last = rig.door;
  const notes = [440, 523.25, 392, 349.23, 659.25];
  return {
    update(dt, w) {
      const speed = Math.abs(rig.door - last) / Math.max(dt, 1e-3);
      last = rig.door;
      const moving = rig.door > 0.015 && rig.door < 0.995;
      ramp(A, cg.gain, moving ? clamp01(speed * 1.1) * 0.3 : 0, 0.08);
      ramp(A, co.frequency, 70 + rig.door * 60, 0.1);
      if (w > 0.05 && A.clock > nextGhost) {
        ghostNote(A, out, pick(notes));
        nextGhost = A.clock + rand(11, 19);
      }
      if (w > 0.05 && A.clock > nextOwl) {
        owl(A, out);
        nextOwl = A.clock + rand(20, 34);
      }
    },
  };
}

function oakBed(A, out) {
  wind(A, out, { f: 1800, q: 0.5, lp: 4200, g: 0.55, gust: 0.13, mod: 0.5 }); // leaves
  wind(A, out, { f: 300, q: 0.5, lp: 450, g: 0.8, gust: 0.09 }); // breeze
  const birds = birdScheduler(A, out, { rate: 1, gainV: 0.05, song: 0.14 });
  let nextCuckoo = A.clock + rand(8, 16);
  return {
    update(dt, w) {
      birds(w);
      if (w > 0.2 && A.clock > nextCuckoo) {
        cuckoo(A, out);
        nextCuckoo = A.clock + rand(22, 38);
      }
    },
  };
}

function trainBed(A, out) {
  const eng = gain(A, 0.2);
  const elp = biquad(A, 'lowpass', 170, 0.7);
  chain(elp, eng).connect(out);
  [[52, 'sawtooth', 0.4], [53.4, 'sawtooth', 0.4], [41, 'sine', 0.5]].forEach(([f, t, v]) => chain(osc(A, t, f), gain(A, v)).connect(elp));
  lfo(A, 7.2, 0.02, eng.gain); // idle "lope"
  const rum = gain(A, 0.5);
  chain(noiseSrc(A, A.brown), biquad(A, 'lowpass', 150, 0.6), rum).connect(out);
  const wh = gain(A, 0);
  chain(noiseSrc(A, A.pink), biquad(A, 'bandpass', 2200, 0.8), wh).connect(out);
  const nat = gain(A, 0.22); // distant meadow behind the train
  nat.connect(out);
  wind(A, nat, { f: 1500, q: 0.5, lp: 3500, g: 0.4 });
  const birds = birdScheduler(A, nat, { rate: 0.5, gainV: 0.04 });
  let lastX = rig.trainX;
  let accum = 0;
  let lastClack = 0;
  let spd = 0;
  let nextHorn = Infinity;
  let nextHiss = A.clock + 8;
  let announced = false;
  return {
    update(dt, w) {
      const d = Math.abs(rig.trainX - lastX);
      lastX = rig.trainX;
      spd += (d / Math.max(dt, 1e-3) - spd) * (1 - Math.exp(-6 * dt));
      ramp(A, rum.gain, 0.45 + Math.min(spd, 6) * 0.1, 0.15);
      ramp(A, wh.gain, Math.min(spd / 5, 1) * 0.07, 0.15);
      ramp(A, elp.frequency, 160 + Math.min(spd, 6) * 8, 0.2);
      accum += d;
      const SPACING = 3.1; // world units between rail joints
      if (accum > SPACING && w > 0.08) {
        accum %= SPACING;
        if (A.clock - lastClack > 0.05) {
          lastClack = A.clock;
          clack(A, out, 0.07 + Math.min(spd / 5, 1) * 0.22, rand(-0.25, 0.25));
        }
      } else if (accum > SPACING) accum %= SPACING;
      birds(w * 0.6);
      if (w > 0.5 && !announced) {
        announced = true;
        nextHorn = A.clock + 1.4;
      }
      if (A.clock > nextHorn && w > 0.3) {
        horn(A, out, 0.45);
        setTimeout(() => A.enabled && horn(A, out, 1.5), 900);
        nextHorn = A.clock + rand(28, 46);
      }
      if (A.clock > nextHiss && w > 0.3) {
        hiss(A, out);
        nextHiss = A.clock + rand(10, 22);
      }
    },
  };
}

function skyBed(A, out) {
  wind(A, out, { f: 650, q: 0.5, lp: 2400, g: 0.8, gust: 0.08 });
  const hi = gain(A, 0.06);
  chain(noiseSrc(A, A.pink), biquad(A, 'highpass', 1800, 0.5), hi).connect(out);
  lfo(A, 0.11, 0.03, hi.gain);
  // propeller plane
  const pan = A.ctx.createStereoPanner();
  const pg = gain(A, 0);
  const am = gain(A, 0.78);
  const pl = biquad(A, 'lowpass', 520, 0.9);
  const oscs = [osc(A, 'sawtooth', 84), osc(A, 'sawtooth', 85), osc(A, 'square', 42)];
  oscs.forEach((o, i) => chain(o, gain(A, i === 2 ? 0.3 : 0.5)).connect(pl));
  lfo(A, 28, 0.22, am.gain);
  chain(pl, am, pg, pan).connect(out);
  const { X0, X1, Z0, Z1, Y0, Y1 } = PLANE_PATH;
  return {
    update() {
      const act = fadeWindow(rig.time, [BEATS.planeFrom - 1.5, BEATS.planeFrom + 1, BEATS.planeTo - 1, BEATS.planeTo + 1.5]);
      const u = clamp01((rig.planeX - X0) / (X1 - X0));
      const dx = rig.planeX;
      const dz = Z0 + (Z1 - Z0) * u + 30;
      const dy = Y0 + (Y1 - Y0) * u - 4;
      const dist = Math.hypot(dx, dz, dy);
      const s = dx / dist; // +1: plane is to the right (and approaching)
      const pitch = 1 + 0.06 * s;
      oscs.forEach((o, i) => ramp(A, o.frequency, [84, 85, 42][i] * pitch, 0.12));
      ramp(A, pan.pan, Math.max(-1, Math.min(1, dx / 40)), 0.1);
      ramp(A, pg.gain, (0.9 / (1 + (dist / 55) ** 2)) * act, 0.15);
    },
  };
}

function wallBed(A, out) {
  wind(A, out, { f: 240, q: 1.0, lp: 700, g: 0.9, gust: 0.06 });
  const whistle = gain(A, 0.012);
  const wbp = biquad(A, 'bandpass', 1500, 14);
  chain(noiseSrc(A, A.pink), wbp, whistle).connect(out);
  lfo(A, 0.05, 300, wbp.frequency);
  lfo(A, 0.08, 0.008, whistle.gain);
  const roar = gain(A, 0.08);
  chain(noiseSrc(A, A.brown), biquad(A, 'bandpass', 190, 0.7), roar).connect(out);
  lfo(A, 6.5, 0.02, roar.gain);
  lfo(A, 0.7, 0.03, roar.gain);
  let nextPop = A.clock;
  let nextBell = A.clock + rand(5, 10);
  return {
    update(dt, w) {
      if (w > 0.05) {
        while (A.clock > nextPop) {
          const left = Math.random() < 0.5;
          pop(A, out, left ? -0.7 : 0.7, rand(0.02, 0.12) * (Math.random() < 0.08 ? 2.5 : 1));
          nextPop += rand(0.03, 0.14);
          if (nextPop < A.clock - 0.3) nextPop = A.clock;
        }
      } else nextPop = A.clock;
      if (w > 0.3 && A.clock > nextBell) {
        bell(A, out, pick([392, 349.23, 293.66]), 0.05);
        nextBell = A.clock + rand(22, 38);
      }
    },
  };
}

function roadBed(A, out) {
  wind(A, out, { f: 500, q: 0.5, lp: 800, g: 0.8, gust: 0.07 });
  const cr = crickets(A, out);
  const birds = birdScheduler(A, out, { rate: 0.45, gainV: 0.035, song: 0.2 });
  const sg = gain(A, 0);
  const sbp = biquad(A, 'bandpass', 2600, 1.2);
  const sam = gain(A, 0.55);
  chain(noiseSrc(A, A.pink), sbp, biquad(A, 'highpass', 900, 0.5), sam, sg).connect(out);
  chain(osc(A, 'square', 11), biquad(A, 'lowpass', 40, 0.5), gain(A, 0.45)).connect(sam.gain);
  const prev = rig.write.slice();
  let rate = 0;
  return {
    update(dt, w) {
      ramp(A, cr.gain, 0.35 + 0.45 * clamp01((rig.time - BEATS.ROAD_T0) / (BEATS.ROAD_T1 - BEATS.ROAD_T0)), 0.5);
      birds(w * (1 - 0.6 * clamp01((rig.time - BEATS.ROAD_T0) / (BEATS.ROAD_T1 - BEATS.ROAD_T0))));
      let d = 0;
      for (let i = 0; i < prev.length; i++) {
        d += Math.abs(rig.write[i] - prev[i]);
        prev[i] = rig.write[i];
      }
      rate += (d / Math.max(dt, 1e-3) - rate) * (1 - Math.exp(-10 * dt));
      ramp(A, sg.gain, Math.min(rate * 0.2, 0.11), 0.06);
      ramp(A, sbp.frequency, 2200 + Math.min(rate, 1) * 900, 0.1);
    },
  };
}

function boothBed(A, out) {
  wind(A, out, { f: 300, q: 0.5, lp: 500, g: 0.6, gust: 0.06 });
  const cr = crickets(A, out);
  ramp(A, cr.gain, 1, 0.1);
  const hum = gain(A, 0);
  [100, 200, 300].forEach((f, i) => chain(osc(A, 'sine', f), gain(A, [0.5, 0.25, 0.12][i])).connect(hum));
  const buzz = gain(A, 0);
  chain(noiseSrc(A, A.pink), biquad(A, 'bandpass', 120, 6), buzz).connect(out);
  hum.connect(out);
  const birds = birdScheduler(A, out, { rate: 0.25, gainV: 0.025 });
  let nextRing = A.clock + 1.5;
  return {
    update(dt, w) {
      const near = clamp01((rig.time - BEATS.BOOTH_A) / (BEATS.BOOTH_C - BEATS.BOOTH_A));
      ramp(A, hum.gain, 0.012 + near * 0.02, 0.4);
      ramp(A, buzz.gain, 0.01 + near * 0.02, 0.4);
      birds(w * 0.4);
      const ringOk = fadeWindow(rig.time, [BEATS.BOOTH_A - 2, BEATS.BOOTH_A + 1, BEATS.BOOTH_B + 1, BEATS.BOOTH_B + 4]);
      if (A.clock > nextRing) {
        if (ringOk > 0.5 && w > 0.3) phoneRing(A, out, 0.05 * ringOk);
        nextRing = A.clock + (ringOk > 0.5 ? 8 : 1);
      }
    },
  };
}

const BEDS = {
  entrance: { build: entranceBed, win: () => [-1, 0, 8, 13] },
  oak: { build: oakBed, win: () => [9, 14, 35, 40] },
  train: { build: trainBed, win: () => [38, 43, BEATS.TRAIN_OUT - 3, BEATS.TRAIN_OUT + 2] },
  sky: { build: skyBed, win: () => [BEATS.TRAIN_OUT - 2, BEATS.TRAIN_OUT + 3, BEATS.WALL_IN - 2, BEATS.WALL_IN + 3] },
  wall: { build: wallBed, win: () => [BEATS.WALL_IN - 2, BEATS.WALL_IN + 2, BEATS.ROAD_YAW - 1, BEATS.ROAD_YAW + 3] },
  road: { build: roadBed, win: () => [BEATS.ROAD_YAW, BEATS.ROAD_T0, BEATS.BOOTH_A - 4, BEATS.BOOTH_A + 1] },
  booth: { build: boothBed, win: () => [BEATS.BOOTH_A - 4, BEATS.BOOTH_A + 1] },
};

export class AmbientAudio {
  constructor() {
    this.ctx = null;
    this.enabled = false;
    this.clock = 0;
    this.layers = {};
    this.supported = typeof window !== 'undefined' && !!(window.AudioContext || window.webkitAudioContext);
    this.now = () => (this.ctx ? this.ctx.currentTime : 0);
  }

  /** Build the graph (idempotent). `ctx` may be injected, e.g. an OfflineAudioContext in tests. */
  init(ctx) {
    if (this.ctx) return;
    const AC = window.AudioContext || window.webkitAudioContext;
    this.ctx = ctx || new AC({ latencyHint: 'playback' });
    const c = this.ctx;
    this.master = gain(this, 0);
    const comp = c.createDynamicsCompressor();
    comp.threshold.value = -12;
    comp.knee.value = 20;
    comp.ratio.value = 6;
    comp.attack.value = 0.01;
    comp.release.value = 0.3;
    this.master.connect(comp);
    comp.connect(c.destination);
    this.white = noiseBuffer(c, 3, 'white');
    this.pink = noiseBuffer(c, 8, 'pink');
    this.brown = noiseBuffer(c, 8, 'brown');
    this.click = noiseBuffer(c, 0.12, 'white');
    // shared feedback echo for "far away / lonely" sounds
    this.echo = gain(this, 1);
    const delay = c.createDelay(1);
    delay.delayTime.value = 0.41;
    const fb = gain(this, 0.42);
    const tone = biquad(this, 'lowpass', 1700, 0.5);
    const wet = gain(this, 0.55);
    this.echo.connect(delay);
    delay.connect(tone);
    tone.connect(fb);
    fb.connect(delay);
    tone.connect(wet);
    wet.connect(this.master);
    // always-on whoosh that follows how fast the story is moving
    this.moveGain = gain(this, 0);
    chain(noiseSrc(this, this.pink), biquad(this, 'bandpass', 420, 0.6), this.moveGain).connect(this.master);
    this.onVis = () => {
      if (!this.ctx || this.ctx.state === 'closed') return;
      if (document.hidden) this.ctx.suspend();
      else if (this.enabled) this.ctx.resume();
    };
    document.addEventListener('visibilitychange', this.onVis);
  }

  /** Must be called from a user gesture (click / key / touch). */
  async start() {
    if (!this.supported) return false;
    this.init();
    try {
      await this.ctx.resume();
    } catch {
      return false;
    }
    this.enabled = true;
    this.master.gain.cancelScheduledValues(this.now());
    this.master.gain.setTargetAtTime(MASTER, this.now(), 0.6);
    return true;
  }

  stop() {
    this.enabled = false;
    if (!this.ctx) return;
    this.master.gain.cancelScheduledValues(this.now());
    this.master.gain.setTargetAtTime(0, this.now(), 0.15);
    setTimeout(() => !this.enabled && this.ctx && this.ctx.suspend(), 700);
  }

  /** Call once per frame. */
  update(dt) {
    if (!this.ctx || !this.enabled) return;
    this.clock += dt;
    const t = rig.time;
    for (const id in BEDS) {
      const w = fadeWindow(t, BEDS[id].win());
      let L = this.layers[id];
      if (!L) {
        if (w < 0.002) continue;
        const bus = gain(this, 0);
        bus.connect(this.master);
        L = this.layers[id] = { bus, ...BEDS[id].build(this, bus) };
      }
      ramp(this, L.bus.gain, Math.sqrt(w), 0.25);
      if (w > 0.002 && L.update) L.update(dt, w);
    }
    ramp(this, this.moveGain.gain, clamp01(rig.speed / 7) * 0.09, 0.25);
  }
}

export const audio = new AmbientAudio();
