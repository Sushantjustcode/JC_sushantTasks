import * as THREE from 'three';
import { SKILL_GROUPS, TIMELINE } from './cv';

// ─────────────────────────────────────────────────────────────────────────────
// STORYBOARD = the one file that decides *when* and *where* everything happens.
//   • Time is measured in "scroll units". 1 unit = SCROLL_VH_PER_UNIT viewport heights.
//   • Scroll → (Lenis) → damped story clock `rig.time` → keyframe tracks → everything.
//   • Each scene has `start/end` (its story beat) and `show` (when it is rendered).
//
// PACING: reading scenes (train, wall, road, booth) are built from "dwell stops": the
// camera / train / road comes to a near-rest while the content is on screen, then glides
// to the next stop. Change a *_STEP or *_HOLD constant to give a scene more or less time.
// ─────────────────────────────────────────────────────────────────────────────

export const SCROLL_VH_PER_UNIT = 10;

/** How scrolling FEELS. Tweak these first if it ever feels too floaty / too tight. */
export const FEEL = {
  wheel: 0.7, // mouse-wheel / trackpad sensitivity (1 = native). Lower = less reactive.
  touch: 1.0,
  lenisLerp: 0.16, // first smoothing stage (the scroll position itself)
  smoothTime: 0.45, // seconds for the story clock to settle (second, spring-based stage)
  maxSpeed: 4, // story units / second the clock may travel at when the target is close…
  maxSpeedPerGap: 0.7, // …plus this much per unit of distance still to cover (scrollbar drags fly faster)
};

// ── Beats (units) ────────────────────────────────────────────────────────────
const OAK_IN = 12.5; // camera has stepped through the door
const OAK_OUT = 30; // end of plaque reading
const RAILS = 36; // slid past the oak, eyes on the rails
const TRAIN_IN = 41.5; // parked beside the train
const TRAIN_STEP = 5.4; // scroll units per coach (travel + rest): ~2 at rest, ~3.4 gliding to the next
const TRAIN_HOLD = 1.0; // half-width of the rest, per coach
export const trainStop = (k) => 43 + k * TRAIN_STEP; // k = 0 loco … 7 guard van
const TRAIN_LAST_HOLD = trainStop(7) + TRAIN_HOLD;
const TRAIN_OUT = TRAIN_LAST_HOLD + 4.4; // last coach has left the frame

const SKY_A = TRAIN_LAST_HOLD + 2.4;
const SKY_B = SKY_A + 7;
const FLIGHT = SKY_B + 5.5; // mid-flight crane over the hills
const WALL_IN = SKY_B + 11;
const WALL_STEP = 4.9;
const WALL_HOLD = 1.3;
export const wallStop = (k) => WALL_IN + 1.8 + k * WALL_STEP; // 5 project frames
const WALL_LAST_HOLD = wallStop(4) + WALL_HOLD;

const ROAD_YAW = WALL_LAST_HOLD + 2.5;
const ROAD_T0 = ROAD_YAW + 4;
const ROAD_STEP = 5.0;
const ROAD_HOLD = 1.3;
export const roadStop = (i) => ROAD_T0 + 4 + i * ROAD_STEP; // 8 milestones
const ROAD_T1 = roadStop(TIMELINE.length - 1) + ROAD_HOLD + 3;

const BOOTH_A = ROAD_T1 + 5;
const BOOTH_A2 = BOOTH_A + 2.5; // resting on the signpost
const BOOTH_B = BOOTH_A2 + 4.5;
const BOOTH_C = BOOTH_B + 5.5; // very close on the note
export const TOTAL = Math.ceil(BOOTH_C + 1.5);

export const SCENES = [
  { id: 'entrance', label: 'The Entrance', start: 0, jump: 0, end: OAK_IN, show: [0, 15] },
  { id: 'oak', label: 'The Oak Tree', start: OAK_IN, jump: OAK_IN + 1.5, end: RAILS, show: [0, 42] },
  { id: 'train', label: 'The Blue Train', start: RAILS, jump: trainStop(0), end: SKY_A - 2, show: [3, TRAIN_OUT + 4] },
  { id: 'sky', label: 'The Sky', start: SKY_A - 2, jump: SKY_A - 2, end: WALL_IN, show: [TRAIN_LAST_HOLD - 4, WALL_IN + 1] },
  { id: 'wall', label: 'The Stone Wall', start: WALL_IN, jump: WALL_IN + 0.5, end: ROAD_YAW - 0.5, show: [SKY_B, ROAD_YAW + 2] },
  { id: 'road', label: 'The Dirt Road', start: ROAD_YAW - 0.5, jump: ROAD_T0 + 3, end: BOOTH_A - 3, show: [WALL_LAST_HOLD, BOOTH_A + 4] },
  { id: 'booth', label: 'The Telephone Booth', start: BOOTH_A - 3, jump: BOOTH_A, end: TOTAL, show: [ROAD_T1 - 6, TOTAL] },
];
export const sceneById = Object.fromEntries(SCENES.map((s) => [s.id, s]));

/** Named moments other files hang their fades on. */
export const BEATS = {
  OAK_IN, OAK_OUT, TRAIN_IN, TRAIN_OUT, SKY_A, SKY_B, FLIGHT, WALL_IN, WALL_LAST_HOLD,
  ROAD_YAW, ROAD_T0, ROAD_T1, BOOTH_A, BOOTH_A2, BOOTH_B, BOOTH_C,
  planeFrom: SKY_A - 4.5,
  planeTo: SKY_A + 10.5,
};

/** The airplane's flight path (SkyScene places it, the audio engine derives distance / doppler / pan from it). */
// X0/X1 are far enough out that the plane AND its ~75-unit banner enter and leave completely off-screen.
export const PLANE_PATH = { X0: 150, X1: -150, Z0: -135, Z1: -66, Y0: 21, Y1: 25, SCALE: 3 };

/** Optional .glb files in /public/models. Missing files fall back to built-in primitives. */
export const MODELS = {
  entrance: '/models/entrance.glb', // must contain a node named "DoorLeaf" (pivot at the hinge)
  oak: '/models/oak.glb',
  loco: '/models/loco.glb', // length along +x, nose at x=0
  coach: '/models/coach.glb', // length along +x, centred on origin; wheel nodes named "Wheel*"
  plane: '/models/plane.glb',
  stoneWall: '/models/stone_wall.glb',
  booth: '/models/phone_booth.glb',
};

// ── World layout ─────────────────────────────────────────────────────────────
export const WORLD = {
  entrance: { doorW: 1.7, doorH: 2.9, wallW: 16, wallH: 6.6, wallT: 0.7 },
  oak: { pos: [-1.8, 0, -13] },
  stone: { pos: [0, 0, -110], w: 22, h: 16 },
};

export const TRAIN = {
  z: -38,
  x0: -5, // rest position: the loco's nameplate is dead-centre when we arrive
  locoLen: 10,
  coachLen: 9,
  gap: 0.5,
  count: SKILL_GROUPS.length,
};
TRAIN.length = TRAIN.locoLen + TRAIN.count * (TRAIN.coachLen + TRAIN.gap);
TRAIN.xEnd = -6.5 - TRAIN.length; // last coach has fully left the left edge of the frame
export const coachCenter = (k) => TRAIN.locoLen + TRAIN.gap + k * (TRAIN.coachLen + TRAIN.gap) + TRAIN.coachLen / 2;
/** trainX at which stop k is centred: 0 = loco nameplate, 1…7 = coach 1…7 */
export const trainStopX = (k) => (k === 0 ? TRAIN.x0 : -coachCenter(k - 1));

/** Lantern positions on the stone wall, wall-local (the wall group sits at WORLD.stone.pos). */
export const LANTERNS = [[-6.3, 9.5, 1.1], [6.3, 5.2, 1.1]];

// Stone wall project frames: [x, y] on the wall, alternating left / right.
export const WALL_FRAMES = [[-3.1, 12.4], [3.1, 10.2], [-3.1, 8.0], [3.1, 5.8], [-3.1, 3.6]];

/** The winding dirt road (scene 6). Starts at the foot of the stone wall, ends at the booth. */
const ROAD_RAW = [[0, 0], [-8, 3], [-18, 0], [-30, 6], [-37, 16], [-33, 27], [-38, 38], [-47, 44]];
export const ROAD = new THREE.CatmullRomCurve3(
  ROAD_RAW.map(([x, z]) => new THREE.Vector3(x * 1.55, 0, -104 + z * 1.55)),
  false,
  'centripetal'
);
export const MILESTONE_U = (i) => 0.2 + (0.7 * i) / (TIMELINE.length - 1);
export const ROAD_LEAD = 0.055; // the camera looks this far (in road-u) ahead of itself
export const roadStopU = (i) => MILESTONE_U(i) - ROAD_LEAD;

// Telephone booth stands just past the end of the road, front facing back down the road.
const endP = ROAD.getPointAt(1);
const endT = ROAD.getTangentAt(1);
export const BOOTH = {
  pos: new THREE.Vector3(endP.x + endT.x * 2.4, 0, endP.z + endT.z * 2.4),
  rotY: Math.atan2(-endT.x, -endT.z),
};
const boothM = new THREE.Matrix4().compose(
  BOOTH.pos,
  new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), BOOTH.rotY),
  new THREE.Vector3(1, 1, 1)
);
/** booth-local → world */
export const B = (x, y, z) => new THREE.Vector3(x, y, z).applyMatrix4(boothM).toArray();
// Low sunset sun: in front of the booth, a little to the side.
BOOTH.sunPos = B(7, 3.2, 9).map((v, i) => v - BOOTH.pos.toArray()[i]);

/** The note taped on the booth glass: small, so the camera has to travel right up to it. */
export const PAPER = { w: 0.44, h: 0.6, y: 1.95, z: 0.93 };

// ── Dwell tracks ─────────────────────────────────────────────────────────────
const DRIFT_TRAIN = 0.45; // world units the train creeps during a rest (so scrolling never feels dead)
export const TRAIN_KEYS = [{ t: 0, v: TRAIN.x0 + DRIFT_TRAIN, s: 0 }];
for (let k = 0; k <= 7; k++) {
  const x = trainStopX(k);
  TRAIN_KEYS.push({ t: trainStop(k) - TRAIN_HOLD, v: x + DRIFT_TRAIN, s: 0 });
  TRAIN_KEYS.push({ t: trainStop(k) + TRAIN_HOLD, v: x - DRIFT_TRAIN, s: 0 });
}
TRAIN_KEYS.push({ t: TRAIN_OUT, v: TRAIN.xEnd, s: 0 });

const DRIFT_ROAD = 0.004;
export const ROAD_U_KEYS = [{ t: ROAD_T0, v: roadStopU(0) - 0.085, s: 0 }];
for (let i = 0; i < TIMELINE.length; i++) {
  ROAD_U_KEYS.push({ t: roadStop(i) - ROAD_HOLD, v: roadStopU(i) - DRIFT_ROAD, s: 0 });
  ROAD_U_KEYS.push({ t: roadStop(i) + ROAD_HOLD, v: roadStopU(i) + DRIFT_ROAD, s: 0 });
}
ROAD_U_KEYS.push({ t: ROAD_T1, v: 0.94, s: 0 });
export const ROAD_U0 = ROAD_U_KEYS[0].v;
/** Milestone i is written while the camera arrives at it, and is complete well before it leaves. */
export const writeWindow = (i) => [roadStop(i) - 1.7, roadStop(i) + 0.5];

// ── Scalar tracks (door, light, palette …): [t, value, s?]. s defaults to 0 = ease to rest ──
export const SCALAR_KEYS = {
  door: [[0, 0], [0.8, 0], [2.6, 0.22], [3.0, 0.22], [5.4, 0.62], [5.8, 0.62], [8.8, 1]],
  glow: [[0, 0], [1.0, 0], [7.0, 1], [7.8, 1], [11.4, 0]],
  bloom: [[0, 0.5], [2.5, 0.5], [6.5, 0.85], [8, 0.85], [11.5, 0.5]],
  dof: [[0, 0], [7, 0], [11, 1], [29, 1], [36, 0]],
  atmo: [
    [0, 0], [4, 0], [12.5, 1], [TRAIN_LAST_HOLD + 1.4, 1], [SKY_A + 1, 2], [SKY_B, 2], [WALL_IN + 1, 3],
    [WALL_LAST_HOLD, 3], [ROAD_YAW + 6, 4], [ROAD_T1 - 18, 4], [ROAD_T1 - 4, 5], [TOTAL, 5],
  ],
  planeX: [[BEATS.planeFrom, PLANE_PATH.X0], [(BEATS.planeFrom + BEATS.planeTo) / 2, 0, 1], [BEATS.planeTo, PLANE_PATH.X1]],
};

// ── Camera ───────────────────────────────────────────────────────────────────
// Keys: t = time the camera is AT this pose.  s = tangent scale (0 = rest, 1 = flow).
// rig/path.js turns these into Hermite splines (position, look-at and fov are all
// velocity-continuous) and inserts dense keys along the road following ROAD_U_KEYS.
export const roadPose = (u) => {
  const p = ROAD.getPointAt(u);
  const tan = ROAD.getTangentAt(u);
  const a = ROAD.getPointAt(Math.min(u + ROAD_LEAD, 1));
  return { pos: [p.x - tan.x * 3, 9, p.z - tan.z * 3], look: [a.x, 0, a.z] };
};

const wallPose = (k, drift = 0) => {
  const [fx] = WALL_FRAMES[k];
  const x = fx * 0.12; // lean slightly toward the active card (any more clips its neighbour)
  const y = 11.8 - 2.2 * k - drift;
  return { pos: [x, y, -99.7], look: [x, y - 0.6, -110] };
};

const K = (t, pos, look, fov, s = 1) => ({ t, pos, look, fov, s });

/** everything before the road drone */
export const CAMERA_HEAD = [
  // 1 – the door
  K(0, [0, 1.7, 9.5], [0, 1.6, 0], 42, 0),
  K(7.5, [0, 1.65, 2.6], [0, 1.5, -5], 46, 1),
  // 2 – through the door, oak tree (a slow push-in while the plaque is read)
  K(OAK_IN, [0, 1.7, -3.5], [-1.2, 2.8, -13], 50, 0.35),
  K(OAK_OUT, [0, 1.7, -4.8], [-1.2, 2.8, -13.5], 50, 0.2),
  K(RAILS, [6.5, 1.8, -19], [7, 1.6, -34], 46, 1), // slide past the oak, eyes on the rails
  // 3 – parked beside the train. The camera barely moves; the train glides past.
  K(TRAIN_IN, [0, 2.3, -28.2], [0, 2.2, -38], 46, 0),
  K(TRAIN_LAST_HOLD, [0.4, 2.3, -28.2], [0.4, 2.2, -38], 46, 0),
  // 4 – lift off: horizon in the lower third, plane crosses, then a crane over the hills to the wall
  K(SKY_A, [0, 3.4, -30], [0, 13, -90], 54, 0.3),
  K(SKY_B, [0, 5.5, -31], [0, 14.5, -92], 54, 0.3),
  K(FLIGHT, [0, 14, -70], [0, 12.2, -102], 48, 1),
  // 5 – stone wall: come to rest at every frame
  K(WALL_IN, wallPose(0).pos, wallPose(0).look, 42, 0),
  ...WALL_FRAMES.flatMap((_, k) => [
    K(wallStop(k) - WALL_HOLD, wallPose(k).pos, wallPose(k).look, 42, 0),
    K(wallStop(k) + WALL_HOLD, wallPose(k, 0.35).pos, wallPose(k, 0.35).look, 42, 0),
  ]),
  // 6 – drop low, yaw left to find the path …
  K(ROAD_YAW, [-1.5, 2.0, -98.5], [-14, 0.3, -100], 46, 0.4),
];

/** the booth: A) full frame, rest on the signpost  B) dolly in  C) very close on the note */
export const CAMERA_TAIL = [
  K(BOOTH_A, B(1.0, 1.7, 8.2), B(0.5, 1.6, 0), 40, 0.3),
  K(BOOTH_A2, B(1.05, 1.72, 8.0), B(0.5, 1.62, 0), 40, 0),
  K(BOOTH_B, B(0.15, 1.78, 4.6), B(0, 1.9, 0.9), 36, 0.6),
  K(BOOTH_C, B(0, PAPER.y, PAPER.z + 1.27), B(0, PAPER.y, PAPER.z), 32, 0),
];
