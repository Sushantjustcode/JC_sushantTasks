import { PROFILE } from '../config/cv';

/**
 * Full-screen entry gate. It does two jobs:
 *  1. Covers the one-time shader compile / texture upload (the 3D world is pre-warmed behind it),
 *     so nothing hitches in the middle of scrolling.
 *  2. Provides the user gesture browsers require before audio may play.
 */
export default function EntryGate({ ready, leaving, onEnter }) {
  return (
    <div
      role="dialog"
      aria-label="Enter the portfolio"
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center gap-7 bg-[#0c1018] px-6 text-center transition-opacity duration-700 ${leaving ? 'pointer-events-none opacity-0' : 'opacity-100'}`}
    >
      <div>
        <h1 className="font-[Fraunces] text-[clamp(2rem,6vw,3.8rem)] font-bold leading-none tracking-tight text-[#fff4dc]">{PROFILE.name}</h1>
        <p className="mt-3 text-[clamp(0.9rem,1.8vw,1.15rem)] text-[#ffe9c4]/85">{PROFILE.role}</p>
      </div>
      {ready ? (
        <div className="flex flex-col items-center gap-3 sm:flex-row">
          <button
            type="button"
            autoFocus
            onClick={() => onEnter(true)}
            className="cursor-pointer rounded-full bg-[#ffd48a] px-7 py-3 text-base font-bold text-[#2a1e12] shadow-[0_0_40px_rgba(255,212,138,0.35)] transition hover:scale-105 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-white"
          >
            Enter with sound
          </button>
          <button
            type="button"
            onClick={() => onEnter(false)}
            className="cursor-pointer rounded-full border border-white/30 px-6 py-3 text-base font-medium text-white/85 transition hover:bg-white/10 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-white"
          >
            Enter silently
          </button>
        </div>
      ) : (
        <div className="flex flex-col items-center gap-3" role="status">
          <div className="h-[3px] w-48 overflow-hidden rounded bg-white/15">
            <div className="gate-bar h-full w-1/3 rounded bg-[#ffd48a]" />
          </div>
          <p className="text-sm text-white/65">Building the world…</p>
        </div>
      )}
      <p className="max-w-sm text-xs text-white/45">A scroll-driven 3D story. Scroll slowly; it is built to be read. Headphones recommended.</p>
    </div>
  );
}
