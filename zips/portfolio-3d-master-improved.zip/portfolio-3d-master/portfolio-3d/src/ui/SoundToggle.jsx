/** Always-visible mute button (bottom-left). */
export default function SoundToggle({ on, onToggle }) {
  return (
    <button
      type="button"
      onClick={onToggle}
      aria-pressed={on}
      aria-label={on ? 'Mute ambient sound' : 'Turn on ambient sound'}
      className="fixed bottom-4 left-4 z-30 flex h-10 cursor-pointer items-center gap-2 rounded-full border border-white/25 bg-black/45 px-3.5 text-sm font-medium text-white/90 backdrop-blur-md transition hover:bg-black/60 focus-visible:outline-2 focus-visible:outline-[#ffd48a]"
    >
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
        <path d="M11 5 6 9H3v6h3l5 4V5z" fill="currentColor" />
        {on ? (
          <>
            <path d="M15.5 8.5a5 5 0 0 1 0 7" />
            <path d="M18.5 5.5a9 9 0 0 1 0 13" />
          </>
        ) : (
          <>
            <path d="m16 9 5 6" />
            <path d="m21 9-5 6" />
          </>
        )}
      </svg>
      <span>{on ? 'Sound on' : 'Sound off'}</span>
    </button>
  );
}
