import { useEffect, useRef, useState } from 'react';
import { subscribe, jumpToTime } from '../rig/engine';
import { SCENES, TOTAL } from '../config/storyboard';

/**
 * Right-edge chapter marker. The line fills with story time; each dot is a button that glides
 * (smoothly, never a jump-cut) to that chapter – handy now that the story is longer.
 * Re-renders only when the scene changes.
 */
export default function ProgressHUD() {
  const [idx, setIdx] = useState(0);
  const [showLabel, setShowLabel] = useState(true);
  const hover = useRef(false);
  const bar = useRef();
  // The chapter name flashes up when the chapter changes, then gets out of the way of the content.
  useEffect(() => {
    setShowLabel(true);
    const id = setTimeout(() => !hover.current && setShowLabel(false), 2600);
    return () => clearTimeout(id);
  }, [idx]);
  useEffect(() => {
    let cur = 0;
    return subscribe((rig) => {
      let next = SCENES.findIndex((s) => rig.time < s.end);
      if (next === -1) next = SCENES.length - 1;
      if (next !== cur) {
        cur = next;
        setIdx(next);
      }
      if (bar.current) bar.current.style.transform = `scaleY(${(rig.time / TOTAL).toFixed(4)})`;
    });
  }, []);
  return (
    <aside
      className="fixed right-4 top-1/2 z-20 hidden -translate-y-1/2 items-center gap-3 md:flex"
      aria-label="Chapters"
      onMouseEnter={() => {
        hover.current = true;
        setShowLabel(true);
      }}
      onMouseLeave={() => {
        hover.current = false;
        setShowLabel(false);
      }}
    >
      <p className={`pointer-events-none w-44 text-right text-sm font-medium text-white/90 transition-opacity duration-500 [text-shadow:0_1px_8px_rgba(0,0,0,0.7)] ${showLabel ? 'opacity-100' : 'opacity-0'}`}>{SCENES[idx].label}</p>
      <div className="relative h-52 w-4">
        <div className="absolute inset-y-0 left-1/2 w-[3px] -translate-x-1/2 rounded bg-white/25">
          <div ref={bar} className="absolute inset-0 origin-top rounded bg-[#ffd48a]" style={{ transform: 'scaleY(0)' }} />
        </div>
        {SCENES.map((s, i) => (
          <button
            key={s.id}
            type="button"
            title={s.label}
            aria-label={`Go to ${s.label}`}
            aria-current={i === idx ? 'true' : undefined}
            onClick={() => jumpToTime(s.jump)}
            className={`absolute left-1/2 h-2.5 w-2.5 -translate-x-1/2 -translate-y-1/2 cursor-pointer rounded-full border border-white/70 transition-transform hover:scale-150 focus-visible:scale-150 focus-visible:outline-2 focus-visible:outline-[#ffd48a] ${i <= idx ? 'bg-[#ffd48a]' : 'bg-black/40'}`}
            style={{ top: `${(s.start / TOTAL) * 100}%` }}
          />
        ))}
      </div>
    </aside>
  );
}
