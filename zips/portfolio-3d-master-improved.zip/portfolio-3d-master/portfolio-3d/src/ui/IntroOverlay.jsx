import { useEffect, useRef } from 'react';
import { PROFILE } from '../config/cv';
import { subscribe } from '../rig/engine';
import { smooth } from '../shared/utils';

/** Scene 1 hero. A plain DOM overlay, faded by the same story clock that opens the door. */
export default function IntroOverlay() {
  const ref = useRef();
  useEffect(
    () =>
      subscribe((rig) => {
        const el = ref.current;
        if (!el) return;
        const o = 1 - smooth((rig.time - 0.4) / 2.8);
        el.style.opacity = o.toFixed(3);
        el.style.transform = `translateY(${((1 - o) * -8).toFixed(2)}%)`;
        el.style.visibility = o < 0.01 ? 'hidden' : 'visible';
      }),
    []
  );
  return (
    <div ref={ref} className="pointer-events-none fixed inset-0 z-10 flex flex-col items-center justify-between px-6 pb-10 pt-[9vh] text-center">
      <div className="absolute inset-x-0 top-0 h-[55vh] bg-gradient-to-b from-black/55 via-black/25 to-transparent" aria-hidden />
      <header className="relative max-w-3xl">
        <h1 className="font-[Fraunces] text-[clamp(2.6rem,8vw,5.8rem)] font-bold leading-[0.95] tracking-tight text-[#fff4dc] [text-shadow:0_3px_24px_rgba(0,0,0,0.55)]">
          {PROFILE.name}
        </h1>
        <p className="mt-4 text-[clamp(0.95rem,2.1vw,1.3rem)] font-medium text-[#ffe9c4] [text-shadow:0_2px_12px_rgba(0,0,0,0.6)]">{PROFILE.role}</p>
        <p className="mx-auto mt-3 max-w-xl text-[clamp(0.9rem,1.8vw,1.1rem)] text-white/90 [text-shadow:0_2px_12px_rgba(0,0,0,0.6)]">{PROFILE.hook}</p>
      </header>
      <div className="relative flex flex-col items-center gap-2 text-sm text-[#fff4dc] [text-shadow:0_2px_10px_rgba(0,0,0,0.7)]">
        <span>Scroll slowly to open the door</span>
        <span className="h-10 w-px animate-pulse bg-[#fff4dc]/80" aria-hidden />
      </div>
    </div>
  );
}
