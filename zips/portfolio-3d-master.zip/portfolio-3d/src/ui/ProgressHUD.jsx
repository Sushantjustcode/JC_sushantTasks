import { useEffect, useRef, useState } from 'react';
import gsap from 'gsap';
import { rig } from '../rig/rig';
import { SCENES, TOTAL } from '../config/storyboard';

/** Right-edge scene marker + progress line. Reads rig.time on the GSAP ticker; re-renders only when the scene changes. */
export default function ProgressHUD() {
  const [idx, setIdx] = useState(0);
  const bar = useRef();
  useEffect(() => {
    let cur = 0;
    const tick = () => {
      const i = Math.max(0, SCENES.findIndex((s) => rig.time < s.end));
      const next = rig.time >= TOTAL - 0.01 ? SCENES.length - 1 : i === -1 ? SCENES.length - 1 : i;
      if (next !== cur) {
        cur = next;
        setIdx(next);
      }
      if (bar.current) bar.current.style.transform = `scaleY(${(rig.time / TOTAL).toFixed(4)})`;
    };
    gsap.ticker.add(tick);
    return () => gsap.ticker.remove(tick);
  }, []);
  return (
    <aside className="pointer-events-none fixed right-4 top-1/2 z-20 hidden -translate-y-1/2 items-center gap-3 md:flex" aria-label="Scene progress">
      <p className="w-44 text-right text-sm font-medium text-white/90 [text-shadow:0_1px_8px_rgba(0,0,0,0.7)]">{SCENES[idx].label}</p>
      <div className="relative h-48 w-[3px] rounded bg-white/25">
        <div ref={bar} className="absolute inset-0 origin-top rounded bg-[#ffd48a]" style={{ transform: 'scaleY(0)' }} />
      </div>
    </aside>
  );
}
