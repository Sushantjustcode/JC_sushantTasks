// ─────────────────────────────────────────────────────────────────────────────
// Single source of truth for every word shown in the site. All of it comes from
// the CV. The only invented strings are marked  // TODO  (URLs the CV hides
// behind link labels) and `hook` (one line of copy for the intro).
// ─────────────────────────────────────────────────────────────────────────────

export const PROFILE = {
  name: 'Sushant Chauhan',
  role: 'Full-Stack MERN Developer • Game & 3D Environment Designer',
  hook: 'I build full-stack web apps, and the game worlds you can walk through.',
  location: 'Karnal, Haryana, India',
  phone: '+91-7015132358',
  email: 'your.email@gmail.com', // TODO: CV only shows the label "Gmail"
  linkedin: 'https://www.linkedin.com/in/your-handle', // TODO: CV only shows the label "linkedin"
  portfolio: 'https://your-portfolio.example', // TODO: CV only shows the label "Portfolio"
  chips: ['Full-Stack (MERN)', 'Game & 3D Design', 'Self-Driven Learner', 'BCA – AI'],
};

/** Scene 2 – text carved into the oak (from CV "Profile"). */
export const BIO = [
  'Full-Stack MERN Developer building web applications with React.js, Node.js, Express.js and MongoDB.',
  'Completed an intensive backend-focused MERN internship and an industrial training program, and ships end-to-end personal projects on an ongoing basis.',
  'Hands-on in game development, level design and 3D modeling, bringing problem solving, visual hierarchy, performance awareness and attention to detail to every build.',
];

/** Scene 2 – notes carried by the falling leaves (CV: Education, Achievements, Core Strengths). */
export const LEAF_NOTES = [
  { title: 'Education', text: 'BCA – Artificial Intelligence, Kurukshetra University (2024 – 2027)' },
  { title: 'Based in', text: 'Karnal, Haryana, India' },
  { title: 'Hackathons', text: 'Runner-Up at HackWars (NIT Karnataka) and CodeMaster (CQST College)' },
  { title: 'Game dev', text: 'WhiteHat Jr Game Developer Achievement, 2020' },
  { title: 'Sports', text: 'Football and Basketball medallist, interschool competitions' },
  {
    title: 'Core strengths',
    text: 'Problem Solving, Debugging & Troubleshooting, Systematic Thinking, Creativity & Design Thinking, Adaptability, Communication, Confidence, Leadership',
  },
];

/** Scene 3 – one coach per CV "Technical Skills" row (+ a guard van for "Also familiar with"). */
export const SKILL_GROUPS = [
  { coach: 'Coach 1', title: 'Programming', skills: ['C', 'C++', 'C#', 'Python', 'OOP', 'DSA'] },
  { coach: 'Coach 2', title: 'Frontend', skills: ['React.js', 'JavaScript', 'HTML5', 'CSS3', 'Tailwind CSS', 'Bootstrap'] },
  { coach: 'Coach 3', title: 'Backend', skills: ['Node.js', 'Express.js', 'REST APIs', 'CRUD', 'MERN'] },
  { coach: 'Coach 4', title: 'Databases', skills: ['MongoDB', 'SQL'] },
  {
    coach: 'Coach 5',
    title: 'Game & 3D',
    skills: ['Blender', 'Unity', 'Unreal Engine', 'Level Design', '3D Modeling', 'Environment Art', 'Lighting', 'Texturing'],
  },
  { coach: 'Coach 6', title: 'Tools & Productivity', skills: ['Git', 'GitHub', 'MS Excel', 'MS PowerPoint', 'MS Word'] },
  { coach: 'Guard van', title: 'Also familiar with', skills: ['YouTube Creator Studio', 'Video Editing'] },
];

/** Scene 5 – "Selected Projects" from the CV, bullets verbatim. */
export const PROJECTS = [
  {
    kind: 'Web',
    title: 'Student Management System',
    stack: ['MERN Stack', 'MongoDB', 'Express.js', 'React.js', 'Node.js'],
    bullets: [
      'Built as the internship project at CodeQuotient School of Technology, Panipat.',
      'Implemented CRUD operations, database integration and structured student-record workflows.',
      'Designed a responsive interface for managing and searching student information.',
    ],
  },
  {
    kind: 'Web',
    title: 'Library Management System',
    stack: ['Web Development', 'Database'],
    bullets: [
      'Developed a management application for organizing books and library records.',
      'Focused on clear data handling, practical workflows and an easy-to-use interface.',
    ],
  },
  {
    kind: 'Web',
    title: 'Personal Portfolio Websites',
    stack: ['React.js', 'JavaScript', 'Tailwind CSS'],
    bullets: [
      'Designed responsive portfolio websites to present development and creative work.',
      'Focused on clean navigation, visual hierarchy, responsive layouts and professional presentation.',
    ],
  },
  {
    kind: 'Game',
    title: 'Horror Game: Forest Level Design',
    stack: ['Unreal Engine', 'Unity', 'Blender'],
    bullets: [
      'Designed a horror-themed forest level using environmental composition, pacing, sightlines and lighting.',
      'Created exploration spaces, set-pieces and atmosphere-focused environments to support gameplay flow.',
      'Applied level design thinking to guide player attention and communicate mood through the environment.',
    ],
  },
  {
    kind: '3D',
    title: '3D Modeling: Game Assets',
    stack: ['Blender', 'Unity', 'Unreal Engine'],
    bullets: [
      'Modeled game assets and environment elements for use in 3D scenes.',
      'Worked with materials, textures, lighting and game-ready asset preparation.',
      'Balanced visual detail with practical real-time requirements when preparing assets for game environments.',
    ],
  },
];

/**
 * Scene 6 – engraved in the sand, in order of appearance.
 * Hackathon dates are not in the CV, so they sit under "Hackathons" instead of a year.
 */
export const TIMELINE = [
  { when: '2020', title: 'WhiteHat Jr', place: 'Game Developer Achievement' },
  { when: '2022 to 2024', title: 'Class 10 and Class 12', place: 'War Heroes Memorial School, Basdhara, Karnal', note: 'Non-Medical Science' },
  { when: 'Jul 2024', title: 'BCA – Artificial Intelligence', place: 'Kurukshetra University', note: 'July 2024 – July 2027' },
  { when: 'Jul – Aug 2025', title: 'Industrial Trainee', place: 'CodeQuotient School of Technology', note: 'Project-driven software development training' },
  { when: 'Jul – Aug 2026', title: 'Web Development Intern', place: 'CodeQuotient School of Technology, Panipat', note: 'Backend & MERN training' },
  { when: 'Ongoing', title: 'Self-Driven Developer', place: 'Independent projects & continuous learning' },
  { when: 'Hackathons', title: 'HackWars Runner-Up', place: 'NIT Karnataka', note: 'CodeMaster Runner-Up (Semifinalist), CQST College' },
  { when: 'Jul 2027', title: 'BCA completes', place: 'Kurukshetra University', note: 'Expected' },
];
