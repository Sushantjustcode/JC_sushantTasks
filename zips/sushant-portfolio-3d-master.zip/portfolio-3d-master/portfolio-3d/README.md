# Sushant Chauhan: 3D scrollytelling portfolio

React + Vite, React Three Fiber, drei, GSAP ScrollTrigger, Lenis, Tailwind v4, postprocessing.
One continuous camera flight through seven scenes. Scrolling is the only input.

```bash
npm install
npm run dev        # http://localhost:5173
npm run build
```

## 1. Directory structure

```
portfolio-3d/
├─ index.html                      fonts (Fraunces, Hanken Grotesk, Caveat)
├─ public/models/                  optional .glb files (see README inside)
└─ src/
   ├─ main.jsx  App.jsx  index.css
   ├─ config/
   │  ├─ cv.js                     ALL copy: bio, skills→coaches, projects, timeline (from the CV)
   │  └─ storyboard.js             scene time ranges, world layout, road spline, CAMERA WAYPOINTS
   ├─ rig/                         the scroll → camera engine
   │  ├─ rig.js                    shared mutable state (door, trainX, planeX, pathT, atmo…)
   │  ├─ buildMasterTimeline.js    THE GSAP timeline (pure; testable in Node)
   │  ├─ useScrollRig.js           Lenis + ScrollTrigger scrub → timeline
   │  ├─ path.js                   pathT → camera position / look-at / fov (CatmullRom splines)
   │  ├─ CameraRig.jsx             per-frame damped follow, hand-held drift, pointer parallax
   │  ├─ Atmosphere.jsx            sky colour, fog, sun, fill light follow rig.atmo
   │  ├─ Effects.jsx               DepthOfField, Bloom, ToneMapping, Vignette
   │  ├─ SceneGroup.jsx            renders a scene only inside its time window
   │  └─ hooks.js                  useFade (DOM overlays), useFlicker (lights)
   ├─ scenes/
   │  ├─ EntranceScene.jsx         1  brick wall, vines, door, light shafts      (full code)
   │  ├─ MeadowScene.jsx           2-4 ground, wind grass, hills
   │  ├─ OakScene.jsx              2  oak, bark plaque, falling leaves
   │  ├─ TrainScene.jsx            3  skill scrubber                              (full code)
   │  ├─ SkyScene.jsx              4  clouds, plane, rippling PROJECTS banner
   │  ├─ StoneWallScene.jsx        5  framed project cards
   │  ├─ DirtRoadScene.jsx         6  sand ribbon, stick-engraved timeline
   │  └─ PhoneBoothScene.jsx       7  booth, signpost, paper + contact form
   ├─ shared/                      textures.js, Grass.jsx, Clouds.jsx, OptionalGLTF.jsx, utils.js
   └─ ui/                          IntroOverlay, ProgressHUD, ContactForm
```

## 2. How the pieces connect

```
scroll ─Lenis→ ScrollTrigger(scrub) ─→ master GSAP timeline ─→ rig (plain object)
                                                                 │ read in useFrame, never React state
              CameraRig · scenes · Atmosphere · Effects · DOM fades ◄┘
```

* `#scroll-spacer` is `TOTAL × SCROLL_VH_PER_UNIT` vh tall (124 × 10 = 1240vh). That height is the story length.
* The timeline is exactly `TOTAL` units, so `scroll% × 124` = timeline time.
* Scenes never listen to scroll. They read `rig.*` (and `rig.time`) inside `useFrame`.

## 3. Camera logic (exact)

`storyboard.js` lists `WAYPOINTS` (`t`, `pos`, `look`, `fov`, `ease`). `path.js` builds two
CatmullRom curves from them (positions and look-at targets). `buildMasterTimeline.js` walks one
scalar, `rig.pathT`, from waypoint to waypoint:

```js
const last = WAYPOINTS.length - 1;
WAYPOINTS.forEach((wp, i) => {
  if (i === 0) return;
  const prev = WAYPOINTS[i - 1];
  tl.to(rig, { pathT: i / last, duration: wp.t - prev.t, ease: wp.ease ?? 'power1.inOut' }, prev.t);
});
```

Both curves share `pathT`, so position and look-at never drift apart. `ease: 'none'` through the train
scrub, the wall descent and the road keeps speed constant (no stop at every waypoint). `CameraRig`
then eases the real camera toward the sampled target with `1 - exp(-5·dt)` (the lerp), adds a faint
drift and mouse parallax, and zeroes both when the contact form locks the camera.

| Scene | Timeline | What moves |
|---|---|---|
| 1 Entrance | 0 – 10 | camera pushes in; door opens in 3 stages; glow floods then fades as you step through |
| 2 Oak | 10 – 26 | camera holds on the oak; DOF blur drops 20→26 as it slides past |
| 3 Train | 26 – 53 | camera parked; `rig.trainX` scrubs 29.5→51.5; coaches light as they pass centre |
| 4 Sky | 53 – 67 | whip up, plane + banner cross 55.5→62.5, pan down to the wall |
| 5 Wall | 67 – 82 | camera descends the wall past 5 frames |
| 6 Road | 82 – 104 | yaw left, drone along the road; `rig.roadU` drives the sand writing |
| 7 Booth | 104 – 124 | A) full frame (108)  B) dolly in (115)  C) lock (118); form fades in 115.5→118 |

Change any number in `storyboard.js` and everything re-times. The timeline is pure, so you can test it
without a browser: `const tl = buildMasterTimeline(rig); tl.time(42); console.log(rig.trainX)`.

## 4. The two complex scenes

* `scenes/EntranceScene.jsx`: door leaf is a group whose origin is the hinge; `rig.door` sets
  `rotation.y`. A drei `<Html transform>` sign is a child of that group, so DOM swings with the door.
  Light = HDR-coloured additive portal plane + 3 additive cones with a gradient `alphaMap` + `Sparkles`
  + flickering point light, all driven by `rig.glow` / `rig.door`; Bloom turns the HDR values into glow.
* `scenes/TrainScene.jsx`: one group moved by `rig.trainX`; wheels roll by distance travelled. Each coach
  measures its distance from screen centre → `lit` (0…1), which drives (a) emissive window planes behind
  the DOM and (b) the CSS variable `--lit` on the DOM panel, so skills switch on in the windows.

## 5. Gotchas worth knowing

* **drei `<Html transform>` sizing:** 1 DOM px = `distanceFactor / 400` world units. Use
  `dfFor(pxPerUnit)` from `shared/utils.js`. On-screen text scale ≈ `(screenH / visibleWorldH) / pxPerUnit`.
  Each panel's `PX` constant is the one knob to turn if text looks too big/small on your screen.
* CSS3D panels sit on top of the canvas (no occlusion), so every panel fades by timeline time (`useFade`).
* Textures are generated on canvas (brick, stone, sand, paper, banner), so there are no image files to load.
  Fonts load from Google Fonts; canvas text redraws when they arrive.
* The fixed canvas has `pointer-events` on, but wheel/touch still scroll the page because those events bubble.
* Performance: scenes outside their `show` window are not rendered. If a low-end device struggles, lower
  `dpr` in `App.jsx`, drop `multisampling` in `Effects.jsx`, or remove `DepthOfField`.

## 6. Content map (CV → site)

All text lives in `config/cv.js`. Everything is from the CV except: the one-line `hook`, and three links
the CV only shows as labels (`email`, `linkedin`, `portfolio`, marked `TODO`). Hackathon dates are not in
the CV, so they appear as "Hackathons" rather than a year.

The storyboard mentioned "Jal-Dhara" and "VOD web platforms". Neither is in the CV, so the wall shows the five
projects that are: Student Management System, Library Management System, Personal Portfolio Websites,
Horror Game: Forest Level Design, 3D Modeling: Game Assets. Add them to `PROJECTS` if you want them
(add a frame position in `StoneWallScene.jsx` and extend the wall waypoints).

## 7. Contact form

`ContactForm.jsx` POSTs `{ name, email, message }` JSON to `VITE_CONTACT_ENDPOINT` (default `/api/contact`).
Point it at Formspree, a Resend/Nodemailer serverless function, or your Express route.

## 8. Changelog
* Fixed black screen: `rig/Atmosphere.jsx` called `.toArray()` on `BOOTH.sunPos`, which is already an array, so the app threw on first render. Now passes `BOOTH.sunPos` directly.
