# Optional .glb models

Every file here is optional. If a file is missing, the scene draws its built-in primitive version.
Drop a file in with the exact name below and it swaps in automatically (no code change).
Export from Blender with +Y up, apply transforms, Draco-compress if you like.

| File | Contract |
|---|---|
| `entrance.glb` | Brick wall (16 wide x 6.6 high, centred on x=0, front face at z=+0.35) with a 1.7 x 2.9 door opening. A node named **`DoorLeaf`** whose origin is the hinge edge (it is rotated on Y). |
| `oak.glb` | Origin at the base of the trunk. Leave a flat face about 2.8 x 3.4 on the +Z side of the trunk at y=2.6, z~1.65: the bio text is anchored there. |
| `loco.glb` | ~10 long along +X, nose at x=0, origin on the rail. Name wheel nodes `Wheel*` (they roll with scroll). |
| `coach.glb` | ~9 long along +X, centred on the origin, origin on the rail. Wheels named `Wheel*`. Leave a window band at y~1.5-3.0 on the +Z side; emissive planes and the skill panel sit there. One model is reused for all coaches. |
| `plane.glb` | Nose toward -X, ~4 long. The banner is added in code. |
| `stone_wall.glb` | ~22 wide x 16 high, base at y=0, front face at z=+0.5. |
| `phone_booth.glb` | ~1.8 x 1.8 x 3.2, front facing +Z. The paper and form are added in code at (0, 1.85, 0.93). |

`useGLTF` pulls Draco decoders from Google's CDN by default. To self-host, copy them to `public/draco/`
and call `useGLTF.setDecoderPath('/draco/')` once in `main.jsx`.
