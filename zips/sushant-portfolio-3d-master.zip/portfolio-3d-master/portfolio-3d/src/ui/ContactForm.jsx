import { useState } from 'react';

/**
 * The contact form shown on the paper. POSTs JSON { name, email, message } to
 * VITE_CONTACT_ENDPOINT (or /api/contact). Hook it to Resend / Nodemailer / Formspree etc.
 */
const ENDPOINT = import.meta.env.VITE_CONTACT_ENDPOINT || '/api/contact';

export default function ContactForm() {
  const [status, setStatus] = useState('idle'); // idle | sending | sent | error

  async function onSubmit(e) {
    e.preventDefault();
    const form = e.currentTarget;
    const data = Object.fromEntries(new FormData(form));
    setStatus('sending');
    try {
      const res = await fetch(ENDPOINT, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
      if (!res.ok) throw new Error(res.statusText);
      form.reset();
      setStatus('sent');
    } catch {
      setStatus('error');
    }
  }

  return (
    <form className="paper-form" onSubmit={onSubmit} data-lenis-prevent>
      <h3>Leave me a note</h3>
      <label>
        Name
        <input name="name" required autoComplete="name" />
      </label>
      <label>
        Email
        <input name="email" type="email" required autoComplete="email" />
      </label>
      <label>
        Message
        <textarea name="message" rows={4} required />
      </label>
      <button type="submit" disabled={status === 'sending'}>
        {status === 'sending' ? 'Sending' : 'Send message'}
      </button>
      <p role="status" className={`form-status ${status}`}>
        {status === 'sent' && 'Message sent. I will reply soon.'}
        {status === 'error' && 'Could not send. Check the connection and try again.'}
      </p>
    </form>
  );
}
