import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { EffectComposer, DepthOfField, Bloom, Vignette, ToneMapping } from '@react-three/postprocessing';
import { ToneMappingMode } from 'postprocessing';
import { rig } from './rig';

/** Bloom (door light, lit train windows, sunset) + depth-of-field (scene 2 background) + vignette. */
export default function Effects() {
  const dof = useRef();
  const bloom = useRef();
  useFrame(() => {
    if (dof.current) dof.current.bokehScale = rig.dof * 6;
    if (bloom.current) bloom.current.intensity = rig.bloom;
  });
  return (
    <EffectComposer multisampling={4}>
      <DepthOfField ref={dof} worldFocusDistance={11} worldFocusRange={9} bokehScale={0} height={480} />
      <Bloom ref={bloom} intensity={0.55} luminanceThreshold={1.15} luminanceSmoothing={0.25} mipmapBlur />
      <ToneMapping mode={ToneMappingMode.ACES_FILMIC} />
      <Vignette offset={0.25} darkness={0.5} />
    </EffectComposer>
  );
}
