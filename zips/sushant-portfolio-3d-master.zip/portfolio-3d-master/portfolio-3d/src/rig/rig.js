import { TRAIN, ROAD_TIMES } from '../config/storyboard';

/**
 * The shared, MUTABLE scene state.
 *   GSAP (driven by scroll) writes it → components read it inside useFrame.
 * It is deliberately NOT React state: it changes 60×/s and must never trigger re-renders.
 */
const initial = () => ({
  time: 0, // master-timeline time in scroll units (0 … TOTAL)
  pathT: 0, // 0…1 position along the camera spline
  door: 0, // 0 closed … 1 fully open
  glow: 0, // light pouring out of the doorway
  bloom: 0.55, // post-processing bloom intensity
  dof: 0, // depth-of-field strength (scene 2 background blur)
  atmo: 0, // palette index (0 entrance … 5 sunset), fractional = blend
  trainX: TRAIN.x0, // world x of the loco's nose
  planeX: 27, // world x of the airplane
  roadU: ROAD_TIMES.u0, // camera progress along the dirt road (drives the sand engraving)
});

export const rig = initial();
export const resetRig = () => Object.assign(rig, initial());
