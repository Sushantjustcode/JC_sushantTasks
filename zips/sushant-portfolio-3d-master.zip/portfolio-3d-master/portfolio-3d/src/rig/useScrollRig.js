import { useLayoutEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Lenis from 'lenis';
import { rig, resetRig } from './rig';
import { buildMasterTimeline } from './buildMasterTimeline';

/**
 * Lenis (inertial scroll) + GSAP ScrollTrigger (scrub) + the master timeline.
 *   Lenis smooths the native scroll position → ScrollTrigger.update runs on every
 *   Lenis tick → `scrub: true` maps scroll progress 1:1 onto the timeline
 *   (smoothing already comes from Lenis; the camera adds a final damp, see CameraRig).
 */
export function useScrollRig(dom) {
  useLayoutEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    if ('scrollRestoration' in history) history.scrollRestoration = 'manual';
    window.scrollTo(0, 0);
    resetRig();

    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const lenis = new Lenis({ duration: reduced ? 0.01 : 1.25, smoothWheel: !reduced });
    lenis.on('scroll', ScrollTrigger.update);
    const raf = (time) => lenis.raf(time * 1000); // gsap.ticker time is in seconds
    gsap.ticker.add(raf);
    gsap.ticker.lagSmoothing(0);

    const tl = buildMasterTimeline(rig, dom);
    const st = ScrollTrigger.create({
      trigger: '#scroll-spacer',
      start: 'top top',
      end: 'bottom bottom',
      scrub: true,
      animation: tl,
    });

    return () => {
      st.kill();
      tl.kill();
      gsap.ticker.remove(raf);
      lenis.destroy();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
}
