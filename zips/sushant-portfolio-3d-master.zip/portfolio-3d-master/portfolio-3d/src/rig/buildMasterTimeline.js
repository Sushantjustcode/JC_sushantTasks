import gsap from 'gsap';
import { WAYPOINTS, TOTAL, TRAIN, ROAD_TIMES } from '../config/storyboard';

/**
 * THE MASTER TIMELINE.
 * A paused GSAP timeline, TOTAL units long, that writes into the shared `rig` object.
 * ScrollTrigger scrubs it (see useScrollRig), so   scroll % → timeline time → rig values
 * → CameraRig / scenes read the rig in useFrame.
 *
 * Pure (no DOM, no React) so it can be unit-tested in Node:
 *   const tl = buildMasterTimeline(rig); tl.time(42); console.log(rig.trainX)
 */
export function buildMasterTimeline(rig, dom = {}) {
  const tl = gsap.timeline({
    paused: true,
    defaults: { ease: 'none' },
    onUpdate: () => {
      rig.time = tl.time();
    },
  });

  // ── 1. CAMERA: one scalar (pathT) walks the camera + look-at splines ───────
  // Waypoint i lives at pathT = i / last. Each segment is its own tween so every
  // move gets its own duration and ease; 'none' keeps velocity constant through
  // cruising shots (train scrub, drone path) so they never "stop" at a waypoint.
  const last = WAYPOINTS.length - 1;
  WAYPOINTS.forEach((wp, i) => {
    if (i === 0) return;
    const prev = WAYPOINTS[i - 1];
    tl.to(rig, { pathT: i / last, duration: wp.t - prev.t, ease: wp.ease ?? 'power1.inOut' }, prev.t);
  });

  // ── 2. SCENE 1: intro overlay out, door creaks open in three stages ────────
  if (dom.intro) tl.to(dom.intro, { autoAlpha: 0, yPercent: -8, duration: 2.2, ease: 'power2.out' }, 0.25);
  tl.to(rig, { door: 0.22, duration: 1.0, ease: 'power2.out' }, 0.5) // first creak
    .to(rig, { door: 0.62, duration: 1.6, ease: 'power1.inOut' }, 1.8) // wider
    .to(rig, { door: 1, duration: 1.6, ease: 'sine.out' }, 3.8) // all the way
    .to(rig, { glow: 1, duration: 3.2, ease: 'power2.in' }, 0.6) // light floods out
    .to(rig, { glow: 0, duration: 1.6, ease: 'power2.inOut' }, 6.4) // …then we step through it
    .to(rig, { bloom: 1.5, duration: 3.5, ease: 'sine.inOut' }, 2.5)
    .to(rig, { bloom: 0.55, duration: 3, ease: 'sine.inOut' }, 7.5);

  // ── 3. SCENE 2: background blur on the way in, "rack focus" once we pass the oak
  tl.to(rig, { dof: 1, duration: 3, ease: 'sine.inOut' }, 7)
    .to(rig, { dof: 0, duration: 6, ease: 'sine.inOut' }, 20);

  // ── 4. SCENE 3: the train scrub. The camera is parked; the world slides by ──
  tl.to(rig, { trainX: TRAIN.xEnd, duration: 22, ease: 'none' }, 29.5);

  // ── 5. SCENE 4: airplane + banner crosses the sky (right → left) ───────────
  tl.to(rig, { planeX: -54, duration: 7, ease: 'none' }, 55.5);

  // ── 6. SCENE 6: camera progress along the road (drives the sand engraving) ─
  tl.to(rig, { roadU: ROAD_TIMES.u1, duration: ROAD_TIMES.t1 - ROAD_TIMES.t0, ease: 'none' }, ROAD_TIMES.t0);

  // ── 7. ATMOSPHERE: palette blends between scenes (see Atmosphere.jsx) ──────
  tl.to(rig, { atmo: 1, duration: 5, ease: 'sine.inOut' }, 5) // overcast door → bright meadow
    .to(rig, { atmo: 2, duration: 3.5, ease: 'sine.inOut' }, 52) // → deep blue sky
    .to(rig, { atmo: 3, duration: 5, ease: 'sine.inOut' }, 62) // → stone-wall daylight
    .to(rig, { atmo: 4, duration: 6, ease: 'sine.inOut' }, 79) // → golden hour
    .to(rig, { atmo: 5, duration: 8, ease: 'sine.inOut' }, 96); // → sunset at the booth

  // Pad to exactly TOTAL so scroll 100% == timeline end (the booth form stays on screen).
  tl.set({}, {}, TOTAL);
  return tl;
}
