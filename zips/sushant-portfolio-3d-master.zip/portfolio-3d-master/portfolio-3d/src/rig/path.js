import * as THREE from 'three';
import { WAYPOINTS } from '../config/storyboard';
import { smooth } from '../shared/utils';

const LAST = WAYPOINTS.length - 1;
const posCurve = new THREE.CatmullRomCurve3(WAYPOINTS.map((w) => new THREE.Vector3(...w.pos)), false, 'centripetal');
const lookCurve = new THREE.CatmullRomCurve3(WAYPOINTS.map((w) => new THREE.Vector3(...w.look)), false, 'centripetal');

/**
 * pathT ∈ [0,1] → camera position, look-at target and fov.
 * Because both curves share the same parameter, position and look-at can never drift apart.
 * Waypoint i sits exactly at pathT = i / LAST.
 */
export function sampleCamera(pathT, outPos, outLook) {
  const t = Math.min(1, Math.max(0, pathT));
  posCurve.getPoint(t, outPos);
  lookCurve.getPoint(t, outLook);
  const f = t * LAST;
  const i = Math.min(Math.floor(f), LAST - 1);
  const k = smooth(f - i);
  return WAYPOINTS[i].fov + (WAYPOINTS[i + 1].fov - WAYPOINTS[i].fov) * k;
}
