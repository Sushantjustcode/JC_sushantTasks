import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { rig } from './rig';
import { sceneById } from '../config/storyboard';

/**
 * Renders its children only while the timeline is inside the scene's `show` window.
 * Keeps seven big scenes from all being drawn at once. Pass `range` to override.
 */
export function SceneGroup({ id, range, children, ...props }) {
  const ref = useRef();
  const [a, b] = range ?? sceneById[id].show;
  useFrame(() => {
    if (ref.current) ref.current.visible = rig.time >= a && rig.time <= b;
  });
  return (
    <group ref={ref} visible={a <= 0} {...props}>
      {children}
    </group>
  );
}
