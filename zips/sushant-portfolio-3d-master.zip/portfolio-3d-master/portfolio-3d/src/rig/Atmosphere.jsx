import { useLayoutEffect, useRef } from 'react';
import * as THREE from 'three';
import { useFrame, useThree } from '@react-three/fiber';
import { rig } from './rig';
import { BOOTH } from '../config/storyboard';

const P = (sky, sun, sunI, hemiI, fog, sunPos) => ({
  sky: new THREE.Color(sky),
  sun: new THREE.Color(sun),
  sunI,
  hemiI,
  fog,
  sunPos: new THREE.Vector3(...sunPos),
});

// Index = rig.atmo. Fractions blend between neighbours.
const PALETTE = [
  P('#cfe2ec', '#fff1d4', 2.6, 1.7, 0.012, [5, 9, 12]), // 0 entrance: soft morning
  P('#8fcdf2', '#fff7e6', 3.2, 1.8, 0.009, [-6, 16, 8]), // 1 meadow & train: bright day
  P('#1a4fae', '#ffffff', 3.0, 2.0, 0.004, [8, 25, 4]), // 2 deep blue sky
  P('#7f9cc2', '#ffe3b8', 2.8, 1.6, 0.006, [7, 12, 14]), // 3 stone wall
  P('#f2b97c', '#ffc27a', 3.0, 1.5, 0.008, [10, 5, -12]), // 4 golden hour road
  P('#ee7f5c', '#ff9a55', 3.4, 1.3, 0.010, BOOTH.sunPos), // 5 sunset booth
];

const _c = new THREE.Color();
const _v = new THREE.Vector3();
const WHITE = new THREE.Color('#ffffff');

/** Sky colour, fog, sun and fill light all follow rig.atmo, so scenes dissolve into each other. */
export default function Atmosphere() {
  const scene = useThree((s) => s.scene);
  const sun = useRef();
  const hemi = useRef();

  useLayoutEffect(() => {
    scene.background = new THREE.Color(PALETTE[0].sky);
    scene.fog = new THREE.FogExp2(PALETTE[0].sky.getHex(), PALETTE[0].fog);
  }, [scene]);

  useFrame(() => {
    if (!scene.background) return; // first frame can run before the effect above
    const i = Math.min(Math.floor(rig.atmo), PALETTE.length - 2);
    const f = rig.atmo - i;
    const A = PALETTE[i];
    const B = PALETTE[i + 1];
    _c.copy(A.sky).lerp(B.sky, f);
    scene.background.copy(_c);
    if (scene.fog) {
      scene.fog.color.copy(_c);
      scene.fog.density = A.fog + (B.fog - A.fog) * f;
    }
    if (sun.current) {
      sun.current.color.copy(A.sun).lerp(B.sun, f);
      sun.current.intensity = A.sunI + (B.sunI - A.sunI) * f;
      sun.current.position.copy(_v.copy(A.sunPos).lerp(B.sunPos, f));
    }
    if (hemi.current) {
      hemi.current.color.copy(_c).lerp(WHITE, 0.35);
      hemi.current.intensity = A.hemiI + (B.hemiI - A.hemiI) * f;
    }
  });

  return (
    <>
      <directionalLight ref={sun} />
      <hemisphereLight ref={hemi} args={['#ffffff', '#4b4a38', 1.6]} />
    </>
  );
}
