import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { rig } from './rig';
import { fadeWindow } from '../shared/utils';

/**
 * Fades a DOM node that lives inside a drei <Html> using timeline time.
 *   win = [fadeInStart, fadeInEnd, fadeOutStart, fadeOutEnd]
 * Hidden nodes also get visibility:hidden, so they cannot be tabbed into.
 * Give the node  style={{ opacity: 0, visibility: 'hidden' }}  to avoid a first-frame flash.
 */
export function useFade(ref, win) {
  const last = useRef(-1);
  useFrame(() => {
    const el = ref.current;
    if (!el) return;
    const o = fadeWindow(rig.time, win);
    if (Math.abs(o - last.current) < 0.004) return;
    last.current = o;
    el.style.opacity = o.toFixed(3);
    el.style.visibility = o < 0.01 ? 'hidden' : 'visible';
    el.style.pointerEvents = o > 0.7 ? 'auto' : 'none';
  });
}

/** Organic flicker for a light / material property (sum of three sines ≈ candle). */
export function useFlicker(ref, { base = 1, amp = 0.15, speed = 9, prop = 'intensity' } = {}) {
  useFrame(({ clock }) => {
    const o = ref.current;
    if (!o) return;
    const t = clock.elapsedTime * speed;
    const n = Math.sin(t) * 0.5 + Math.sin(t * 2.37 + 1.7) * 0.3 + Math.sin(t * 5.11 + 0.4) * 0.2;
    o[prop] = base * (1 + n * amp);
  });
}
