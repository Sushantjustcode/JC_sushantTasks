import { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame, useThree } from '@react-three/fiber';
import { rig } from './rig';
import { sampleCamera } from './path';
import { smooth } from '../shared/utils';

const DAMP = 5; // higher = snappier. exp(-DAMP*dt) smoothing = the "lerp" that stops jarring moves.

/**
 * Reads rig.pathT (written by GSAP), samples the splines, then eases the real
 * camera toward that target every frame. Also adds a faint hand-held drift and
 * mouse parallax that calm down to zero when the contact form locks the camera.
 */
export default function CameraRig() {
  const camera = useThree((s) => s.camera);
  const size = useThree((s) => s.size);
  const cur = useRef({ pos: new THREE.Vector3(), look: new THREE.Vector3(), fov: 42, ready: false });
  const tp = useMemo(() => new THREE.Vector3(), []);
  const tl = useMemo(() => new THREE.Vector3(), []);

  useFrame((state, dt) => {
    const c = cur.current;
    let fov = sampleCamera(rig.pathT, tp, tl);

    const aspect = size.width / size.height;
    fov *= 1 + Math.max(0, 1.15 - aspect) * 0.9; // widen on portrait phones so scenes still fit

    const calm = 1 - smooth((rig.time - 115) / 3); // 1 normally → 0 when the form locks
    const t = state.clock.elapsedTime;
    tp.x += (Math.sin(t * 0.45) * 0.04 + state.pointer.x * 0.12) * calm;
    tp.y += (Math.sin(t * 0.63 + 1.3) * 0.03 + state.pointer.y * 0.06) * calm;

    if (!c.ready) {
      c.pos.copy(tp);
      c.look.copy(tl);
      c.fov = fov;
      c.ready = true;
    }
    const k = 1 - Math.exp(-DAMP * Math.min(dt, 0.1));
    c.pos.lerp(tp, k);
    c.look.lerp(tl, k);
    c.fov += (fov - c.fov) * k;

    camera.position.copy(c.pos);
    camera.lookAt(c.look);
    if (Math.abs(camera.fov - c.fov) > 0.001) {
      camera.fov = c.fov;
      camera.updateProjectionMatrix();
    }
  });
  return null;
}
