import { Suspense, useRef } from 'react';
import { Canvas } from '@react-three/fiber';
import { useScrollRig } from './rig/useScrollRig';
import CameraRig from './rig/CameraRig';
import Atmosphere from './rig/Atmosphere';
import Effects from './rig/Effects';
import { SwayTicker } from './shared/Grass';
import EntranceScene from './scenes/EntranceScene';
import MeadowScene from './scenes/MeadowScene';
import OakScene from './scenes/OakScene';
import TrainScene from './scenes/TrainScene';
import SkyScene from './scenes/SkyScene';
import StoneWallScene from './scenes/StoneWallScene';
import DirtRoadScene from './scenes/DirtRoadScene';
import PhoneBoothScene from './scenes/PhoneBoothScene';
import IntroOverlay from './ui/IntroOverlay';
import ProgressHUD from './ui/ProgressHUD';
import { SCROLL_VH_PER_UNIT, TOTAL } from './config/storyboard';

/**
 * Layout = three layers:
 *   z-0   fixed full-screen <Canvas> (also hosts every drei <Html> panel)
 *   z-10  DOM intro overlay (faded by the master timeline)
 *   -     a tall invisible #scroll-spacer: its scroll distance IS the story's length
 */
export default function App() {
  const intro = useRef(null);
  useScrollRig({ get intro() { return intro.current; } });

  return (
    <>
      <div className="fixed inset-0 z-0">
        <Canvas dpr={[1, 1.75]} gl={{ antialias: false, powerPreference: 'high-performance' }} camera={{ fov: 42, near: 0.1, far: 500, position: [0, 1.7, 9.5] }}>
          <SwayTicker />
          <CameraRig />
          <Atmosphere />
          <Suspense fallback={null}>
            <EntranceScene />
            <MeadowScene />
            <OakScene />
            <TrainScene />
            <SkyScene />
            <StoneWallScene />
            <DirtRoadScene />
            <PhoneBoothScene />
          </Suspense>
          <Effects />
        </Canvas>
      </div>
      <IntroOverlay ref={intro} />
      <ProgressHUD />
      <div id="scroll-spacer" aria-hidden style={{ height: `${TOTAL * SCROLL_VH_PER_UNIT}vh` }} />
    </>
  );
}
