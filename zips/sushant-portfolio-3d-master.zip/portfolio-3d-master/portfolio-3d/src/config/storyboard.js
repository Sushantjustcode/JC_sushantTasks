import * as THREE from 'three';
import { SKILL_GROUPS } from './cv';

// ─────────────────────────────────────────────────────────────────────────────
// STORYBOARD = the one file that decides *when* and *where* everything happens.
//   • Time is measured in "scroll units". 1 unit = SCROLL_VH_PER_UNIT viewport heights.
//   • The master GSAP timeline is exactly TOTAL units long and is scrubbed by scroll.
//   • Each scene has `start/end` (its story beat) and `show` (when it is rendered).
// ─────────────────────────────────────────────────────────────────────────────

export const TOTAL = 124;
export const SCROLL_VH_PER_UNIT = 10; // 124 units -> 1240vh of scroll

export const SCENES = [
  { id: 'entrance', label: 'The Entrance', start: 0, end: 10, show: [0, 12] },
  { id: 'oak', label: 'The Oak Tree', start: 10, end: 26, show: [3, 30] },
  { id: 'train', label: 'The Blue Train', start: 26, end: 53, show: [3, 56] },
  { id: 'sky', label: 'The Sky', start: 53, end: 67, show: [3, 68] },
  { id: 'wall', label: 'The Stone Wall', start: 67, end: 82, show: [60, 84] },
  { id: 'road', label: 'The Dirt Road', start: 82, end: 104, show: [76, 108] },
  { id: 'booth', label: 'The Telephone Booth', start: 104, end: 124, show: [96, 124] },
];
export const sceneById = Object.fromEntries(SCENES.map((s) => [s.id, s]));

/** Optional .glb files in /public/models. Missing files fall back to built-in primitives. */
export const MODELS = {
  entrance: '/models/entrance.glb', // must contain a node named "DoorLeaf" (pivot at the hinge)
  oak: '/models/oak.glb',
  loco: '/models/loco.glb', // length along +x, nose at x=0
  coach: '/models/coach.glb', // length along +x, centred on origin; wheel nodes named "Wheel*"
  plane: '/models/plane.glb',
  stoneWall: '/models/stone_wall.glb',
  booth: '/models/phone_booth.glb',
};

// ── World layout ─────────────────────────────────────────────────────────────
export const WORLD = {
  entrance: { doorW: 1.7, doorH: 2.9, wallW: 16, wallH: 6.6, wallT: 0.7 },
  oak: { pos: [-1.8, 0, -13] },
  stone: { pos: [0, 0, -110], w: 22, h: 16 },
};

export const TRAIN = {
  z: -38,
  x0: -10, // x of the loco's nose at rest (also where the scrub starts)
  locoLen: 10,
  coachLen: 9,
  gap: 0.5,
  count: SKILL_GROUPS.length,
};
TRAIN.length = TRAIN.locoLen + TRAIN.count * (TRAIN.coachLen + TRAIN.gap);
TRAIN.xEnd = -8 - TRAIN.length; // last coach has fully left the left edge of the frame
export const coachCenter = (k) => TRAIN.locoLen + TRAIN.gap + k * (TRAIN.coachLen + TRAIN.gap) + TRAIN.coachLen / 2;

/** The winding dirt road (scene 6). Starts at the foot of the stone wall, ends at the booth. */
const ROAD_RAW = [[0, 0], [-8, 3], [-18, 0], [-30, 6], [-37, 16], [-33, 27], [-38, 38], [-47, 44]];
export const ROAD = new THREE.CatmullRomCurve3(
  ROAD_RAW.map(([x, z]) => new THREE.Vector3(x * 1.55, 0, -104 + z * 1.55)),
  false,
  'centripetal'
);

// Telephone booth stands just past the end of the road, front facing back down the road.
const endP = ROAD.getPointAt(1);
const endT = ROAD.getTangentAt(1);
export const BOOTH = {
  pos: new THREE.Vector3(endP.x + endT.x * 2.4, 0, endP.z + endT.z * 2.4),
  rotY: Math.atan2(-endT.x, -endT.z),
};
const boothM = new THREE.Matrix4().compose(
  BOOTH.pos,
  new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), BOOTH.rotY),
  new THREE.Vector3(1, 1, 1)
);
const B = (x, y, z) => new THREE.Vector3(x, y, z).applyMatrix4(boothM).toArray(); // booth-local -> world
// Low sunset sun: in front of the booth, a little to the side.
BOOTH.sunPos = B(7, 3.2, 9).map((v, i) => v - BOOTH.pos.toArray()[i]);

// ── Camera waypoints ─────────────────────────────────────────────────────────
// `t` = timeline time at which the camera ARRIVES at this waypoint.
// `ease` shapes the move from the previous waypoint to this one.
// pos / look are fed to two CatmullRom curves sampled by one scalar (rig.pathT).
const road = (u) => {
  const p = ROAD.getPointAt(u);
  const tan = ROAD.getTangentAt(u);
  const a = ROAD.getPointAt(Math.min(u + 0.055, 1));
  return { pos: [p.x - tan.x * 3, 10, p.z - tan.z * 3], look: [a.x, 0, a.z] };
};
const roadU = Array.from({ length: 10 }, (_, i) => 0.06 + (i * 0.88) / 9);
const ROAD_T0 = 86;
const ROAD_T1 = 102;

export const WAYPOINTS = [
  // Scene 1 – the door
  { t: 0, pos: [0, 1.7, 9.5], look: [0, 1.6, 0], fov: 42 },
  { t: 6, pos: [0, 1.65, 2.4], look: [0, 1.5, -5], fov: 46 },
  // Scene 2 – through the door, oak tree
  { t: 10, pos: [0, 1.7, -3.5], look: [-1.2, 2.8, -13], fov: 50 },
  { t: 19, pos: [0, 1.7, -5], look: [-1.2, 2.8, -13.5], fov: 50, ease: 'sine.inOut' },
  { t: 25, pos: [6.5, 1.8, -19], look: [7, 1.6, -34], fov: 46 }, // slide past the oak, eyes on the rails
  // Scene 3 – parallel to the train (camera holds, the train scrubs)
  { t: 29, pos: [0, 2.3, -29], look: [0, 2.2, -38], fov: 44, ease: 'power2.inOut' },
  { t: 51, pos: [0.4, 2.3, -29], look: [0.4, 2.2, -38], fov: 44, ease: 'none' },
  // Scene 4 – whip up into the sky, plane flies by, pan down onto the wall
  { t: 54.5, pos: [0, 2.6, -29.5], look: [0, 30, -46], fov: 48, ease: 'power3.inOut' },
  { t: 62, pos: [0, 6, -34], look: [0, 28, -48], fov: 50, ease: 'sine.inOut' },
  { t: 67, pos: [0, 11.8, -100.5], look: [0, 11.2, -110], fov: 42, ease: 'power2.inOut' },
  // Scene 5 – stone wall: read the top frame, then travel down the wall
  { t: 69, pos: [0, 11.8, -100.5], look: [0, 11.2, -110], fov: 42, ease: 'none' },
  { t: 80, pos: [0, 3.4, -100.5], look: [0, 3.2, -110], fov: 42, ease: 'none' },
  // Scene 6 – drop low, yaw left to find the path, then drone along it
  { t: 83, pos: [-1.5, 2.0, -98.5], look: [-14, 0.3, -100], fov: 46, ease: 'power2.inOut' },
  ...roadU.map((u, i) => ({
    t: ROAD_T0 + (i * (ROAD_T1 - ROAD_T0)) / 9,
    ...road(u),
    fov: 48,
    ease: i === 0 ? 'sine.inOut' : 'none',
  })),
  // Scene 7 – booth: A) full frame  B) dolly in  C) lock on the paper
  { t: 108, pos: B(1.0, 1.7, 8.2), look: B(0.5, 1.6, 0), fov: 40, ease: 'power2.inOut' },
  { t: 115, pos: B(0.15, 1.8, 5.6), look: B(0, 1.85, 0.9), fov: 36, ease: 'power3.inOut' },
  { t: 118, pos: B(0, 1.85, 3.85), look: B(0, 1.85, 0.95), fov: 34, ease: 'sine.out' },
];

export const ROAD_TIMES = { t0: ROAD_T0, t1: ROAD_T1, u0: roadU[0], u1: roadU[roadU.length - 1] };
