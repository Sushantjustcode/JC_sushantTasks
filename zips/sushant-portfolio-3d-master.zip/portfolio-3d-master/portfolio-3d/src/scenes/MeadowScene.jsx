import { useMemo } from 'react';
import { SceneGroup } from '../rig/SceneGroup';
import { GrassInstances } from '../shared/Grass';
import { mulberry32 } from '../shared/utils';
import { TRAIN } from '../config/storyboard';

/** Ground, swaying grass and distant hills shared by scenes 2–4 (behind the door → train → sky). */
export default function MeadowScene() {
  const blades = useMemo(() => {
    const r = mulberry32(99);
    const out = [];
    while (out.length < 2800) {
      const x = (r() - 0.5) * 90;
      const z = 2 - r() * 44;
      if (Math.abs(z - TRAIN.z) < 2.4) continue; // keep the track bed clear
      out.push([x, z]);
    }
    return out;
  }, []);
  const hills = useMemo(() => [[-60, -88, 38, 9], [-10, -95, 48, 12], [48, -90, 40, 8], [95, -80, 36, 10], [-105, -70, 30, 7]], []);
  return (
    <SceneGroup range={[3, 68]}>
      <mesh rotation-x={-Math.PI / 2} position={[0, 0, -30]}>
        <planeGeometry args={[220, 110]} />
        <meshStandardMaterial color="#79a85a" roughness={1} />
      </mesh>
      <GrassInstances positions={blades} height={0.7} color="#5a9444" seed={4} />
      {hills.map(([x, z, w, h], i) => (
        <mesh key={i} position={[x, -2, z]} scale={[w, h, 18]}>
          <sphereGeometry args={[1, 24, 14]} />
          <meshStandardMaterial color={i % 2 ? '#5f9552' : '#6aa35a'} roughness={1} flatShading />
        </mesh>
      ))}
    </SceneGroup>
  );
}
