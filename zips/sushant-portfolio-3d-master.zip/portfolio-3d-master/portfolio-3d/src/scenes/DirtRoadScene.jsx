import { useEffect, useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { Sparkles } from '@react-three/drei';
import { rig } from '../rig/rig';
import { SceneGroup } from '../rig/SceneGroup';
import { GrassInstances } from '../shared/Grass';
import { useSandTexture } from '../shared/textures';
import { clamp01, mulberry32 } from '../shared/utils';
import { TIMELINE } from '../config/cv';
import { ROAD } from '../config/storyboard';

/**
 * SCENE 6: THE DIRT ROAD (career / education timeline)
 * A sand ribbon is extruded along ROAD (the same spline the drone camera follows).
 * Each TIMELINE entry is "written" into a clearing with a stick: a canvas texture is
 * re-drawn with a growing clip (line by line, left → right) while a 3D stick tip follows
 * the writing front. Progress comes from rig.roadU, the camera's position on the road.
 */

const N = TIMELINE.length;
const milestoneU = (i) => 0.2 + (i * 0.7) / (N - 1);
// An entry starts being written when the camera is 0.15 of the road behind it, and is done at 0.03.
const REVEAL_FROM = 0.15;
const REVEAL_SPAN = 0.12;
const roadWidth = (u) => {
  let w = 3.2;
  for (let i = 0; i < N; i++) w += 5 * Math.exp(-(((u - milestoneU(i)) / 0.032) ** 2)); // clearing at each milestone
  return w;
};

function RoadRibbon() {
  const sand = useSandTexture();
  const geo = useMemo(() => {
    const SEG = 240;
    const total = ROAD.getLength();
    const pos = [];
    const uv = [];
    const idx = [];
    for (let i = 0; i <= SEG; i++) {
      const u = i / SEG;
      const p = ROAD.getPointAt(u);
      const t = ROAD.getTangentAt(u);
      const w = roadWidth(u) / 2;
      pos.push(p.x - t.z * w, 0.02, p.z + t.x * w, p.x + t.z * w, 0.02, p.z - t.x * w);
      uv.push(0, (u * total) / 5, 1, (u * total) / 5);
      if (i < SEG) {
        const a = i * 2;
        idx.push(a, a + 2, a + 1, a + 1, a + 2, a + 3);
      }
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    g.setIndex(idx);
    g.computeVertexNormals();
    return g;
  }, []);
  return (
    <mesh geometry={geo}>
      <meshStandardMaterial map={sand} roughness={1} side={THREE.DoubleSide} />
    </mesh>
  );
}

function RoadGrass() {
  const blades = useMemo(() => {
    const r = mulberry32(77);
    const out = [];
    for (let i = 0; i < 150; i++) {
      const u = i / 149;
      const p = ROAD.getPointAt(u);
      const t = ROAD.getTangentAt(u);
      for (const side of [-1, 1]) {
        const off = roadWidth(u) / 2 + 0.25 + r() * 2.2;
        const cx = p.x - t.z * off * side;
        const cz = p.z + t.x * off * side;
        for (let k = 0; k < 7; k++) out.push([cx + (r() - 0.5) * 0.9, cz + (r() - 0.5) * 0.9]);
      }
    }
    return out;
  }, []);
  return <GrassInstances positions={blades} height={0.8} color="#7e9a3f" seed={9} />;
}

const CW = 1024;
const CH = 400;
const PLANE_W = 8;
const PLANE_H = (PLANE_W * CH) / CW;

function fit(g, text, size, weight, family) {
  let s = size;
  g.font = `${weight} ${s}px ${family}`;
  while (g.measureText(text).width > CW - 90 && s > 20) {
    s -= 2;
    g.font = `${weight} ${s}px ${family}`;
  }
  return s;
}

/** One engraved entry. Re-draws its canvas only while the reveal progress is changing. */
function Milestone({ item, u }) {
  const stick = useRef();
  const last = useRef(-1);
  const p = ROAD.getPointAt(u);
  const t = ROAD.getTangentAt(u);
  const rotY = Math.atan2(-t.x, -t.z); // text reads left→right on screen when heading along the road

  const { canvas, tex, ctx, lines } = useMemo(() => {
    const canvas = document.createElement('canvas');
    canvas.width = CW;
    canvas.height = CH;
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    tex.anisotropy = 8;
    const lines = [
      { text: item.when, size: 130, weight: 700, y: 120, family: 'Caveat, "Segoe Script", cursive' },
      { text: item.title, size: 76, weight: 700, y: 215, family: 'Caveat, "Segoe Script", cursive' },
      { text: item.place, size: 54, weight: 600, y: 285, family: 'Caveat, "Segoe Script", cursive' },
      ...(item.note ? [{ text: item.note, size: 48, weight: 600, y: 345, family: 'Caveat, "Segoe Script", cursive' }] : []),
    ];
    return { canvas, tex, ctx: canvas.getContext('2d'), lines };
  }, [item]);

  const draw = (prog) => {
    ctx.clearRect(0, 0, CW, CH);
    const L = lines.length;
    let front = { x: 0, y: 0 };
    lines.forEach((ln, k) => {
      const lp = clamp01(prog * L - k);
      if (lp <= 0) return;
      const size = fit(ctx, ln.text, ln.size, ln.weight, ln.family);
      const w = ctx.measureText(ln.text).width;
      const x0 = (CW - w) / 2;
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, 0, x0 + w * lp + 6, CH);
      ctx.clip();
      ctx.font = `${ln.weight} ${size}px ${ln.family}`;
      ctx.textBaseline = 'alphabetic';
      ctx.fillStyle = 'rgba(255,236,196,0.7)'; // sunlit lip of the groove
      ctx.fillText(ln.text, x0 + 2.5, ln.y + 2.5);
      ctx.fillStyle = '#5a3a1a'; // shadowed bottom of the groove
      ctx.fillText(ln.text, x0, ln.y);
      ctx.restore();
      if (lp < 1 || k === L - 1) front = { x: x0 + w * lp, y: ln.y };
    });
    tex.needsUpdate = true;
    return front;
  };

  useEffect(() => {
    document.fonts?.ready.then(() => (last.current = -1)); // redraw once Caveat has loaded
    return () => tex.dispose();
  }, [tex]);

  useFrame(({ clock }) => {
    const prog = clamp01((rig.roadU - (u - REVEAL_FROM)) / REVEAL_SPAN);
    if (Math.abs(prog - last.current) > 0.002) {
      last.current = prog;
      const f = draw(prog);
      if (stick.current) {
        stick.current.position.set((f.x / CW - 0.5) * PLANE_W, 0.05, (f.y / CH - 0.5) * PLANE_H);
        stick.current.visible = prog > 0 && prog < 0.999;
      }
    }
    if (stick.current?.visible) stick.current.position.y = 0.05 + Math.sin(clock.elapsedTime * 20) * 0.015; // scratching wobble
  });

  return (
    <group position={[p.x, 0, p.z]} rotation-y={rotY}>
      <mesh rotation-x={-Math.PI / 2} position={[0, 0.05, 0]}>
        <planeGeometry args={[PLANE_W, PLANE_H]} />
        <meshStandardMaterial map={tex} transparent depthWrite={false} roughness={1} polygonOffset polygonOffsetFactor={-2} />
      </mesh>
      <group ref={stick} visible={false}>
        <mesh position={[0.45, 0.8, 0]} rotation={[0, 0, -0.8]}>
          <cylinderGeometry args={[0.035, 0.05, 1.8, 6]} />
          <meshStandardMaterial color="#6b4a2b" roughness={1} />
        </mesh>
      </group>
    </group>
  );
}

export default function DirtRoadScene() {
  const mid = ROAD.getPointAt(0.5);
  return (
    <>
      {/* ground is shared by scenes 5 + 6 + 7 */}
      <SceneGroup range={[58, 125]}>
        <mesh rotation-x={-Math.PI / 2} position={[-35, -0.03, -70]}>
          <planeGeometry args={[300, 220]} />
          <meshStandardMaterial color="#8aa65a" roughness={1} />
        </mesh>
      </SceneGroup>
      <SceneGroup id="road">
        <RoadRibbon />
        <RoadGrass />
        {TIMELINE.map((item, i) => (
          <Milestone key={item.title + item.when} item={item} u={milestoneU(i)} />
        ))}
        <Sparkles count={120} scale={[90, 5, 80]} position={[mid.x, 2.5, mid.z]} size={6} speed={0.3} color="#ffe29a" />
      </SceneGroup>
    </>
  );
}
