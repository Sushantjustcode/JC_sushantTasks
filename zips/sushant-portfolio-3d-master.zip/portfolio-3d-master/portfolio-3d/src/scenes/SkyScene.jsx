import { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { rig } from '../rig/rig';
import { SceneGroup } from '../rig/SceneGroup';
import CloudField from '../shared/Clouds';
import { OptionalGLTF } from '../shared/OptionalGLTF';
import { useBannerTexture } from '../shared/textures';
import { MODELS } from '../config/storyboard';

/**
 * SCENE 4: THE SKY
 * Drifting clouds + an airplane towing a "PROJECTS" banner. rig.planeX (GSAP) places the
 * plane; the banner's vertices ripple every frame so it flaps like cloth.
 */
const matRed = new THREE.MeshStandardMaterial({ color: '#c4382a', roughness: 0.5 });
const matCream = new THREE.MeshStandardMaterial({ color: '#f1ead7', roughness: 0.6 });

function Airplane() {
  const g = useRef();
  const prop = useRef();
  const tex = useBannerTexture('PROJECTS');
  const geo = useMemo(() => new THREE.PlaneGeometry(14, 3.2, 28, 4), []);
  const base = useMemo(() => Float32Array.from(geo.attributes.position.array), [geo]);

  useFrame(({ clock }, dt) => {
    const t = clock.elapsedTime;
    g.current.position.set(rig.planeX, 27 + Math.sin(t * 0.8) * 0.4, -47);
    g.current.rotation.z = Math.sin(t * 0.7) * 0.03;
    if (prop.current) prop.current.rotation.x += dt * 45;
    const pos = geo.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      const k = (base[i * 3] + 7) / 14; // 0 at the tow rope → 1 at the free end
      pos.setZ(i, Math.sin(k * 9 - t * 5) * 0.5 * k);
      pos.setY(i, base[i * 3 + 1] + Math.sin(k * 5 - t * 3) * 0.12 * k);
    }
    pos.needsUpdate = true;
  });

  return (
    <group ref={g} scale={1.2}>
      <OptionalGLTF
        url={MODELS.plane}
        fallback={
          <group>
            {/* nose points toward -x so the plane flies right → left */}
            <mesh material={matRed} rotation={[0, 0, Math.PI / 2]}><capsuleGeometry args={[0.42, 3.0, 6, 12]} /></mesh>
            <mesh material={matCream} position={[-0.3, 0, 0]}><boxGeometry args={[0.9, 0.07, 6]} /></mesh>
            <mesh material={matRed} position={[1.7, 0.55, 0]}><boxGeometry args={[0.7, 0.9, 0.06]} /></mesh>
            <mesh material={matCream} position={[1.7, 0.1, 0]}><boxGeometry args={[0.5, 0.06, 1.9]} /></mesh>
            <group ref={prop} position={[-2.0, 0, 0]}>
              <mesh material={matCream}><boxGeometry args={[0.05, 1.5, 0.12]} /></mesh>
            </group>
          </group>
        }
      />
      <mesh position={[2.6, -0.1, 0]} material={matCream}><boxGeometry args={[0.9, 0.025, 0.025]} /></mesh>
      <mesh geometry={geo} position={[10, -0.2, 0]}>
        <meshBasicMaterial map={tex} side={THREE.DoubleSide} />
      </mesh>
    </group>
  );
}

export default function SkyScene() {
  return (
    <SceneGroup id="sky">
      <CloudField />
      <Airplane />
    </SceneGroup>
  );
}
