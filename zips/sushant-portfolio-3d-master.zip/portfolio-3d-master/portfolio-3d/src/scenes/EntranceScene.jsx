import { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { Html, Sparkles } from '@react-three/drei';
import { rig } from '../rig/rig';
import { SceneGroup } from '../rig/SceneGroup';
import { OptionalGLTF } from '../shared/OptionalGLTF';
import { useBrickTexture, useGradientAlpha } from '../shared/textures';
import { clamp01, dfFor, mulberry32 } from '../shared/utils';
import { MODELS, WORLD } from '../config/storyboard';

/**
 * SCENE 1: THE ENTRANCE
 * ─────────────────────
 * 3D: red brick wall, hanging vines + flowers, white wooden door that swings open,
 *     additive light-shaft cones + dust motes pouring out of the doorway.
 * HTML interplay:
 *   • <DoorSign/> is a drei <Html transform> child of the door-leaf group, so the DOM
 *     sign swings open WITH the 3D door and fades as it opens.
 *   • The big intro overlay lives in the DOM (ui/IntroOverlay) and is faded by the
 *     same master timeline that opens the door, so both are on one clock.
 * Everything is driven by rig.door / rig.glow (written by GSAP, see buildMasterTimeline).
 */

const { doorW: DW, doorH: DH, wallW: WW, wallH: WH, wallT: WT } = WORLD.entrance;
const OPEN = THREE.MathUtils.degToRad(105);
const WHITE = '#f3efe6';

function BrickBox({ size, position, map }) {
  const tex = useMemo(() => {
    const t = map.clone();
    t.repeat.set(size[0] / 1.6, size[1] / 1.6); // one brick tile = 1.6 world units
    t.needsUpdate = true;
    return t;
  }, [map, size]);
  return (
    <mesh position={position}>
      <boxGeometry args={size} />
      <meshStandardMaterial map={tex} roughness={0.95} />
    </mesh>
  );
}

/** Hanging vines (tube + leaf blobs + flower heads) that sway on their own phase. */
function Vines() {
  const refs = useRef([]);
  const vines = useMemo(() => {
    const r = mulberry32(21);
    const palette = ['#ff8fb1', '#ffd34d', '#ffffff', '#ff6f61'];
    return Array.from({ length: 10 }, (_, i) => {
      const len = 1.2 + r() * 2.4;
      const pts = Array.from({ length: 6 }, (_, k) => new THREE.Vector3(Math.sin(k * 1.3 + i) * 0.14, (-k / 5) * len, 0));
      const curve = new THREE.CatmullRomCurve3(pts);
      return {
        x: (i / 9 - 0.5) * (WW - 1.5) + (r() - 0.5) * 0.6,
        curve,
        phase: r() * 6,
        leaves: Array.from({ length: 9 }, () => ({ p: curve.getPoint(r()), s: 0.07 + r() * 0.06, a: r() * 3 })),
        flowers: Array.from({ length: 3 + Math.floor(r() * 4) }, () => ({ p: curve.getPoint(0.2 + r() * 0.8), s: 0.06 + r() * 0.05, c: palette[Math.floor(r() * 4)] })),
      };
    });
  }, []);
  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    refs.current.forEach((g, i) => g && (g.rotation.z = Math.sin(t * 0.8 + vines[i].phase) * 0.045));
  });
  return (
    <group>
      {vines.map((v, i) => (
        <group key={i} ref={(el) => (refs.current[i] = el)} position={[v.x, WH - 0.05, WT / 2 + 0.06]}>
          <mesh>
            <tubeGeometry args={[v.curve, 24, 0.022, 5]} />
            <meshStandardMaterial color="#3f7d34" roughness={0.9} />
          </mesh>
          {v.leaves.map((l, k) => (
            <mesh key={k} position={l.p} scale={[l.s * 1.6, l.s, l.s * 0.5]} rotation={[0, 0, l.a]}>
              <icosahedronGeometry args={[1, 0]} />
              <meshStandardMaterial color="#4f9a3d" flatShading />
            </mesh>
          ))}
          {v.flowers.map((f, k) => (
            <mesh key={k} position={f.p} scale={f.s}>
              <icosahedronGeometry args={[1, 1]} />
              <meshStandardMaterial color={f.c} roughness={0.7} flatShading />
            </mesh>
          ))}
        </group>
      ))}
    </group>
  );
}

/** A DOM sign mounted ON the door: it is a child of the leaf group, so it rotates with the 3D door. */
function DoorSign() {
  const ref = useRef();
  useFrame(() => {
    if (ref.current) ref.current.style.opacity = String(1 - clamp01(rig.door * 4));
  });
  return (
    <Html transform center distanceFactor={dfFor(130)} position={[(DW - 0.04) / 2, 2.25, 0.05]}>
      <div ref={ref} className="door-sign">
        Come in
        <small>scroll to open the door</small>
      </div>
    </Html>
  );
}

function ProceduralEntrance({ leafRef }) {
  const brick = useBrickTexture();
  const sideW = (WW - DW) / 2;
  const frame = <meshStandardMaterial color={WHITE} roughness={0.6} />;
  return (
    <group>
      <BrickBox map={brick} size={[sideW, WH, WT]} position={[-(DW / 2 + sideW / 2), WH / 2, 0]} />
      <BrickBox map={brick} size={[sideW, WH, WT]} position={[DW / 2 + sideW / 2, WH / 2, 0]} />
      <BrickBox map={brick} size={[DW, WH - DH, WT]} position={[0, DH + (WH - DH) / 2, 0]} />

      {/* white door frame */}
      <mesh position={[-DW / 2 - 0.05, DH / 2, 0.05]}><boxGeometry args={[0.1, DH, WT + 0.1]} />{frame}</mesh>
      <mesh position={[DW / 2 + 0.05, DH / 2, 0.05]}><boxGeometry args={[0.1, DH, WT + 0.1]} />{frame}</mesh>
      <mesh position={[0, DH + 0.05, 0.05]}><boxGeometry args={[DW + 0.2, 0.1, WT + 0.1]} />{frame}</mesh>
      {/* stone step */}
      <mesh position={[0, 0.06, 0.65]}><boxGeometry args={[DW + 0.7, 0.12, 0.9]} /><meshStandardMaterial color="#9b958a" roughness={1} /></mesh>

      {/* door leaf: group origin = hinge, so rotation.y swings it around the hinge edge */}
      <group ref={leafRef} position={[-DW / 2 + 0.02, 0, 0.18]}>
        <mesh position={[(DW - 0.04) / 2, DH / 2, 0]}>
          <boxGeometry args={[DW - 0.04, DH - 0.02, 0.07]} />
          <meshStandardMaterial color={WHITE} roughness={0.55} />
        </mesh>
        {[0.5, 1.45, 2.4].map((y, i) => (
          <mesh key={i} position={[(DW - 0.04) / 2, y, 0.045]}>
            <boxGeometry args={[DW - 0.5, i === 1 ? 0.7 : 0.55, 0.03]} />
            <meshStandardMaterial color="#e6e1d4" roughness={0.6} />
          </mesh>
        ))}
        <mesh position={[DW - 0.2, 1.05, 0.08]}>
          <sphereGeometry args={[0.045, 12, 12]} />
          <meshStandardMaterial color="#c9a35a" metalness={0.8} roughness={0.3} />
        </mesh>
        <DoorSign />
      </group>

      <Vines />
      {/* lawn in front of the wall */}
      <mesh rotation-x={-Math.PI / 2} position={[0, 0, 7]}>
        <planeGeometry args={[60, 14]} />
        <meshStandardMaterial color="#6fa05a" roughness={1} />
      </mesh>
    </group>
  );
}

/** Portal glow + volumetric-looking cones + dust motes + a flickering warm point light. */
function LightPouring() {
  const alpha = useGradientAlpha();
  const portal = useRef();
  const cones = useRef();
  const light = useRef();
  const portalMat = useMemo(() => {
    const m = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false });
    m.color.setRGB(2.4, 2.1, 1.6); // HDR (>1) so bloom picks it up
    return m;
  }, []);
  const coneMats = useMemo(
    () =>
      [0.9, 0.8, 0.7].map(() => {
        const m = new THREE.MeshBasicMaterial({ alphaMap: alpha, transparent: true, opacity: 0, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false });
        m.color.setRGB(1.6, 1.45, 1.1);
        return m;
      }),
    [alpha]
  );

  useFrame(({ clock }) => {
    const t = clock.elapsedTime;
    const fl = 1 + Math.sin(t * 7.3) * 0.04 + Math.sin(t * 13.1 + 2) * 0.03;
    const open = clamp01(rig.door * 1.6);
    portalMat.opacity = clamp01(rig.glow) * 0.95;
    coneMats.forEach((m, i) => (m.opacity = open * (0.14 + i * 0.05) * fl * (0.6 + 0.4 * Math.sin(t * 0.6 + i * 2))));
    if (light.current) light.current.intensity = rig.glow * 38 * fl;
  });

  return (
    <group>
      <mesh ref={portal} position={[0, DH / 2, -0.12]} material={portalMat}>
        <planeGeometry args={[DW - 0.04, DH - 0.02]} />
      </mesh>
      <group ref={cones} position={[0, DH / 2 - 0.1, 0.1]}>
        {[2.6, 1.8, 1.1].map((r, i) => (
          <mesh key={i} position={[0, 0, 3.1]} rotation={[Math.PI / 2, 0, 0]} material={coneMats[i]}>
            <cylinderGeometry args={[r, 0.25, 6, 32, 1, true]} />
          </mesh>
        ))}
      </group>
      <pointLight ref={light} position={[0, 1.6, -0.6]} color="#ffe2a8" distance={12} decay={1.6} intensity={0} />
      <Sparkles count={50} scale={[3.5, 3, 5]} position={[0, 1.6, 3]} size={4} speed={0.4} opacity={0.8} color="#fff6d8" />
    </group>
  );
}

export default function EntranceScene() {
  const leaf = useRef(null);
  useFrame(() => {
    if (leaf.current) leaf.current.rotation.y = rig.door * OPEN;
  });
  return (
    <SceneGroup id="entrance">
      <OptionalGLTF
        url={MODELS.entrance}
        onReady={(root) => {
          leaf.current = root.getObjectByName('DoorLeaf');
        }}
        fallback={<ProceduralEntrance leafRef={leaf} />}
      />
      <LightPouring />
    </SceneGroup>
  );
}
