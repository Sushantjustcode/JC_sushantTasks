import { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { Html } from '@react-three/drei';
import { rig } from '../rig/rig';
import { SceneGroup } from '../rig/SceneGroup';
import { useFade, useFlicker } from '../rig/hooks';
import { OptionalGLTF } from '../shared/OptionalGLTF';
import { usePaperTexture } from '../shared/textures';
import { dfFor } from '../shared/utils';
import ContactForm from '../ui/ContactForm';
import { PROFILE } from '../config/cv';
import { BOOTH, MODELS } from '../config/storyboard';

/**
 * SCENE 7: THE RED TELEPHONE BOOTH (contact)
 *  Step 1 – camera shows the booth full-frame; contact details sit on a signpost beside it.
 *  Step 2 – camera dollies into the glass pane (WAYPOINT t=115).
 *  Step 3 – camera locks on the paper (t=118); the DOM contact form fades in over the paper.
 * The form is a drei <Html transform> child of the paper mesh, so it is pinned to the paper in 3D.
 */

const BW = 1.8; // booth width / depth
const BH = 3.2;
const PAPER = { w: 1.0, h: 1.3 };
const FORM_PX = 460;
const SIGN_PX = 170;
const matRed = new THREE.MeshStandardMaterial({ color: '#c4161c', roughness: 0.45, metalness: 0.1 });
const matGlass = new THREE.MeshStandardMaterial({ color: '#bfe6ff', transparent: true, opacity: 0.16, roughness: 0.1, metalness: 0.1, side: THREE.DoubleSide, depthWrite: false });
const matDark = new THREE.MeshStandardMaterial({ color: '#1b1b1d', roughness: 0.7 });

function BoothBody() {
  const sign = useMemo(() => {
    const c = document.createElement('canvas');
    c.width = 512;
    c.height = 96;
    const g = c.getContext('2d');
    g.fillStyle = '#fff6dc';
    g.fillRect(0, 0, 512, 96);
    g.fillStyle = '#c4161c';
    g.font = '700 58px Fraunces, Georgia, serif';
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.fillText('TELEPHONE', 256, 52);
    const t = new THREE.CanvasTexture(c);
    t.colorSpace = THREE.SRGBColorSpace;
    return t;
  }, []);
  const bulb = useRef();
  useFlicker(bulb, { base: 6, amp: 0.25, speed: 7 });
  const posts = [[-1, -1], [1, -1], [-1, 1], [1, 1]];
  const panes = [
    { p: [0, 1.8, BW / 2 - 0.04], r: 0, w: BW - 0.12 },
    { p: [0, 1.8, -BW / 2 + 0.04], r: 0, w: BW - 0.12 },
    { p: [BW / 2 - 0.04, 1.8, 0], r: Math.PI / 2, w: BW - 0.12 },
    { p: [-BW / 2 + 0.04, 1.8, 0], r: Math.PI / 2, w: BW - 0.12 },
  ];
  return (
    <group>
      <mesh material={matRed} position={[0, 0.35, 0]}><boxGeometry args={[BW + 0.15, 0.7, BW + 0.15]} /></mesh>
      {posts.map(([x, z], i) => (
        <mesh key={i} material={matRed} position={[x * (BW / 2 - 0.05), 0.7 + 1.1, z * (BW / 2 - 0.05)]}><boxGeometry args={[0.1, 2.2, 0.1]} /></mesh>
      ))}
      {panes.map((a, i) => (
        <group key={i} position={a.p} rotation={[0, a.r, 0]}>
          <mesh material={matGlass}><boxGeometry args={[a.w, 2.0, 0.02]} /></mesh>
          {[-0.3, 0.3].map((x) => (
            <mesh key={x} material={matRed} position={[x, 0, 0.01]}><boxGeometry args={[0.04, 2.0, 0.03]} /></mesh>
          ))}
          {[-0.65, -0.1, 0.45, 0.95].map((y) => (
            <mesh key={y} material={matRed} position={[0, y, 0.01]}><boxGeometry args={[a.w, 0.04, 0.03]} /></mesh>
          ))}
        </group>
      ))}
      <mesh material={matRed} position={[0, BH - 0.1, 0]}><boxGeometry args={[BW + 0.2, 0.22, BW + 0.2]} /></mesh>
      <mesh material={matRed} position={[0, BH + 0.1, 0]}><boxGeometry args={[BW - 0.2, 0.18, BW - 0.2]} /></mesh>
      <mesh material={matRed} position={[0, BH + 0.26, 0]}><boxGeometry args={[BW - 0.7, 0.14, BW - 0.7]} /></mesh>
      <mesh position={[0, BH - 0.44, BW / 2 + 0.01]}>
        <planeGeometry args={[BW - 0.2, 0.34]} />
        <meshBasicMaterial map={sign} />
      </mesh>
      {/* inside: phone + flickering bulb */}
      <mesh material={matDark} position={[0, 1.5, -BW / 2 + 0.2]}><boxGeometry args={[0.4, 0.55, 0.16]} /></mesh>
      <pointLight ref={bulb} position={[0, 2.6, 0]} color="#ffcf8a" distance={6} decay={2} />
    </group>
  );
}

function Paper() {
  const paperTex = usePaperTexture();
  const form = useRef();
  useFade(form, [115.5, 118, 200, 201]); // fades in as the camera locks, never fades out
  return (
    <group position={[0, 1.85, BW / 2 + 0.03]} rotation={[0, 0, 0.015]}>
      <mesh>
        <planeGeometry args={[PAPER.w, PAPER.h]} />
        <meshStandardMaterial map={paperTex} roughness={0.9} />
      </mesh>
      <Html transform center distanceFactor={dfFor(FORM_PX)} position={[0, 0, 0.01]}>
        <div ref={form} className="paper" style={{ width: PAPER.w * FORM_PX, height: PAPER.h * FORM_PX, opacity: 0, visibility: 'hidden' }}>
          <ContactForm />
        </div>
      </Html>
    </group>
  );
}

function ContactSign() {
  const ref = useRef();
  useFade(ref, [105, 107, 113.5, 115.5]);
  const links = [
    ['Phone', PROFILE.phone, `tel:${PROFILE.phone.replace(/[^+\d]/g, '')}`],
    ['Email', PROFILE.email, `mailto:${PROFILE.email}`],
    ['LinkedIn', 'linkedin', PROFILE.linkedin],
    ['Portfolio', 'portfolio', PROFILE.portfolio],
  ];
  return (
    <group position={[BW / 2 + 1.7, 0, BW / 2 + 0.4]} rotation={[0, -0.22, 0]}>
      <mesh position={[0, 1, 0]}><boxGeometry args={[0.12, 2, 0.12]} /><meshStandardMaterial color="#5a3d22" roughness={1} /></mesh>
      <mesh position={[0, 1.75, 0]}><boxGeometry args={[2.0, 1.45, 0.08]} /><meshStandardMaterial color="#7a5430" roughness={0.9} /></mesh>
      <Html transform center distanceFactor={dfFor(SIGN_PX)} position={[0, 1.75, 0.05]}>
        <div ref={ref} className="booth-sign" style={{ width: 1.85 * SIGN_PX, height: 1.3 * SIGN_PX, opacity: 0, visibility: 'hidden' }}>
          <h3>Get in touch</h3>
          <p>{PROFILE.location}</p>
          <ul>
            {links.map(([label, text, href]) => (
              <li key={label}><span>{label}</span><a href={href} target="_blank" rel="noreferrer">{text}</a></li>
            ))}
          </ul>
        </div>
      </Html>
    </group>
  );
}

export default function PhoneBoothScene() {
  const sunset = useRef();
  useFrame(() => {
    if (sunset.current) sunset.current.intensity = 6 * Math.min(1, Math.max(0, (rig.atmo - 4) * 1.2));
  });
  return (
    <SceneGroup id="booth" position={BOOTH.pos} rotation-y={BOOTH.rotY}>
      <OptionalGLTF url={MODELS.booth} fallback={<BoothBody />} />
      <Paper />
      <ContactSign />
      {/* warm kicker so the glass catches the sunset */}
      <pointLight ref={sunset} position={[3, 2.5, 5]} color="#ff9a55" distance={14} decay={1.6} />
    </SceneGroup>
  );
}
