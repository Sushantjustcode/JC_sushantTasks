import { useLayoutEffect, useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { Html } from '@react-three/drei';
import { rig } from '../rig/rig';
import { SceneGroup } from '../rig/SceneGroup';
import { useFade, useFlicker } from '../rig/hooks';
import { OptionalGLTF } from '../shared/OptionalGLTF';
import { dfFor, smooth } from '../shared/utils';
import { SKILL_GROUPS, PROFILE } from '../config/cv';
import { MODELS, TRAIN, coachCenter } from '../config/storyboard';

/**
 * SCENE 3: THE INDIAN BLUE TRAIN (skill scrubber)
 * ───────────────────────────────────────────────
 * The camera is parked parallel to the train (see WAYPOINTS 5→6). The master timeline
 * tweens rig.trainX; this component just moves the whole train group to that x each frame.
 *
 * 3D ↔ HTML interplay, per coach:
 *   • <Html transform> panel is glued to the coach's side wall, so it travels with the train.
 *   • Each frame we measure how close the coach is to screen-centre → `lit` (0…1).
 *   • `lit` drives (a) the opacity of emissive window planes BEHIND the DOM (3D glow + bloom)
 *     and (b) the CSS variable --lit on the DOM panel (text turns from cold blue to warm ink).
 *   So skills "switch on" inside the windows as their coach rolls past the camera.
 */

const PX = 120; // DOM px per world unit on the train (see dfFor)
const D = 2.6; // body depth (z)
const H = 3.2; // body height
const Y0 = 0.6; // ride height
const WHEEL_R = 0.45;
const PANEL = { w: TRAIN.coachLen - 0.5, h: 1.5, y: 2.25 };
const HEAD_PX = 44;
const GAP_PX = 8;
const WIN_H = (PANEL.h * PX - HEAD_PX - GAP_PX) / PX;
const WIN_Y = PANEL.y + PANEL.h / 2 - (HEAD_PX + GAP_PX) / PX - WIN_H / 2;
const CELL_GAP = 0.09;
const FADE = [26.5, 28.5, 53, 54.5];

const matBlue = new THREE.MeshStandardMaterial({ color: '#1f4f9c', roughness: 0.5, metalness: 0.15 });
const matCream = new THREE.MeshStandardMaterial({ color: '#f1ead7', roughness: 0.6 });
const matGrey = new THREE.MeshStandardMaterial({ color: '#8d96a0', roughness: 0.7 });
const matDark = new THREE.MeshStandardMaterial({ color: '#1a1d22', roughness: 0.8 });

function Wheel({ position, wheels }) {
  return (
    <group position={position} ref={(el) => el && wheels.add(el)}>
      <mesh rotation={[Math.PI / 2, 0, 0]} material={matDark}>
        <cylinderGeometry args={[WHEEL_R, WHEEL_R, 0.12, 20]} />
      </mesh>
      <mesh position={[0.24, 0, 0.07]} material={matCream}>
        <boxGeometry args={[0.22, 0.06, 0.02]} />
      </mesh>
    </group>
  );
}

function Bogie({ x, wheels }) {
  return (
    <group position={[x, WHEEL_R, 0]}>
      {[-0.9, 0.9].flatMap((dx) => [-0.78, 0.78].map((z) => <Wheel key={`${dx}${z}`} position={[dx, 0, z]} wheels={wheels} />))}
    </group>
  );
}

function CoachBody({ wheels }) {
  const L = TRAIN.coachLen;
  return (
    <group>
      <mesh material={matBlue} position={[0, Y0 + H / 2, 0]}><boxGeometry args={[L, H, D]} /></mesh>
      <mesh material={matCream} position={[0, Y0 + 0.55, 0]}><boxGeometry args={[L + 0.02, 0.16, D + 0.02]} /></mesh>
      <mesh material={matCream} position={[0, Y0 + H - 0.2, 0]}><boxGeometry args={[L + 0.02, 0.16, D + 0.02]} /></mesh>
      <mesh material={matGrey} position={[0, Y0 + H + 0.12, 0]}><boxGeometry args={[L - 0.3, 0.24, D - 0.5]} /></mesh>
      <mesh material={matDark} position={[0, Y0 - 0.12, 0]}><boxGeometry args={[L - 0.8, 0.3, D - 0.6]} /></mesh>
      <Bogie x={-L * 0.32} wheels={wheels} />
      <Bogie x={L * 0.32} wheels={wheels} />
    </group>
  );
}

const collectWheels = (root, wheels) => root.traverse((o) => o.name?.startsWith('Wheel') && wheels.add(o));

function Coach({ group, index, x, wheels }) {
  const panel = useRef();
  const glow = useMemo(() => {
    const m = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0.1, toneMapped: false });
    m.color.setRGB(3, 2.3, 1.1); // HDR warm window light → picked up by bloom
    return m;
  }, []);
  useFade(panel, FADE);

  useFrame(({ clock }) => {
    const d = Math.abs(rig.trainX + x); // coach centre vs screen centre (camera x ≈ 0)
    const lit = 1 - smooth((d - 2.5) / 5.5);
    glow.opacity = (0.1 + lit * 0.9) * (1 + Math.sin(clock.elapsedTime * 11 + index * 2) * 0.03);
    panel.current?.style.setProperty('--lit', lit.toFixed(3));
  });

  const n = group.skills.length;
  const cellW = (PANEL.w - CELL_GAP * (n - 1)) / n;
  return (
    <group position={[x, 0, 0]}>
      <OptionalGLTF url={MODELS.coach} fallback={<CoachBody wheels={wheels.current} />} onReady={(r) => collectWheels(r, wheels.current)} />
      {/* dark glass strip, then one emissive plane per window (all share the `glow` material) */}
      <mesh position={[0, WIN_Y, D / 2 + 0.008]}>
        <planeGeometry args={[PANEL.w + 0.1, WIN_H + 0.1]} />
        <meshStandardMaterial color="#0a1a33" roughness={0.3} />
      </mesh>
      {group.skills.map((s, k) => (
        <mesh key={s} material={glow} position={[-PANEL.w / 2 + cellW / 2 + k * (cellW + CELL_GAP), WIN_Y, D / 2 + 0.014]}>
          <planeGeometry args={[cellW, WIN_H]} />
        </mesh>
      ))}
      <Html transform center distanceFactor={dfFor(PX)} position={[0, PANEL.y, D / 2 + 0.04]}>
        <div ref={panel} className="coach-panel" style={{ width: PANEL.w * PX, height: PANEL.h * PX, opacity: 0, visibility: 'hidden' }}>
          <div className="coach-head" style={{ height: HEAD_PX }}>
            <span>{group.coach}</span>
            <b>{group.title}</b>
          </div>
          <div className="coach-windows" style={{ gap: CELL_GAP * PX, marginTop: GAP_PX, height: WIN_H * PX }}>
            {group.skills.map((s) => (
              <div key={s} className="coach-cell">{s}</div>
            ))}
          </div>
        </div>
      </Html>
    </group>
  );
}

function Loco({ wheels }) {
  const L = TRAIN.locoLen;
  const plate = useRef();
  const lamp = useRef();
  useFade(plate, FADE);
  useFlicker(lamp, { base: 3, amp: 0.2, speed: 8 });
  return (
    <group>
      <OptionalGLTF
        url={MODELS.loco}
        fallback={
          <group>
            <mesh material={matBlue} position={[L / 2, Y0 + H / 2, 0]}><boxGeometry args={[L, H, D]} /></mesh>
            <mesh material={matBlue} position={[0.7, Y0 + 1.1, 0]}><boxGeometry args={[1.4, 2.2, D - 0.3]} /></mesh>
            <mesh material={matCream} position={[L / 2, Y0 + 0.55, 0]}><boxGeometry args={[L + 0.02, 0.16, D + 0.02]} /></mesh>
            <mesh material={matCream} position={[L / 2, Y0 + H - 0.2, 0]}><boxGeometry args={[L + 0.02, 0.16, D + 0.02]} /></mesh>
            <mesh material={matGrey} position={[L / 2, Y0 + H + 0.14, 0]}><boxGeometry args={[L - 0.4, 0.28, D - 0.6]} /></mesh>
            <mesh material={matDark} position={[L - 1.3, Y0 + H - 1.0, D / 2 + 0.01]}><boxGeometry args={[1.5, 1.0, 0.02]} /></mesh>
            <mesh position={[0.05, Y0 + 1.7, 0.6]}>
              <sphereGeometry args={[0.2, 12, 12]} />
              <meshBasicMaterial color={[3, 2.8, 2]} toneMapped={false} />
            </mesh>
            <mesh material={matDark} position={[L / 2, Y0 - 0.12, 0]}><boxGeometry args={[L - 0.8, 0.3, D - 0.6]} /></mesh>
            <Bogie x={L * 0.25} wheels={wheels.current} />
            <Bogie x={L * 0.75} wheels={wheels.current} />
          </group>
        }
        onReady={(r) => collectWheels(r, wheels.current)}
      />
      <pointLight ref={lamp} position={[-0.4, Y0 + 1.7, 0.6]} color="#fff0c4" distance={9} decay={2} />
      <Html transform center distanceFactor={dfFor(PX)} position={[L * 0.5, PANEL.y, D / 2 + 0.04]}>
        <div ref={plate} className="loco-plate" style={{ width: 5.2 * PX, height: 1.3 * PX, opacity: 0, visibility: 'hidden' }}>
          <strong>{PROFILE.name}</strong>
          <span>Full-Stack MERN Developer</span>
        </div>
      </Html>
    </group>
  );
}

function Tracks() {
  const ref = useRef();
  const xs = useMemo(() => Array.from({ length: 330 }, (_, i) => -140 + i * 0.85), []);
  useLayoutEffect(() => {
    const o = new THREE.Object3D();
    xs.forEach((x, i) => {
      o.position.set(x, 0.07, 0);
      o.updateMatrix();
      ref.current.setMatrixAt(i, o.matrix);
    });
    ref.current.instanceMatrix.needsUpdate = true;
  }, [xs]);
  return (
    <group position={[0, 0, TRAIN.z]}>
      <mesh position={[0, 0.07, 0]}><boxGeometry args={[320, 0.14, 3.6]} /><meshStandardMaterial color="#6f6a62" roughness={1} /></mesh>
      <instancedMesh ref={ref} args={[undefined, undefined, xs.length]}>
        <boxGeometry args={[0.28, 0.1, 2.5]} />
        <meshStandardMaterial color="#4a3a2c" roughness={1} />
      </instancedMesh>
      {[-0.78, 0.78].map((z) => (
        <mesh key={z} position={[0, 0.22, z]}><boxGeometry args={[320, 0.12, 0.1]} /><meshStandardMaterial color="#9aa3ad" metalness={0.8} roughness={0.35} /></mesh>
      ))}
    </group>
  );
}

export default function TrainScene() {
  const root = useRef();
  const wheels = useRef(new Set());
  const prev = useRef(rig.trainX);

  useFrame((_, dt) => {
    const g = root.current;
    if (!g) return;
    g.position.x = rig.trainX;
    const roll = (TRAIN.x0 - rig.trainX) / WHEEL_R; // wheels turn exactly with distance travelled
    wheels.current.forEach((w) => (w.rotation.z = roll));
    const v = Math.abs(rig.trainX - prev.current) / Math.max(dt, 1e-3);
    prev.current = rig.trainX;
    g.position.y = Math.sin(performance.now() * 0.045) * 0.004 * Math.min(v, 6); // rumble while moving
  });

  return (
    <SceneGroup id="train">
      <Tracks />
      <group ref={root} position={[TRAIN.x0, 0, TRAIN.z]}>
        <Loco wheels={wheels} />
        {SKILL_GROUPS.map((g, k) => (
          <Coach key={g.coach} group={g} index={k} x={coachCenter(k)} wheels={wheels} />
        ))}
      </group>
    </SceneGroup>
  );
}
