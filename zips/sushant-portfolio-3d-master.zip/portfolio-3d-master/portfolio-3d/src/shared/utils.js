export const clamp01 = (x) => Math.min(1, Math.max(0, x));
export const smooth = (x) => {
  x = clamp01(x);
  return x * x * (3 - 2 * x);
};

/** Seeded RNG so scatter (grass, clouds, vines…) is identical on every load. */
export const mulberry32 = (a) => () => {
  a |= 0;
  a = (a + 0x6d2b79f5) | 0;
  let t = Math.imul(a ^ (a >>> 15), 1 | a);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};

/**
 * drei <Html transform>: 1 DOM px = distanceFactor / 400 world units.
 * So pick how many CSS px you want per world unit and use dfFor(px) as distanceFactor.
 * Rule of thumb: on-screen text scale = (screenHeightPx / visibleWorldHeight) / pxPerUnit.
 */
export const dfFor = (pxPerUnit) => 400 / pxPerUnit;

/** 0→1 over [a,b], optionally back to 0 over [c,d]. Used to fade DOM overlays from timeline time. */
export const fadeWindow = (t, [a, b, c, d]) =>
  smooth((t - a) / (b - a)) * (c === undefined ? 1 : 1 - smooth((t - c) / (d - c)));
