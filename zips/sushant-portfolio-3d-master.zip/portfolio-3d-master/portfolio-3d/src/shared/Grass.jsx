import { useLayoutEffect, useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { mulberry32 } from './utils';

// One shared material: blades bend in the wind via a tiny vertex-shader injection.
const swayUniforms = { uTime: { value: 0 } };
const swayMaterial = new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 1, flatShading: true });
swayMaterial.onBeforeCompile = (shader) => {
  shader.uniforms.uTime = swayUniforms.uTime;
  shader.vertexShader = shader.vertexShader
    .replace('#include <common>', '#include <common>\nuniform float uTime;')
    .replace(
      '#include <begin_vertex>',
      `#include <begin_vertex>
       #ifdef USE_INSTANCING
         float ph = instanceMatrix[3].x * 0.35 + instanceMatrix[3].z * 0.27;
       #else
         float ph = 0.0;
       #endif
       float bend = max(position.y, 0.0);
       transformed.x += sin(uTime * 1.6 + ph) * 0.14 * bend;
       transformed.z += cos(uTime * 1.2 + ph) * 0.09 * bend;`
    );
};

/** Mount once inside <Canvas>: advances the wind clock. */
export function SwayTicker() {
  useFrame(({ clock }) => {
    swayUniforms.uTime.value = clock.elapsedTime;
  });
  return null;
}

/** positions = array of [x, z]. Thousands of blades, one draw call. */
export function GrassInstances({ positions, height = 0.7, color = '#4f8a3c', seed = 1 }) {
  const ref = useRef();
  const geo = useMemo(() => {
    const g = new THREE.ConeGeometry(0.06, height, 3);
    g.translate(0, height / 2, 0);
    return g;
  }, [height]);
  useLayoutEffect(() => {
    const rnd = mulberry32(seed);
    const o = new THREE.Object3D();
    const c = new THREE.Color();
    positions.forEach(([x, z], i) => {
      o.position.set(x, 0, z);
      o.rotation.set(0, rnd() * 6.28, (rnd() - 0.5) * 0.25);
      o.scale.setScalar(0.6 + rnd() * 1.0);
      o.updateMatrix();
      ref.current.setMatrixAt(i, o.matrix);
      ref.current.setColorAt(i, c.set(color).offsetHSL((rnd() - 0.5) * 0.04, 0, (rnd() - 0.5) * 0.14));
    });
    ref.current.instanceMatrix.needsUpdate = true;
    ref.current.instanceColor.needsUpdate = true;
  }, [positions, color, seed]);
  return <instancedMesh ref={ref} args={[geo, swayMaterial, positions.length]} frustumCulled={false} />;
}
