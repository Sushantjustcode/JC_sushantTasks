import { useMemo, useRef } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { mulberry32 } from './utils';

const geo = new THREE.IcosahedronGeometry(1, 1);
const mat = new THREE.MeshStandardMaterial({
  color: '#ffffff',
  emissive: '#dfeaff',
  emissiveIntensity: 0.35,
  flatShading: true,
  roughness: 1,
});

/** Low-poly cumulus puffs that drift along +x and wrap around. */
export default function CloudField({ count = 20, seed = 11, area = [150, 22, 70], center = [0, 30, -55], speed = 0.7 }) {
  const refs = useRef([]);
  const clouds = useMemo(() => {
    const r = mulberry32(seed);
    return Array.from({ length: count }, () => ({
      p: [(r() - 0.5) * area[0], center[1] + (r() - 0.5) * area[1], center[2] + (r() - 0.5) * area[2]],
      s: 2.2 + r() * 3.2,
      v: speed * (0.5 + r()),
      puffs: Array.from({ length: 5 + Math.floor(r() * 3) }, (_, i) => [(i - 3) * 0.9 + r() * 0.5, r() * 0.7, (r() - 0.5) * 0.9, 0.8 + r() * 0.8]),
    }));
  }, [count, seed, area, center, speed]);

  useFrame((_, dt) => {
    refs.current.forEach((g, i) => {
      if (!g) return;
      g.position.x += clouds[i].v * dt;
      if (g.position.x > area[0] / 2 + 20) g.position.x = -area[0] / 2 - 20;
    });
  });

  return (
    <group>
      {clouds.map((c, i) => (
        <group key={i} ref={(el) => (refs.current[i] = el)} position={c.p} scale={c.s}>
          {c.puffs.map(([x, y, z, r], k) => (
            <mesh key={k} geometry={geo} material={mat} position={[x, y, z]} scale={[r * 1.15, r * 0.8, r]} />
          ))}
        </group>
      ))}
    </group>
  );
}
