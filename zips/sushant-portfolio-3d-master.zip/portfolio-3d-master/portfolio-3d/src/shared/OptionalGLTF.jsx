import { Suspense, useEffect, useLayoutEffect, useMemo, useState } from 'react';
import { useGLTF } from '@react-three/drei';

function GLTFPrimitive({ url, onReady, ...props }) {
  const { scene } = useGLTF(url);
  const root = useMemo(() => scene.clone(true), [scene]);
  useLayoutEffect(() => {
    onReady?.(root);
  }, [root, onReady]);
  return <primitive object={root} {...props} />;
}

/**
 * Loads /public/models/*.glb if it exists, otherwise renders `fallback` (the built-in primitives).
 * HEAD-checks first because Vite/SPA hosts answer a missing file with index.html (200, text/html),
 * which would otherwise crash useGLTF. Drop a real .glb in and it swaps in automatically.
 */
export function OptionalGLTF({ url, fallback = null, onReady, ...props }) {
  const [state, setState] = useState('checking');
  useEffect(() => {
    let live = true;
    fetch(url, { method: 'HEAD' })
      .then((r) => live && setState(r.ok && !(r.headers.get('content-type') || '').includes('text/html') ? 'ok' : 'missing'))
      .catch(() => live && setState('missing'));
    return () => {
      live = false;
    };
  }, [url]);
  if (state !== 'ok') return fallback;
  return (
    <Suspense fallback={fallback}>
      <GLTFPrimitive url={url} onReady={onReady} {...props} />
    </Suspense>
  );
}
