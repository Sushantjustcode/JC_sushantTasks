import { useMemo } from 'react';
import * as THREE from 'three';
import { mulberry32 } from './utils';

const canvas = (w, h) => {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  return [c, c.getContext('2d')];
};
const finish = (c, { repeat = true, srgb = true } = {}) => {
  const t = new THREE.CanvasTexture(c);
  if (repeat) t.wrapS = t.wrapT = THREE.RepeatWrapping;
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
};
export const roundRect = (g, x, y, w, h, r) => {
  g.beginPath();
  g.moveTo(x + r, y);
  g.arcTo(x + w, y, x + w, y + h, r);
  g.arcTo(x + w, y + h, x, y + h, r);
  g.arcTo(x, y + h, x, y, r);
  g.arcTo(x, y, x + w, y, r);
  g.closePath();
};

/** Seamless red brick (running bond). One tile = 1.6 world units when repeat is set by the mesh. */
export function useBrickTexture() {
  return useMemo(() => {
    const [c, g] = canvas(512, 512);
    const rnd = mulberry32(7);
    g.fillStyle = '#d9cdbb';
    g.fillRect(0, 0, 512, 512);
    for (let row = 0; row < 8; row++) {
      for (let col = -1; col < 5; col++) {
        const x = col * 128 + (row % 2 ? 64 : 0) + 3;
        g.fillStyle = `hsl(${7 + rnd() * 9} ${50 + rnd() * 12}% ${36 + rnd() * 11}%)`;
        g.fillRect(x, row * 64 + 3, 122, 58);
      }
    }
    for (let i = 0; i < 1800; i++) {
      g.fillStyle = `rgba(0,0,0,${rnd() * 0.07})`;
      g.fillRect(rnd() * 512, rnd() * 512, 2, 2);
    }
    return finish(c);
  }, []);
}

/** Seamless irregular stone courses (rows sum to the tile height, stones sum to the tile width). */
export function useStoneTexture() {
  return useMemo(() => {
    const S = 1024;
    const [c, g] = canvas(S, S);
    const rnd = mulberry32(5);
    g.fillStyle = '#3f3b35';
    g.fillRect(0, 0, S, S);
    const rows = 9;
    const h = S / rows;
    for (let r = 0; r < rows; r++) {
      const ws = [];
      let sum = 0;
      while (sum < S) {
        const w = 90 + rnd() * 120;
        ws.push(w);
        sum += w;
      }
      let x = 0;
      for (const w0 of ws) {
        const w = (w0 * S) / sum;
        const l = 40 + rnd() * 20;
        g.fillStyle = `hsl(${28 + rnd() * 14} ${5 + rnd() * 9}% ${l}%)`;
        roundRect(g, x + 4, r * h + 4, w - 8, h - 8, 16);
        g.fill();
        g.fillStyle = 'rgba(255,255,255,0.10)';
        roundRect(g, x + 8, r * h + 8, w - 16, 10, 5);
        g.fill();
        g.fillStyle = 'rgba(0,0,0,0.18)';
        roundRect(g, x + 8, r * h + h - 18, w - 16, 10, 5);
        g.fill();
        x += w;
      }
    }
    for (let i = 0; i < 2500; i++) {
      g.fillStyle = `rgba(0,0,0,${rnd() * 0.12})`;
      g.fillRect(rnd() * S, rnd() * S, 2, 2);
    }
    return finish(c);
  }, []);
}

/** Speckled sand for the road ribbon. */
export function useSandTexture() {
  return useMemo(() => {
    const [c, g] = canvas(256, 256);
    const rnd = mulberry32(13);
    g.fillStyle = '#cfa96d';
    g.fillRect(0, 0, 256, 256);
    for (let i = 0; i < 3500; i++) {
      const v = rnd();
      g.fillStyle = v > 0.5 ? `rgba(255,236,190,${rnd() * 0.35})` : `rgba(110,75,35,${rnd() * 0.3})`;
      g.fillRect(rnd() * 256, rnd() * 256, 1 + rnd() * 2, 1 + rnd() * 2);
    }
    return finish(c);
  }, []);
}

/** White→black vertical gradient used as an alphaMap (opaque at the bottom row, transparent at the top). */
export function useGradientAlpha() {
  return useMemo(() => {
    const [c, g] = canvas(4, 256);
    const grad = g.createLinearGradient(0, 0, 0, 256);
    grad.addColorStop(0, '#000');
    grad.addColorStop(0.55, '#333');
    grad.addColorStop(1, '#fff');
    g.fillStyle = grad;
    g.fillRect(0, 0, 4, 256);
    return finish(c, { repeat: false, srgb: false });
  }, []);
}

/** Paper with tape marks for the booth note. */
export function usePaperTexture() {
  return useMemo(() => {
    const [c, g] = canvas(512, 660);
    const rnd = mulberry32(31);
    g.fillStyle = '#f7f1e1';
    g.fillRect(0, 0, 512, 660);
    for (let i = 0; i < 2500; i++) {
      g.fillStyle = `rgba(120,90,40,${rnd() * 0.06})`;
      g.fillRect(rnd() * 512, rnd() * 660, 2, 2);
    }
    g.fillStyle = 'rgba(255,224,140,0.55)';
    g.fillRect(-20, 10, 120, 44);
    g.fillRect(412, 10, 120, 44);
    return finish(c, { repeat: false });
  }, []);
}

/** Flag-style banner for the airplane. */
export function useBannerTexture(text) {
  return useMemo(() => {
    const [c, g] = canvas(1400, 320);
    g.fillStyle = '#f7f0df';
    g.fillRect(0, 0, 1400, 320);
    g.strokeStyle = '#a63d2a';
    g.lineWidth = 14;
    g.strokeRect(14, 14, 1372, 292);
    g.fillStyle = '#a63d2a';
    g.font = '700 190px Fraunces, Georgia, serif';
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.fillText(text, 700, 172);
    const t = finish(c, { repeat: false });
    document.fonts?.ready.then(() => {
      g.fillStyle = '#f7f0df';
      g.fillRect(20, 20, 1360, 280);
      g.fillStyle = '#a63d2a';
      g.fillText(text, 700, 172);
      t.needsUpdate = true;
    });
    return t;
  }, [text]);
}
